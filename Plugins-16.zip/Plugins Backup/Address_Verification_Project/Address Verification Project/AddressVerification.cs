using System;
using System.Data;

namespace Address_Verification_Project
{
   public class AddressVerification
    {

        // This function Fetch Address from Service object
        public DataTable GetAddressFromServiceObject(string Address, string City, string State, string Zip, string Key)
        {
            DataTable tblNew = new DataTable();

            try
            {
                // calling service service object
                DOTSAddressValidate.DOTSAddressValidate chk = new DOTSAddressValidate.DOTSAddressValidate();
                DOTSAddressValidate.DPVAddress add = chk.ValidateAddressWithDPV(Address, "", City, State, Zip, Key);

                // make sure record exist from service object
                if (add != null && add.Address != null && add.Address != "")
                {

                    tblNew.Columns.Add("Index");
                    tblNew.Columns.Add("Address1");
                    tblNew.Columns.Add("City");
                    tblNew.Columns.Add("State");
                    tblNew.Columns.Add("Zip");
                    tblNew.Columns.Add("ESID");
                    tblNew.Columns.Add("Zone");
                    tblNew.Columns.Add("Switch");
                    tblNew.Columns.Add("TDSP");
                    tblNew.Columns.Add("AMS");
                    tblNew.Columns.Add("AddressType");

                    DataRow drNew = tblNew.NewRow();
                    drNew["Index"] = 0;
                    drNew["Address1"] = add.Address;
                    drNew["City"] = add.City;
                    drNew["State"] = add.State;
                    drNew["Zip"] = add.Zip.Substring(0, 5);


                    tblNew.Rows.Add(drNew);

                    return tblNew;
                }
            }
            catch (Exception ex)
            {

            }

            return null;
        }


        // following simply get County function from service object
        public string GetCounty(string Address, string City, string State, string Zip, string Key)
        {
            DOTSAddressValidate.DOTSAddressValidate chk = new DOTSAddressValidate.DOTSAddressValidate();
            try
            {
                DOTSAddressValidate.DPVAddress add = chk.ValidateAddressWithDPV(Address, "", City, State, Zip, Key);

                if (add != null && add.Address != null && add.Address != "")
                {

                    return String.IsNullOrEmpty(add.CountyName) ? String.Empty : add.CountyName;
                }
                else
                {
                    return "";
                }
            }
            catch
            {
                return "";
            }
        }
    }
}