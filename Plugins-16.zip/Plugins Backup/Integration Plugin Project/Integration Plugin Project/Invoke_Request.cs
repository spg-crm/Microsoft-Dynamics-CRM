﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Text;
using System.Xml;
using System.Xml.Linq;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace Integration_Plugin_Project
{
    public enum _enmTransaction
    {
        ExperianCompanies = 1,
        ExperianCreditScore = 2,
        CreateOpportunity = 3,
        IntegrateBDM = 4,
        IntegrateBroker = 5,
        IntegrateBrokerAgent = 6,
        IntegrateContract = 7
    };
    public class Invoke_Request : IPlugin
    {
        #region Secure/Unsecure Configuration Setup
        private string _secureConfig = null;
        private string _unsecureConfig = null;

        public Invoke_Request(string unsecureConfig, string secureConfig)
        {
            _secureConfig = secureConfig;
            _unsecureConfig = unsecureConfig;
        }
        #endregion
        #region Transaction entity field Constants
        private string _attrTransactionType = "spg_transactiontype";
        #endregion
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);

            try
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                int _attrTransactionTypeValue = 0;

                if (entity.Attributes.Contains(_attrTransactionType))
                {
                    _attrTransactionTypeValue = ((OptionSetValue)entity.Attributes[_attrTransactionType]).Value;

                    tracer.Trace(string.Format("{0} : {1}", _attrTransactionType, _attrTransactionTypeValue));

                    Experian_Integration objExperian;
                    ESG_Integration objESG;

                    switch (_attrTransactionTypeValue)
                    {
                        case (int)_enmTransaction.ExperianCompanies:
                            objExperian = new Experian_Integration();
                            objExperian.GetCompanies(ref entity, ref service, context.UserId, ref tracer);

                            break;
                        case (int)_enmTransaction.ExperianCreditScore:
                            objExperian = new Experian_Integration();
                            objExperian.GetCreditScore(ref entity, ref service, context.UserId, ref tracer);
                            break;
                        case (int)_enmTransaction.CreateOpportunity:
                            objESG = new ESG_Integration();
                            objESG.IntegrateOpportunity(ref entity, ref service, context.UserId, ref tracer);
                            break;
                        case (int)_enmTransaction.IntegrateBDM:
                            objESG = new ESG_Integration();
                            objESG.IntegrateBDM(ref entity, ref service, context.UserId, ref tracer);
                            break;
                        case (int)_enmTransaction.IntegrateBroker:
                            objESG = new ESG_Integration();
                            objESG.IntegrateBroker(ref entity, ref service, context.UserId, ref tracer);
                            break;
                        case (int)_enmTransaction.IntegrateBrokerAgent:
                            objESG = new ESG_Integration();
                            objESG.IntegrateBrokerAgent(ref entity, ref service, context.UserId, ref tracer);
                            break;
                        case (int)_enmTransaction.IntegrateContract:
                            objESG = new ESG_Integration();
                            objESG.IntegrateContract(ref entity, ref service, context.UserId, ref tracer);
                            break;
                        default:
                            tracer.Trace(String.Format("Transaction type {0} is not implemented yet", _attrTransactionTypeValue));
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }

        #region Helpers
        public static XmlDocument HttpSOAPRequest(string url, string serviceParameters, string serviceData, ref ITracingService tracer, bool IsContract)
        {
            // trust all certs
            ServicePointManager.ServerCertificateValidationCallback = ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });

            System.Net.ServicePointManager.Expect100Continue = false;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);

            tracer.Trace("into HttpRequest method..");

            req.KeepAlive = false;
            req.ConnectionGroupName = Guid.NewGuid().ToString();
            req.Headers.Add("SOAPAction", "\"\"");
            req.ContentType = "text/xml;charset=utf-8";
            req.Accept = "text/xml";
            req.Method = "POST";
            Stream stm = req.GetRequestStream();
            string soapHdr;
            string soapTrl;

            if (IsContract)
            {
                soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Body>";
                soapTrl = "</soapenv:Body></soapenv:Envelope>";
            }
            else
            {
                soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
                soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
            }
            string input = string.Concat(soapHdr, serviceParameters, serviceData, soapTrl);
           // throw new Exception(input);
            // Util.FileWrite(strNTXPath, "Request-" + CustomerID, input);
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(soapHdr + serviceParameters + serviceData + soapTrl);
            stm.Write(bytes, 0, bytes.Length);
            stm.Close();

          

            HttpWebResponse resp;

            try
            {
                
                resp = (HttpWebResponse)req.GetResponse();
                

                Stream objResponseStream = resp.GetResponseStream();
                XmlTextReader objXMLReader = new XmlTextReader(objResponseStream);
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(objXMLReader);
                XmlDocument XMLResponse = xmldoc;
                objXMLReader.Close();
                
                return XMLResponse;
            }
            catch (WebException exc)
            {
                if (exc.Status == WebExceptionStatus.ProtocolError)
                {
                    StreamReader reader = new StreamReader(exc.Response.GetResponseStream());
                    throw new Exception(reader.ReadToEnd() + " : input : " + input);
                }
                return null;
            }
        }
        #endregion
    }
}
