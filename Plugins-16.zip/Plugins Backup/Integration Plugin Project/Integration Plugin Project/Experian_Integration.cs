﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Net;
using System.Net.Security;
using System.Xml;
using System.Xml.Linq;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace Integration_Plugin_Project
{
    public class Experian_Integration
    {
        #region Transaction entity field Constants

        private string _strCompanyLookupEntity = "spg_experiancompanies";

        private string _attrBusinessName = "spg_businessname";
        private string _attrBusinessAddress = "spg_businessaddress";
        private string _attrBusinessCity = "spg_businesscity";
        private string _attrBusinessState = "spg_businessstate";
        private string _attrBusinessZip = "spg_businesszip";
        private string _attrBusinessTaxId = "spg_businesstaxid";
        private string _attrBusinessRecordNo = "spg_businessrecordno";
        private string _attrBusinessTransNo = "spg_businesstransno";
        private string _attrBusinessFileNo = "spg_businessfileno";
        private string _attrBusinessOpportunity = "spg_businessopportunity";
        private string _attrResponseStatusCode = "spg_responsestatuscode";
        private string _attrResponseServerURL = "spg_responseserverurl";
        private string _attrResponseFSRScore = "spg_responsefsrscore";
        private string _attrResponseIntelliScore = "spg_responseintelliscore";
        private string _attrResponseModelCode = "spg_responsemodelcode";
        private string _attrResponseScore = "spg_responsescore";
        private string _attrResultXML = "spg_resultxml";
        private string _attrRequestDataXML = "spg_dataxml";
        private string _attrResponseBIN = "spg_responsebin";
        private string _attrAPIPassword = "spg_apipassword";
        private string _attrAPIAccount = "spg_apiaccount";

        //private string _attrResponseTransNumber = "spg_responsetransnumber";

        private string _attrCompanyGUID = "spg_experiancompaniesid";
        private string _attrCompanyIndex = "spg_companyindex";
        private string _attrCompanyTransNo = "spg_companytransno";
        private string _attrCompanyFileNo = "spg_companyfileno";
        private string _attrCompanyRecordNo = "spg_companyrecordno";
        private string _attrCompanyPrimaryfield = "spg_name";
        private string _attrCompanyBusinessName = "spg_companyname";
        private string _attrCompanyAddress = "spg_companyaddress";
        private string _attrCompanyCity = "spg_companycity";
        private string _attrCompanyState = "spg_companystate";
        private string _attrCompanyZip = "spg_companyzip";
        private string _attrCompanyOwner = "ownerid";
        private string _attrCompanyOpportunityId = "spg_opportunityid";
        private string _attrCompanyOpportunity = "spg_opportunity";

        private string _strExperianHostName = ".experian.com";
        private string _strExperianServerURL = "http://www.experian.com/lookupServlet1?lookupServiceName=AccessPoint&lookupServiceVersion=1.0&serviceName=NetConnect&serviceVersion=2.0&responseType=text/plain";
        private string _strExperianCredentials = "#Account#:#Password#"; //"spgenergy4:Medtractions13";
        private string _strExperianDataPrefix = "NETCONNECT_TRANSACTION";
        private int _intRequestTimeout = 100000;

        private string _xnodResponseStatusCode = "CompletionCode";
        private string _xnodInquiryTransNo = "InquiryTransactionNumber";
        private string _xnodProducts = "Products";
        private string _xnodLOS = "ListOfSimilars";
        private string _xnodPremierProfile = "PremierProfile";
        private string _xnodInputSummary = "InputSummary";
        private string _xnodBusinessInfo = "ExpandedBusinessNameAndAddress";
        private string _xnodIntelliScoreInfo = "IntelliscoreScoreInformation";
        private string _xnodModelInfo = "ModelInformation";
        private string _xnodModelCode = "ModelCode";
        private string _xnodScoreInfo = "ScoreInfo";
        private string _xnodScore = "Score";
        private string _xnodScoreSign = "ScoreSign";
        private string _xnodBusinessBIN = "ExperianBIN";

        private string _xnodCompanyFileNo = "ExperianFileNumber";
        private string _xnodCompanyRecordNo = "RecordSequenceNumber";
        private string _xnodCompanyBusinessName = "BusinessName";

        private string _xnodCompanyAddress = "StreetAddress";
        private string _xnodCompanyCity = "City";
        private string _xnodCompanyState = "State";
        private string _xnodCompanyZip = "Zip";

        #endregion

        public void GetCompanies(ref Entity entity, ref IOrganizationService service, Guid UserId, ref ITracingService tracer)
        {
            string _strResultXML = null;
            string _varResponseStatusCode = null;
            string _strOpportunityId = null;
            EntityReference _objOpportunityRef = null;

            #region Pull Company List
            try
            {
                string _strDATAXML = GetTransactionTypePOSTData(_enmTransaction.ExperianCompanies);

                if (entity.Attributes.Contains(_attrBusinessOpportunity))
                {
                    _objOpportunityRef = entity.GetAttributeValue<EntityReference>(_attrBusinessOpportunity);
                    tracer.Trace(_objOpportunityRef.ToString());
                    if (_objOpportunityRef != null)
                    {
                        _strOpportunityId = _objOpportunityRef.Id.ToString();
                    }
                }
                #region setting credentials
                if (entity.Attributes.Contains(_attrAPIAccount))
                    _strExperianCredentials = _strExperianCredentials.Replace("#Account#", entity.Attributes[_attrAPIAccount].ToString());
                if (entity.Attributes.Contains(_attrAPIPassword))
                    _strExperianCredentials = _strExperianCredentials.Replace("#Password#", entity.Attributes[_attrAPIPassword].ToString());
                #endregion

                if (entity.Attributes.Contains(_attrBusinessName))
                    _strDATAXML = _strDATAXML.Replace("#BusinessName#", entity.Attributes[_attrBusinessName].ToString().Replace("&", "&amp;"));
                if (entity.Attributes.Contains(_attrBusinessAddress))
                    _strDATAXML = _strDATAXML.Replace("#Street#", entity.Attributes[_attrBusinessAddress].ToString().Replace("&", "&amp;"));
                if (entity.Attributes.Contains(_attrBusinessCity))
                    _strDATAXML = _strDATAXML.Replace("#City#", entity.Attributes[_attrBusinessCity].ToString());
                if (entity.Attributes.Contains(_attrBusinessState))
                    _strDATAXML = _strDATAXML.Replace("#State#", entity.Attributes[_attrBusinessState].ToString());
                if (entity.Attributes.Contains(_attrBusinessZip))
                    _strDATAXML = _strDATAXML.Replace("#Zip#", entity.Attributes[_attrBusinessZip].ToString());
                if (entity.Attributes.Contains(_attrBusinessTaxId))
                    _strDATAXML = _strDATAXML.Replace("#TaxID#", "<TaxId>" + entity.Attributes[_attrBusinessTaxId].ToString().Replace("-", "") + @"</TaxId>");
                else
                    _strDATAXML = _strDATAXML.Replace("#TaxID#", string.Empty);

                if (entity.Attributes.Contains(_attrRequestDataXML))
                    entity.Attributes[_attrRequestDataXML] = string.Format("{0}={1}", _strExperianDataPrefix, System.Web.HttpUtility.UrlEncode(_strDATAXML));
                else
                    entity.Attributes.Add(_attrRequestDataXML, string.Format("{0}={1}", _strExperianDataPrefix, System.Web.HttpUtility.UrlEncode(_strDATAXML)));

                string _strServerURL = GetServerURL(_enmTransaction.ExperianCompanies);

                if (entity.Attributes.Contains(_attrResponseServerURL))
                    entity.Attributes[_attrResponseServerURL] = _strServerURL.ToString();
                else
                    entity.Attributes.Add(_attrResponseServerURL, _strServerURL.ToString());

                _strResultXML = GetTransactionTypeResponse(_strServerURL.ToString(), _strDATAXML.ToString(), _enmTransaction.ExperianCompanies, ref tracer);
                if (entity.Attributes.Contains(_attrResultXML))
                    entity.Attributes[_attrResultXML] = _strResultXML;
                else
                    entity.Attributes.Add(_attrResultXML, _strResultXML);
            }
            catch (Exception ex)
            {
                tracer.Trace("pull company list");
                throw new InvalidPluginExecutionException(ex.Message);
                //tracer.Trace(ex.Message);
            }
            #endregion
            #region Parse Company List
            try
            {
                #region Parsing Completion Code
                XElement xElements = XElement.Parse(_strResultXML);

                _varResponseStatusCode = (from objElement in xElements.Elements()
                                          where objElement.Name.LocalName == _xnodResponseStatusCode
                                          select objElement.Value
                              ).FirstOrDefault();

                if (entity.Attributes.Contains(_attrResponseStatusCode))
                    entity.Attributes[_attrResponseStatusCode] = _varResponseStatusCode;
                else
                    entity.Attributes.Add(_attrResponseStatusCode, _varResponseStatusCode);

                #endregion
            }
            catch (Exception ex)
            {
                tracer.Trace("parse company list");
                throw new InvalidPluginExecutionException(ex.Message);
            }
            #endregion
            #region Deleting Users Experian Company List
            try
            {
                ConditionExpression _objOpportunityCondition = null;
                ConditionExpression _objOwnerCondition = null;

                FilterExpression _objFilterExpression = new FilterExpression(LogicalOperator.And);

                _objOwnerCondition =
                    new ConditionExpression(_attrCompanyOwner, ConditionOperator.Equal, UserId);
                _objFilterExpression.AddCondition(_objOwnerCondition);

                if (_strOpportunityId != null)
                {
                    _objOpportunityCondition =
                    new ConditionExpression(_attrCompanyOpportunityId, ConditionOperator.Equal, _strOpportunityId);

                    _objFilterExpression.AddCondition(_objOpportunityCondition);
                }

                QueryExpression objExperianCompaniesQuery = new QueryExpression
                {
                    EntityName = _strCompanyLookupEntity,
                    ColumnSet = new ColumnSet(_attrCompanyGUID),
                    Criteria = _objFilterExpression
                    //new FilterExpression
                    //{
                    //FilterOperator = LogicalOperator.And,
                    //Conditions =
                    //{
                    //    new ConditionExpression
                    //    {
                    //        AttributeName = _attrCompanyOwner,
                    //        Operator = ConditionOperator.Equal,
                    //        Values = { UserId }
                    //    },
                    //    new ConditionExpression
                    //    {
                    //        AttributeName = _attrCompanyOpportunityId,
                    //        Operator = ConditionOperator.Equal,
                    //        Values = { _strOpportunityId }
                    //    }
                    //}
                    //}
                };


                DataCollection<Entity> objExperianCompanies = service.RetrieveMultiple(
                    objExperianCompaniesQuery).Entities;

                foreach (Entity objExperianCompany in objExperianCompanies)
                {
                    Guid idExperianCompany = new Guid(objExperianCompany.Attributes[_attrCompanyGUID].ToString());
                    service.Delete(_strCompanyLookupEntity, idExperianCompany);
                }

            }
            catch (Exception ex)
            {
                tracer.Trace("delete company list");
                throw new InvalidPluginExecutionException(ex.Message);
            }

            #endregion
            #region Processing Company List into Entity
            try
            {
                if (_varResponseStatusCode != "1000" && _varResponseStatusCode != "1001"
                    && _varResponseStatusCode != "1002" && _varResponseStatusCode != "1003"
                    && _varResponseStatusCode != "1004" && _varResponseStatusCode != "2000"
                    && _varResponseStatusCode != "4000")
                {

                    XmlDocument objXMLDoc = new XmlDocument();
                    objXMLDoc.LoadXml(_strResultXML);

                    int _intCompanyIndex = 0;
                    //string _varResponseTransNumber = string.Empty;
                    string _varCompanyTransNo = string.Empty;
                    string _varCompanyFileNo = string.Empty;
                    string _varCompanyRecordNo = string.Empty;
                    string _varCompanyName = string.Empty;
                    string _varCompanyAddress = string.Empty;
                    string _varCompanyCity = string.Empty;
                    string _varCompanyState = string.Empty;
                    string _varCompanyZip = string.Empty;

                    XmlNodeList objProductsNode = objXMLDoc.GetElementsByTagName(_xnodProducts);
                    XmlNodeList objProductChildNode = objProductsNode[0].ChildNodes;

                    foreach (XmlNode objProduct in objProductChildNode)
                    {
                        if (objProduct.Name == _xnodPremierProfile)
                        {
                            XmlNodeList objIntellNode = objProduct.ChildNodes;
                            foreach (XmlNode objIntel in objIntellNode)
                            {
                                if (objIntel.Name == _xnodLOS)
                                {
                                    XmlNodeList objCompanyNode = objIntel.ChildNodes;
                                    foreach (XmlNode objCompanyTag in objCompanyNode)
                                    {
                                        if (objCompanyTag.Name == _xnodCompanyBusinessName)
                                        {
                                            _varCompanyName = objCompanyTag.InnerText.Trim();
                                        }
                                        else if (objCompanyTag.Name == _xnodCompanyAddress)
                                        {
                                            _varCompanyAddress = objCompanyTag.InnerText.Trim();
                                        }
                                        else if (objCompanyTag.Name == _xnodCompanyCity)
                                        {
                                            _varCompanyCity = objCompanyTag.InnerText.Trim();
                                        }
                                        else if (objCompanyTag.Name == _xnodCompanyState)
                                        {
                                            _varCompanyState = objCompanyTag.InnerText.Trim();
                                        }
                                        else if (objCompanyTag.Name == _xnodCompanyZip)
                                        {
                                            _varCompanyZip = objCompanyTag.InnerText.Trim();
                                        }
                                        else if (objCompanyTag.Name == _xnodCompanyFileNo)
                                        {
                                            _varCompanyFileNo = objCompanyTag.InnerText;
                                        }
                                        else if (objCompanyTag.Name == _xnodCompanyRecordNo)
                                        {
                                            _varCompanyRecordNo = objCompanyTag.InnerText;
                                        }
                                    }

                                    if (_varCompanyName != string.Empty)
                                    {
                                        Entity objCompanyLookup = new Entity(_strCompanyLookupEntity);
                                        objCompanyLookup[_attrCompanyTransNo] = _varCompanyTransNo;
                                        objCompanyLookup[_attrCompanyFileNo] = _varCompanyFileNo;
                                        objCompanyLookup[_attrCompanyRecordNo] = _varCompanyRecordNo;
                                        objCompanyLookup[_attrCompanyBusinessName] = _varCompanyName;
                                        objCompanyLookup[_attrCompanyPrimaryfield] = _varCompanyName;
                                        objCompanyLookup[_attrCompanyAddress] = _varCompanyAddress;
                                        objCompanyLookup[_attrCompanyCity] = _varCompanyCity;
                                        objCompanyLookup[_attrCompanyState] = _varCompanyState;
                                        objCompanyLookup[_attrCompanyZip] = _varCompanyZip;
                                        objCompanyLookup[_attrCompanyIndex] = Convert.ToInt32(_intCompanyIndex);
                                        objCompanyLookup[_attrCompanyOpportunityId] = _strOpportunityId;
                                        objCompanyLookup[_attrCompanyOpportunity] = _objOpportunityRef;
                                        Guid id = service.Create(objCompanyLookup);
                                    }
                                    _intCompanyIndex++;
                                }
                                else if (objIntel.Name == _xnodInputSummary)
                                {
                                    XmlNodeList objCompanyNode = objIntel.ChildNodes;
                                    foreach (XmlNode objCompanyTag in objCompanyNode)
                                    {
                                        if (objCompanyTag.Name == _xnodInquiryTransNo)
                                        {
                                            _varCompanyTransNo = objCompanyTag.InnerText;

                                            //if (entity.Attributes.Contains(_attrResponseTransNumber))
                                            //    entity.Attributes[_attrResponseTransNumber] = _varResponseTransNumber;
                                            //else
                                            //    entity.Attributes.Add(_attrResponseTransNumber, _varResponseTransNumber);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracer.Trace("Processing company list");
                // throw new InvalidPluginExecutionException(ex.Message);
            }
            #endregion

        }
        public void GetCreditScore(ref Entity entity, ref IOrganizationService service, Guid UserId, ref ITracingService tracer)
        {
            string _strResultXML = null;
            string _varResponseStatusCode = null;

            #region Pull Company Score
            try
            {
                string _strDATAXML = GetTransactionTypePOSTData(_enmTransaction.ExperianCreditScore);

                #region setting credentials
                if (entity.Attributes.Contains(_attrAPIAccount))
                    _strExperianCredentials = _strExperianCredentials.Replace("#Account#", entity.Attributes[_attrAPIAccount].ToString());
                if (entity.Attributes.Contains(_attrAPIPassword))
                    _strExperianCredentials = _strExperianCredentials.Replace("#Password#", entity.Attributes[_attrAPIPassword].ToString());
                #endregion

                if (entity.Attributes.Contains(_attrBusinessTransNo))
                    _strDATAXML = _strDATAXML.Replace("#TransNo#", entity.Attributes[_attrBusinessTransNo].ToString());
                if (entity.Attributes.Contains(_attrBusinessRecordNo))
                    _strDATAXML = _strDATAXML.Replace("#RecordNo#", entity.Attributes[_attrBusinessRecordNo].ToString());
                if (entity.Attributes.Contains(_attrBusinessFileNo))
                    _strDATAXML = _strDATAXML.Replace("#FileNo#", entity.Attributes[_attrBusinessFileNo].ToString());

                if (entity.Attributes.Contains(_attrRequestDataXML))
                    entity.Attributes[_attrRequestDataXML] = _strDATAXML.ToString();
                else
                    entity.Attributes.Add(_attrRequestDataXML, _strDATAXML.ToString());

                string _strServerURL = GetServerURL(_enmTransaction.ExperianCreditScore);

                if (entity.Attributes.Contains(_attrResponseServerURL))
                    entity.Attributes[_attrResponseServerURL] = _strServerURL.ToString();
                else
                    entity.Attributes.Add(_attrResponseServerURL, _strServerURL.ToString());

                _strResultXML = GetTransactionTypeResponse(_strServerURL.ToString(), _strDATAXML.ToString(), _enmTransaction.ExperianCreditScore, ref tracer);
                if (entity.Attributes.Contains(_attrResultXML))
                    entity.Attributes[_attrResultXML] = _strResultXML;
                else
                    entity.Attributes.Add(_attrResultXML, _strResultXML);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
                //tracer.Trace(ex.Message);
            }
            #endregion
            #region Parse Company Credit Score
            try
            {
                #region Parsing Completion Code
                XElement xElements = XElement.Parse(_strResultXML);

                _varResponseStatusCode = (from objElement in xElements.Elements()
                                          where objElement.Name.LocalName == _xnodResponseStatusCode
                                          select objElement.Value
                              ).FirstOrDefault();

                if (entity.Attributes.Contains(_attrResponseStatusCode))
                    entity.Attributes[_attrResponseStatusCode] = _varResponseStatusCode;
                else
                    entity.Attributes.Add(_attrResponseStatusCode, _varResponseStatusCode);

                #endregion
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            #endregion

            #region Processing Company Score into Transaction Entity
            try
            {
                if (_varResponseStatusCode != "1000" && _varResponseStatusCode != "1001"
                    && _varResponseStatusCode != "1002" && _varResponseStatusCode != "1003"
                    && _varResponseStatusCode != "1004" && _varResponseStatusCode != "2000"
                    && _varResponseStatusCode != "4000")
                {

                    XmlDocument objXMLDoc = new XmlDocument();
                    objXMLDoc.LoadXml(_strResultXML);

                    string _varCompanyIntelliScore = string.Empty;
                    string _varCompanyFSRScore = string.Empty;
                    string _varCompanyModelCode = string.Empty;
                    string _varCompanyScore = string.Empty;
                    string _varCompanyBIN = string.Empty;

                    XmlNodeList objProductsNode = objXMLDoc.GetElementsByTagName(_xnodProducts);
                    XmlNodeList objProductChildNode = objProductsNode[0].ChildNodes;

                    foreach (XmlNode objProduct in objProductChildNode)
                    {
                        if (objProduct.Name == _xnodPremierProfile)
                        {
                            XmlNodeList objIntellNode = objProduct.ChildNodes;
                            foreach (XmlNode objIntel in objIntellNode)
                            {
                                if (objIntel.Name == _xnodIntelliScoreInfo)
                                {
                                    XmlNodeList objIntelliScoreInforNode = objIntel.ChildNodes;
                                    foreach (XmlNode objCompanyTag in objIntelliScoreInforNode)
                                    {
                                        if (objCompanyTag.Name == _xnodModelInfo)
                                        {
                                            XmlNodeList objModelInfo = objCompanyTag.ChildNodes;
                                            foreach (XmlNode objModelCode in objModelInfo)
                                            {
                                                if (objModelCode.Name == _xnodModelCode)
                                                {
                                                    _varCompanyModelCode = objModelCode.InnerText;
                                                }

                                            }
                                        }
                                        else if (objCompanyTag.Name == _xnodScoreInfo)
                                        {
                                            XmlNodeList objScoreInfo = objCompanyTag.ChildNodes;
                                            foreach (XmlNode objScore in objScoreInfo)
                                            {
                                                if (objScore.Name == _xnodScore)
                                                {
                                                    _varCompanyScore = objScore.InnerText;
                                                }
                                                else if (objScore.Name == _xnodScoreSign)
                                                {
                                                    _varCompanyScore = objScore.InnerText + _varCompanyScore;
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (objIntel.Name == _xnodBusinessInfo)
                                {
                                    XmlNodeList objBusinessInfo = objIntel.ChildNodes;
                                    foreach (XmlNode objBusiness in objBusinessInfo)
                                    {
                                        if (objBusiness.Name == _xnodBusinessBIN)
                                        {
                                            _varCompanyBIN = objBusiness.InnerText;
                                        }
                                    }
                                }
                                #region Updating Transaction entity

                                if (entity.Attributes.Contains(_attrResponseModelCode))
                                    entity.Attributes[_attrResponseModelCode] = _varCompanyModelCode;
                                else
                                    entity.Attributes.Add(_attrResponseModelCode, _varCompanyModelCode);

                                if (entity.Attributes.Contains(_attrResponseScore))
                                    entity.Attributes[_attrResponseScore] = _varCompanyScore;
                                else
                                    entity.Attributes.Add(_attrResponseScore, _varCompanyScore);

                                if (entity.Attributes.Contains(_attrResponseBIN))
                                    entity.Attributes[_attrResponseBIN] = _varCompanyBIN;
                                else
                                    entity.Attributes.Add(_attrResponseBIN, _varCompanyBIN);

                                if (_varCompanyModelCode == "000223")
                                {
                                    _varCompanyFSRScore = _varCompanyScore;

                                    if ((int.Parse(_varCompanyFSRScore) / 100) > 0)
                                    {
                                        if (entity.Attributes.Contains(_attrResponseFSRScore))
                                            entity.Attributes[_attrResponseFSRScore] = (int.Parse(_varCompanyFSRScore) / 100);
                                        else
                                            entity.Attributes.Add(_attrResponseFSRScore, (int.Parse(_varCompanyFSRScore) / 100));
                                    }
                                    else
                                    {
                                        if (entity.Attributes.Contains(_attrResponseFSRScore))
                                            entity.Attributes[_attrResponseFSRScore] = int.Parse(_varCompanyFSRScore);
                                        else
                                            entity.Attributes.Add(_attrResponseFSRScore, int.Parse(_varCompanyFSRScore));
                                    }
                                }
                                if (_varCompanyModelCode == "000224")
                                {
                                    _varCompanyIntelliScore = _varCompanyScore;

                                    if (int.Parse(_varCompanyIntelliScore) > 0)
                                    {
                                        if (entity.Attributes.Contains(_attrResponseIntelliScore))
                                            entity.Attributes[_attrResponseIntelliScore] = (int.Parse(_varCompanyIntelliScore) / 100);
                                        else
                                            entity.Attributes.Add(_attrResponseIntelliScore, (int.Parse(_varCompanyIntelliScore) / 100));
                                    }
                                    else
                                    {
                                        if (entity.Attributes.Contains(_attrResponseIntelliScore))
                                            entity.Attributes[_attrResponseIntelliScore] = int.Parse(_varCompanyIntelliScore);
                                        else
                                            entity.Attributes.Add(_attrResponseIntelliScore, int.Parse(_varCompanyIntelliScore));
                                    }
                                }
                                #endregion
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            #endregion

        }

        #region HTTP(s) GET/ POST Data XML
        //HTTPRequest POST Data
        private string GetTransactionTypePOSTData(_enmTransaction _paramTransactionType)
        {
            string _strTransactionTypePOSTData = null;
            if (_paramTransactionType == _enmTransaction.ExperianCompanies)
            {
                _strTransactionTypePOSTData = @"<?xml version='1.0' encoding='UTF-8'?><NetConnectRequest
xmlns='http://www.experian.com/NetConnect'
xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'
xsi:schemaLocation='http://www.experian.com/NetConnect
NetConnect.xsd'>
<EAI>M5D1296Y</EAI>
	<DBHost>BISPROD</DBHost>
<ReferenceId>1</ReferenceId>
<Request>
<Products>
<PremierProfile>
<Subscriber>
<OpInitials>SO</OpInitials>
<SubCode>0688190</SubCode>
</Subscriber>
<BusinessApplicant>
                   
					<BusinessName>#BusinessName#</BusinessName>
					<CurrentAddress>
                        <Street>#Street#</Street>
						<City>#City#</City>
						<State>#State#</State>
						<Zip>#Zip#</Zip>
					</CurrentAddress>
 #TaxID#
				</BusinessApplicant>
<AddOns>
<List>Y</List>
</AddOns>
<OutputType>
<XML>
<Verbose>Y</Verbose>
</XML>
</OutputType>
<Vendor>
<VendorNumber>BIS041</VendorNumber>
</Vendor>
</PremierProfile>
</Products>
</Request>
</NetConnectRequest>";
            }
            if (_paramTransactionType == _enmTransaction.ExperianCreditScore)
            {
                _strTransactionTypePOSTData = @"<?xml version='1.0' encoding='UTF-8'?><NetConnectRequest
                xmlns='http://www.experian.com/NetConnect'
                xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'
                xsi:schemaLocation='http://www.experian.com/NetConnect
                NetConnect.xsd'>
                <EAI>M5D1296Y</EAI>
	                <DBHost>BISPROD</DBHost>
                <ReferenceId>1</ReferenceId>
                <Request>
                <Products>
                <ListOfSimilars>
                <Subscriber>
                <OpInitials>SO</OpInitials>
                <SubCode>0688190</SubCode>
                </Subscriber>
                <BusinessApplicant>
                <TransactionNumber>#TransNo#</TransactionNumber><BISListNumber>#FileNo##RecordNo#</BISListNumber>
                </BusinessApplicant>
                <AddOns>
                <BUSP>Y</BUSP>
                </AddOns>
                <OutputType>
                <XML>
                <Verbose>Y</Verbose>
                </XML>
                </OutputType>
                <Vendor>
                <VendorNumber>BIS041</VendorNumber>
                </Vendor>
                </ListOfSimilars>
                </Products>
                </Request>
                </NetConnectRequest>";
            }
            return _strTransactionTypePOSTData;
        }
        private string GetTransactionTypeResponse(string _paramServerURL, string _paramDataXML, _enmTransaction _paramTransactionType, ref ITracingService tracer)
        {
            try
            {
                tracer.Trace("starting GetTransactionTypeResponse");
                string _strRequestData = null;
                string _strResult = null;

                if (_paramTransactionType == _enmTransaction.ExperianCreditScore || _paramTransactionType == _enmTransaction.ExperianCompanies)
                {
                    _strRequestData = string.Format("{0}={1}", _strExperianDataPrefix, System.Web.HttpUtility.UrlEncode(_paramDataXML));
                    tracer.Trace("_strRequestData : " + _strRequestData);

                    HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(_paramServerURL);
                    objRequest.Method = "POST";
                    objRequest.ContentType = "application/x-www-form-urlencoded";

                    tracer.Trace("_strExperianCredentials : " + _strExperianCredentials);
                    tracer.Trace(" Base64 _strExperianCredentials : " + ConvertToBase64String(_strExperianCredentials));

                    objRequest.Headers.Add("Authorization", "BASIC " + ConvertToBase64String(_strExperianCredentials));
                    objRequest.Timeout = _intRequestTimeout;
                    objRequest.KeepAlive = false;
                    objRequest.Credentials = System.Net.CredentialCache.DefaultCredentials;

                    ASCIIEncoding _objEncoding = new ASCIIEncoding();
                    byte[] byteData;
                    byteData = _objEncoding.GetBytes(_strRequestData);

                    objRequest.AllowAutoRedirect = true;
                    objRequest.ContentLength = byteData.Length;

                    Stream _objRequestDataStream = objRequest.GetRequestStream();
                    _objRequestDataStream.Write(byteData, 0, byteData.Length);
                    _objRequestDataStream.Close();

                    HttpWebResponse _objResponse = (HttpWebResponse)objRequest.GetResponse();

                    Stream _objResponseStream = _objResponse.GetResponseStream();
                    StreamReader _objStreamReader = new StreamReader(_objResponseStream);
                    _strResult = _objStreamReader.ReadToEnd();
                    _objStreamReader.Close();
                    tracer.Trace("result");
                    tracer.Trace(_strResult);
                }
                return _strResult;
            }
            catch (Exception ex)
            {
                tracer.Trace("Get response");
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        #endregion

        #region Helpers
        //Base 64 convert routine
        private string ConvertToBase64String(string input)
        {
            //Encoding is in the System.Text Namespace
            byte[] info = Encoding.ASCII.GetBytes(input);
            //Convert the binary input into base 64 UUEncode output.
            //Each 3 byte sequence in the source data becomes a 4 byte
            //sequence in the character array.
            long dataLength = (long)((4.0d / 3.0d) * info.Length);
            //if length is not divisible by 4, go up to the next multiple of 4.
            if (dataLength % 4 != 0)
                dataLength += 4 - dataLength % 4;
            //Allocate the output buffer
            char[] base64CharArray = new char[dataLength];
            //converting.... (Convert is in the system namespace)
            Convert.ToBase64CharArray(info, 0, info.Length, base64CharArray, 0);
            //display the converted data
            return new string(base64CharArray);
        }

        private string GetServerURL(_enmTransaction _paramTransactionType)
        {
            StringBuilder objStringBuilder = new StringBuilder();
            string tempString = null;

            if (_paramTransactionType == _enmTransaction.ExperianCompanies || _paramTransactionType == _enmTransaction.ExperianCreditScore)
            {
                HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(_strExperianServerURL);
                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();

                if (!objResponse.ResponseUri.Host.EndsWith(_strExperianHostName))
                {
                    // ltrl.Text = "The hostname returned from ECALS must end with .experian.com";
                    return null;
                }

                // Create a buffer to store response stream.
                byte[] responseBuffer = new byte[1000];

                // build the response stream
                Stream objStream = objResponse.GetResponseStream();
                int bytesRead = 0;
                //int linecount =0;
                do
                {
                    // fill the buffer with data
                    bytesRead = objStream.Read(responseBuffer, 0, responseBuffer.Length);
                    // make sure we read some data
                    if (bytesRead != 0)
                    {
                        // translate from bytes to ASCII text
                        tempString = Encoding.ASCII.GetString(responseBuffer, 0, bytesRead);
                        objStringBuilder.Append(tempString);
                    }
                }
                while (bytesRead > 0); // any more data to read?
            }
            return tempString;
        }

        private EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue)
        {
            ColumnSet indexCol = new ColumnSet(true);

            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = indexCol;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }


        #endregion
    }
}
