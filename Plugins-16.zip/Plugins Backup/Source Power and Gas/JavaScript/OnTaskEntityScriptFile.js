﻿function onload() {
    onchange_regarding();
}
function OnRequestChange() {
    try {
        Xrm.Page.getAttribute("spg_queue").setValue(null);
        var _RequestTypeId = GetLookupFieldId("spg_requesttype");

        retrieveMultipleAsync("spg_requesttypeSet", "?$select=spg_Queue&$filter=spg_requesttypeId eq guid'" + _RequestTypeId + "'", RequestTypeCompleted, null);
    }
    catch (e)
    { console.log("OnRequestChang : " + e) }
}
function RequestTypeCompleted(data, textStatus, XmlHttpRequest) {
    try {

        if (data != null) {
            if (data.length > 0) {

                var _QueueId = data[0].spg_Queue.Id;
                var _QueueName = data[0].spg_Queue.Name;

                Xrm.Page.getAttribute("spg_queue").setValue([{
                    id: _QueueId,
                    name: _QueueName,
                    entityType: "queue"
                }]);
            }
        }
    }
    catch (e)
    { console.log("RequestTypeCompleted : " + e) }
}


function onchange_regarding() {
    var _RegardingId = GetLookupFieldId("regardingobjectid");
    var _RegardingName = GetLookupFieldName("regardingobjectid");
    var _RegardingType = null;
    if (_RegardingId != null) {
         _RegardingType = GetLookupFieldType("regardingobjectid");
        Xrm.Page.getAttribute("spg_regardingtype").setValue(_RegardingType);
    }
    if (_RegardingName != null)
        Xrm.Page.getAttribute("subject").setValue(_RegardingName);
    if (_RegardingId != null && _RegardingType == 3)
        retrieveMultipleAsync("OpportunitySet", "?$select=spg_BDM,spg_MarketRegion,spg_Type&$filter=OpportunityId eq guid'" + _RegardingId + "'", GetOpportunityDataCompleted, null);
}
function GetOpportunityDataCompleted(data, textStatus, XmlHttpRequest)
{
    try 
    {
        if (data != null)
        {
            if (data.length > 0)
            {
                var _BDMId = data[0].spg_BDM.Id;
                var _BDMName = data[0].spg_BDM.Name;
                var _MarketRegionId = data[0].spg_MarketRegion.Id;
                var _MarketRegionName = data[0].spg_MarketRegion.Name;
                var _OpportunityType = data[0].spg_Type.Value;
                if (_BDMId != null) {
                    Xrm.Page.getAttribute("spg_bdm").setValue([{
                        id: _BDMId,
                        name: _BDMName,
                        entityType: "systemuser"
                    }]);
                }
                if (_MarketRegionId != null)
                {
                    Xrm.Page.getAttribute("spg_marketregion").setValue([{
                        id: _MarketRegionId,
                        name: _MarketRegionName,
                        entityType: "spg_marketregion"
                    }]);
                }
                if (_OpportunityType != null)
                    Xrm.Page.getAttribute("spg_opportunitytype").setValue(_OpportunityType);
            }
        }
    }
    catch (e)
    { console.log("GetOpportunityDataCompleted :" + e); }
}