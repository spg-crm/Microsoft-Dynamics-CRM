﻿function switchProcess(processId) {
    console.log("fire switch process");
    if (processId != null) {
        console.log(processId);
        Xrm.Page.data.process.setActiveProcess(processId, switchProcessEnd);
    }
}

function switchProcessEnd(result) {
    console.log(result);
    if (result === "invalid") {
        Xrm.Page.ui.setFormNotification("Unable to switch to the new business process.", ERROR, "error");
    } else {
        Xrm.Page.ui.clearFormNotification("error");
    }
}

if (typeof (ns_opportunity) === "undefined") {
    ns_opportunity = {
        __namespace: true
    };
}
ns_opportunity = {
    ProcessId: null,
    getProcessId: function (processName) {
        Xrm.Page.data.process.getEnabledProcesses(function (processes) {
            for (var processId in processes) {
                console.log("loop pro cname :" + processes[processId]);
                if (processes[processId] === processName) {
                    ns_opportunity.ProcessId = processId;

                    switchProcess(ns_opportunity.ProcessId);
                }
            }
        });
    }
}

function pricingrequest2_Onchange() {
    if (Xrm.Page.getAttribute("spg_pricingrequest2").getValue() == true) {
        InitialQuote();
        console.log("fire onchange");
        ns_opportunity.getProcessId("Pricing Request");
    }
}

function contractcreated_Onchange() {
    if (Xrm.Page.getAttribute("spg_contractcreated").getValue() == 1)
        OpenTaskDialog();
    console.log("Fire Onchange");
}

function pricingcompletednotification_Onchange() {
    if (Xrm.Page.getAttribute("spg_pricingcompletednotification").getValue() == 1) {
        OfferCreatedDialog();
        Xrm.Page.data.process.moveNext();
        console.log("Fire Onchange")
    }
}


function requestpositioning_Onchange() {
    if (Xrm.Page.getAttribute("spg_requestpositioning").getValue() == 1) {
        CloseinPricingSolutionDialog();
        Xrm.Page.data.process.moveNext();
        console.log("Fire Onchange")
    }

}

function dealwonorlost_Onchange() {

}

function dealwonorlost_Onchange() {
    if (Xrm.Page.getAttribute("spg_dealwonorlost").getValue() == 2) {
        console.log("fire onchange");
        ns_opportunity.getProcessId("Deal Lost/Cancel");
    }
    else if (Xrm.Page.getAttribute("spg_dealwonorlost").getValue() == 1) {
        console.log("fire onchange");
        ns_opportunity.getProcessId("Contract Close-Won");
    }
}
function OpenTaskDialog() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={6A157EA4-3341-4EA1-A22B-86B82CB96640}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function OfferCreatedDialog() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={0DD576BE-BA7D-4375-94F0-47F82A9A355E}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function CloseinPricingSolutionDialog() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={698DF377-AF90-4FEF-B410-7C93DA7C095C}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function operationsreview_Onchange() {
    if (Xrm.Page.getAttribute("spg_operationsreview").getValue() == 1)
        CloseWonDialog();
    console.log("Fire Onchange");
}

function CloseWonDialog() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={194E8793-60EE-4549-8802-734F93A1C042}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function decisionmaker_Onchange() {


    if (Xrm.Page.getAttribute("decisionmaker").getValue() == true) {
        //RemoveRequirementLevel();
        Xrm.Page.data.process.moveNext();

        // moveToStage("Request Pricing");
    }
}

function creditcheckinitiated_Onchange() {
    if (Xrm.Page.getAttribute("spg_creditcheckinitiated").getValue() == 1) {
        // RemoveRequirementLevel();
        Xrm.Page.data.process.moveNext();
        console.log("Fire Onchange");
    }
}

function requestrefreshrequote_Onchange() {
    if (Xrm.Page.getAttribute("spg_requestrefreshrequote").getValue() == 2) {
        RequoteCreatedDialog();
        console.log("Fire Onchange")

    } else if (Xrm.Page.getAttribute("spg_requestrefreshrequote").getValue() == 1) {
        RefreshCreatedDialog();
        console.log("Fire Onchange")
    }
}

function RequoteCreatedDialog() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={ECCADEEB-9466-4BA8-8B52-92702A6383FC}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}


function RefreshCreatedDialog() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={8F95AE51-CC76-47F4-909D-99CF6F8D8ECC}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function generatecontratpjmonly_Onchange() {
    if (Xrm.Page.getAttribute("spg_generatecontratpjmonly").getValue() == 1)
        GeneratedContract();
    console.log("Fire Onchange");
}

function GeneratedContract() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={B4BF67E3-D3BC-4FB8-A6E0-17D821C0A710}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function contractcreated_Onchange() {
    if (Xrm.Page.getAttribute("spg_contractcreated").getValue() == 1)
        ContractCreated();
    console.log("Fire Onchange");
}

function ContractCreated() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={92A4075E-A1B6-4E90-BF51-47CCB2BACF72}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function dealvitalsdocumented_Onchange() {
    if (Xrm.Page.getAttribute("spg_dealvitalsdocumented").getValue() == 1) {
        Xrm.Page.data.process.moveNext();
        console.log("Fire Onchange");
    }
}

function InitialQuote() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={DF4A71F7-DB0B-49B6-AC0E-1ECBD50049D4}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function pricingrequest_Onchange() {
    if (Xrm.Page.getAttribute("spg_pricingrequest").getValue() == 1) {
        ReadyforPricing();
        Xrm.Page.data.process.moveNext();
        console.log("Fire Onchange");
    }
}

function ReadyforPricing() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={F393BF8A-DEDC-4E9D-A70F-97D4AD213558}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function readytoenroll_Onchange() {
    if (Xrm.Page.getAttribute("spg_readytoenroll").getValue() == 1) {
        Xrm.Page.data.process.moveNext();
        ReadytoEnroll();
        console.log("Fire Onchange");
    }
}

function ReadytoEnroll() {
    try {
        var url = "http://spgazcrm01/AZSPG/cs/dialog/rundialog.aspx?DialogId={DF229BDC-2F5D-42B8-AA30-100AA5FCF809}&EntityName=opportunity&ObjectId=" + Xrm.Page.data.entity.getId();

        var vWidth = 700;
        var vHeight = 620;
        var vLeft = (screen.width / 2) - (vWidth / 2);
        var vTop = (screen.height / 2) - (vHeight / 2);
        var features = "status=no,scrollbars=no,toolbars=no,menubar=no,location=no,resizable=0," + "height=" + vHeight + ",top=" + vTop + ",left=" + vLeft;

        window.open(url, "_blank", features, false);
    }
    catch (e)
    { console.log("OpenTaskDialog :" + e); }
}

function refreshrequotecompleted_Onchange() {
    if (Xrm.Page.getAttribute("spg_refreshrequotecompleted").getValue() == 1) {
        OfferCreatedDialog();
        console.log("Open Task Pop Up");
    }
}
function onMoveNext(returnStatus) {
    console.log("returnStatus " + returnStatus);
    switch (returnStatus) {
        case "success":
            break;
        case "crossEntity":
            break;
        case "end":
            break;
        case "invalid":
            break;

    }

}
function moveToStage(newStageName) {



    //get active stage

    var activeStage = Xrm.Page.data.process.getActiveStage();

    var activeStageName = activeStage.getName();

    //get a collection of stages currently in the active path

    var activePathCollection = Xrm.Page.data.process.getActivePath();

    //Enumerate the stages

    activePathCollection.forEach(function (stage, n) {

        var name = stage.getName();

        //search for specific stage by name

        if ((newStageName == name) && (newStageName != activeStageName)) {

            //move to the new stage
            console.log("stage.getId() " + stage.getId());
            var attributes = Xrm.Page.data.entity.attributes.get();
            for (var i in attributes)
                attributes[i].setSubmitMode("never");
            Xrm.Page.data.process.setActiveStage(stage.getId(), onSetActiveStage);

        }

    })

}
function RemoveRequirementLevel() {
    try {
        Xrm.Page.getAttribute("spg_type").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_stage").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_bdm").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_sourcemargin").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_leadsource").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_switchtype").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_marketregion").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_startmonthyear").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_brokerpaymethod").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_commodity").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_opportunityname").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_status").setRequiredLevel("none");
        Xrm.Page.getAttribute("spg_substatus").setRequiredLevel("none");
    }
    catch (e) {
        console.log("RemoveRequirementLevel:" + e);
    }
}
function SetRequirementLevel() {
    try {
        Xrm.Page.getAttribute("spg_type").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_stage").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_bdm").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_sourcemargin").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_leadsource").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_switchtype").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_marketregion").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_startmonthyear").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_brokerpaymethod").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_commodity").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_opportunityname").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_status").setRequiredLevel("required");
        Xrm.Page.getAttribute("spg_substatus").setRequiredLevel("required");
    }
    catch (e) {
        console.log("SetRequirementLevel:" + e);
    }
}
function OnLoad() {
    try {
        SetRequirementLevel();
        OnProcessStageChange();
        Xrm.Page.data.process.addOnStageChange(OnProcessStageChange);
    }
    catch (e)
    { console.log("OnLoad :" + e); }
}
function OnProcessStageChange() {
    try {

        console.log("Before set requirement level to required");


        var _SelectedStage = Xrm.Page.data.process.getSelectedStage();
        switch (_SelectedStage.getName()) {
            case "Request Pricing":
                SetRequirementLevel();
                break;
            case "Run Credit Check":
                SetRequirementLevel();
                break;
            case "Usage Available":
                SetRequirementLevel();
                break;
            default:
                break;
        }
    }

    catch (e) { console.log("OnProcessStageChange : " + e); }
}