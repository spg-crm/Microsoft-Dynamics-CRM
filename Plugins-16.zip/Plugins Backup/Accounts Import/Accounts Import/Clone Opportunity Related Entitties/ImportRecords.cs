﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Data;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;


namespace AccountsImport

{
    public class ImportRecords : CodeActivity
    {
        

       
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracer = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                EntityReference ImportAccountReference = importAccountReference.Get<EntityReference>(executionContext);
                EntityReference OpportunityReference = opportunityReference.Get<EntityReference>(executionContext);
                if (ImportAccountReference != null && ImportAccountReference.Id != Guid.Empty && OpportunityReference != null && OpportunityReference.Id != Guid.Empty)
                {
                    Entity notesEntityObject = GetCSVDocument(ref service, ImportAccountReference.Id);
                    DataTable dataTable = new DataTable();
                    string filePath = "C:\\Program Files (x86)\\Accounts Import File Folder\\";
                    if (notesEntityObject != null)
                    {
                        string documentBody = notesEntityObject.Attributes["documentbody"].ToString();
                        string mimeType = notesEntityObject.Attributes["mimetype"].ToString();
                        string fileName = notesEntityObject.Attributes["filename"].ToString();
                        byte[] fileContents = Convert.FromBase64String(documentBody);
                        using (FileStream fileStream = new FileStream(filePath + fileName, FileMode.OpenOrCreate,FileAccess.ReadWrite))
                        {
                            byte[] fileContent = Convert.FromBase64String(documentBody);
                            fileStream.Write(fileContent, 0, fileContent.Length);
                        }

                        dataTable = ConvertCSVtoDataTable(filePath + fileName);//This method read the data from tab delimited file and convert it inot DataTable...
                        ProcessDataTable(dataTable, ref service, OpportunityReference);//This method reads data from datatable and create record in Accounts Entity
                        File.Delete(filePath + fileName);//For delete file....
                    }

                }

            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
       
        private void CreateAccountsRecord(EntityReference MarketerReference, string AccountNumber, string CustomerName, int HistoricalUsage, string PostalCode, string City, string StateName, string CountyName, string Address1, EntityReference BillMethodDesc, ref IOrganizationService service, EntityReference OpportunityReference, EntityReference UtilityReference)
        {
            Entity entity = new Entity("spg_account");
            if (MarketerReference != null && MarketerReference.Id != Guid.Empty)
            {
                entity.Attributes.Add("spg_marketer", MarketerReference);
            }
            entity.Attributes.Add("spg_ldcaccountnumber", AccountNumber);
            entity.Attributes.Add("spg_customername", CustomerName);
            if (HistoricalUsage > 0)
            {
                entity.Attributes.Add("spg_historicalusage", new OptionSetValue(HistoricalUsage));
            }
            entity.Attributes.Add("spg_address1_postalcode", PostalCode);
            entity.Attributes.Add("spg_address1_city", City);
            entity.Attributes.Add("spg_address1_state", StateName);
            entity.Attributes.Add("spg_address1_county", CountyName);
            entity.Attributes.Add("spg_adressline1", Address1);
            if (UtilityReference != null && UtilityReference.Id != Guid.Empty)
            {
                entity.Attributes.Add("spg_utility", UtilityReference);
            }
            if (BillMethodDesc != null && BillMethodDesc.Id != Guid.Empty)
            {
                entity.Attributes.Add("spg_billmethoddesc", BillMethodDesc);
            }
            Guid accountsId = service.Create(entity);
            if (accountsId != Guid.Empty)
            {
                EntityReference accountsReference = new EntityReference("spg_account", accountsId);
                AccountsAssociationWithOpportunity(OpportunityReference, accountsReference, ref service);
            }
        }
        private DataSet DeserailizeByteArrayToDataSet(byte[] byteArrayData)
        {
            DataSet tempDataSet = new DataSet();
            DataTable dt;
            // Deserializing into datatable    
            using (MemoryStream stream = new MemoryStream(byteArrayData))
            {
                BinaryFormatter bformatter = new BinaryFormatter();
                dt = (DataTable)bformatter.Deserialize(stream);
               
            }
            // Adding DataTable into DataSet    
            tempDataSet.Tables.Add(dt);
            return tempDataSet;
        }

        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            StreamReader sr = new StreamReader(strFilePath);
             string[] headers = sr.ReadLine().Split('\t');//Tab Delimited
            DataTable dt = new DataTable();
            foreach (string header in headers)
            {
                dt.Columns.Add(header);
            }
            while (!sr.EndOfStream)
            {
                string[] rows = sr.ReadLine().Split('\t');//Tab Delimited
                DataRow dr = dt.NewRow();
                for (int i = 0; i < headers.Length; i++)
                {
                    dr[i] = rows[i];
                }
                dt.Rows.Add(dr);
            }
            sr.Close();
            return dt;
        }
        private static Entity GetCSVDocument(ref IOrganizationService service, Guid RegardingId)
        {
            Entity vzEntity = null;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "annotation";
            indexattribute.Attributes.AddRange(new string[] { "objectid" });
            indexattribute.Values.AddRange(new object[] { RegardingId });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
                vzEntity = index.Entities[0];

            return vzEntity;
        }
        private static EntityReference GetMarketerReference(ref IOrganizationService service, string MarketerName)
        {
            Entity vzEntity = null;
            EntityReference marketerreference = null;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_marketer";
            indexattribute.Attributes.AddRange(new string[] { "spg_name" });
            indexattribute.Values.AddRange(new object[] { MarketerName });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
                vzEntity = index.Entities[0];
            if (vzEntity.Attributes.Contains("spg_marketerid"))
            {
                marketerreference = new EntityReference(vzEntity.LogicalName, vzEntity.Id);
            }
            return marketerreference;
        }
        private static EntityReference GetBillMethodReference(ref IOrganizationService service, string BillMethodName)
        {
            Entity vzEntity = null;
            EntityReference billMethodReference = null;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_billingtypes";
            indexattribute.Attributes.AddRange(new string[] { "spg_name" });
            indexattribute.Values.AddRange(new object[] { BillMethodName });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
                vzEntity = index.Entities[0];
            if (vzEntity.Attributes.Contains("spg_billingtypesid"))
            {
                billMethodReference = new EntityReference(vzEntity.LogicalName, vzEntity.Id);
            }
            return billMethodReference;
        }
        private static bool GetAccounts(ref IOrganizationService service, string AccountNumber, string CustomerName, Guid UtilityId)
        {
            bool IsExist = false;
            if (UtilityId != Guid.Empty)
            {
                Entity vzEntity = null;
                
                ColumnSet Indexcol = new ColumnSet(true);
                QueryByAttribute indexattribute = new QueryByAttribute();
                indexattribute.EntityName = "spg_account";
                indexattribute.Attributes.AddRange(new string[] { "spg_name", "spg_customername", "spg_utility" });
                indexattribute.Values.AddRange(new object[] { AccountNumber, CustomerName, UtilityId });
                indexattribute.ColumnSet = Indexcol;
                RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
                req_index.Query = indexattribute;
                RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
                EntityCollection index = resp_index.EntityCollection;
                if (index != null && index.Entities.Count > 0)
                    vzEntity = index.Entities[0];
                if (vzEntity != null && vzEntity.Attributes.Contains("spg_accountid"))
                {
                    IsExist = true;
                }
            }
            return IsExist;
        }

        private static bool CheckIsAccountAssociated(ref IOrganizationService service, Guid opportunityId, Guid accountId)
        {
            Entity vzEntity = null;
            bool IsExist = false;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_opportunity_spg_account";
            indexattribute.Attributes.AddRange(new string[] { "opportunityid", "spg_accountid" });
            indexattribute.Values.AddRange(new object[] { opportunityId , accountId });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
                vzEntity = index.Entities[0];
            if (vzEntity != null && vzEntity.Attributes.Contains("spg_accountid"))
            {
                IsExist = true;
            }
            return IsExist;
        }

        private static Entity GetAccountRecords(ref IOrganizationService service, string AccountNumber)
        {
            Entity vzEntity = null;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_account";
            indexattribute.Attributes.AddRange(new string[] { "spg_name" });
            indexattribute.Values.AddRange(new object[] { AccountNumber });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                vzEntity = index.Entities[0];
            }
            
            return vzEntity;
        }

        private void AssociateManyToManyEntityRecords(Microsoft.Xrm.Sdk.EntityReference moniker1, Microsoft.Xrm.Sdk.EntityReference moniker2, string strEntityRelationshipName, ref IOrganizationService service)

        {
            bool Flag = CheckIsAccountAssociated(ref service, moniker1.Id, moniker2.Id);
            if (Flag == false)
            {
                AssociateEntitiesRequest request = new AssociateEntitiesRequest();
                request.Moniker1 = new EntityReference { Id = moniker1.Id, LogicalName = moniker1.LogicalName };
                request.Moniker2 = new EntityReference { Id = moniker2.Id, LogicalName = moniker2.LogicalName };
                request.RelationshipName = strEntityRelationshipName;
                service.Execute(request);
            }

        }
        private void AccountsAssociationWithOpportunity(EntityReference OpportunityReference, EntityReference AccountReference, ref IOrganizationService service)
        {
            AssociateManyToManyEntityRecords(OpportunityReference, AccountReference, "spg_opportunity_spg_account", ref service);
        }
        private void ProcessDataTable(DataTable datatable, ref IOrganizationService service, EntityReference OpportunityReference)
        {
            for (int i = 0; i < datatable.Rows.Count; i++)
            {
                EntityReference marketerReference = null;
                EntityReference billMethodReference = null;
                EntityReference utilityReference = null;
                int historicalUsageValue = 0;
                string marketerName = datatable.Rows[i]["Marketer_Name"].ToString();
                string territoryCode = datatable.Rows[i]["Territory_Code"].ToString();
                string ldcAccountNumber = datatable.Rows[i]["LDC_Account_Num"].ToString();
                string historicalUsage = datatable.Rows[i]["Historical_Usage_Desc"].ToString();
                string postalCode = datatable.Rows[i]["Postal_Code"].ToString();
                string cityName = datatable.Rows[i]["City_Name"].ToString();
                string stateName = datatable.Rows[i]["State_Name"].ToString();
                string billMethodDesc = datatable.Rows[i]["Bill_Method_Desc"].ToString();
                string customerName = datatable.Rows[i]["Customer_Name"].ToString();
                string countyName = datatable.Rows[i]["County_Name"].ToString();
                string address1 = datatable.Rows[i]["Ln1_Addr"].ToString();
                string requestDate = datatable.Rows[i]["Requested_Start_Date"].ToString();
                Entity utilityEntityObject = null;

            
            
                    if (customerName.Contains("\""))//Removing Double Quotes...
                    {
                        customerName = customerName.Replace("\"", "");
                    }
                    customerName = removeSpecialCharacters(customerName);
                    if (cityName.Contains("\""))//Removing Double Quotes...
                    {
                        cityName = cityName.Replace("\"", "");
                    }
                    if (cityName.Contains(","))//Removing Commas...
                    {
                        cityName = cityName.Replace(",", "");
                    }
                    cityName = removeSpecialCharacters(cityName);//Removing Special Characters...
                    stateName = removeSpecialCharacters(stateName);//Removing Special Characters...
                    countyName = removeSpecialCharacters(countyName);//Removing Special Characters...

                if (address1.Contains("\""))//Removing Double Quotes...
                    {
                        address1 = address1.Replace("\"", "");
                    }
                    address1 = removeSpecialCharacters(address1);
                   
                    if (marketerName.Length > 0)
                    {
                        marketerReference = GetMarketerReference(ref service, marketerName);

                    }
                    if (territoryCode.Length > 0)
                    {
                        utilityEntityObject = GetUtilityEntity(ref service, territoryCode);
                        if (utilityEntityObject != null && utilityEntityObject.Id != Guid.Empty)
                        {
                            utilityReference = new EntityReference(utilityEntityObject.LogicalName, utilityEntityObject.Id);
                        }
                    }

                    if (historicalUsage == "Monthly")
                        historicalUsageValue = 1;
                    else if (historicalUsage == "Interval")
                        historicalUsageValue = 2;
                    if (billMethodDesc.Length > 0)
                    {
                        billMethodReference = GetBillMethodReference(ref service, billMethodDesc);
                    }
                  
                    if (ldcAccountNumber != string.Empty && ldcAccountNumber != null && ldcAccountNumber.Length > 0)
                    {
                        bool IsRecordExist = GetAccounts(ref service, ldcAccountNumber, customerName, utilityEntityObject.Id);//Check if Account is already Exist...
                        if (IsRecordExist == false)
                        {
                            CreateAccountsRecord(marketerReference, ldcAccountNumber, customerName, historicalUsageValue, postalCode, cityName, stateName, countyName, address1, billMethodReference, ref service, OpportunityReference, utilityReference);
                        }
                        else
                        {
                            //If Account is already exist then associate it with opportunity...
                            Entity accountsEntityObject = GetAccountRecords(ref service, ldcAccountNumber);
                            if (accountsEntityObject != null && accountsEntityObject.Id != Guid.Empty)
                            {
                                AccountsAssociationWithOpportunity(OpportunityReference, new EntityReference(accountsEntityObject.LogicalName, accountsEntityObject.Id), ref service);
                            }
                        }
                    }
                
                }
         
        }
       
        private Entity GetUtilityEntity(ref IOrganizationService service, string TerritoryCode)
        {
            Entity entity = null;

            ColumnSet Indexcol = new ColumnSet(new string[] { "spg_utilityid" });
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_utility";
            indexattribute.Attributes.AddRange(new string[] { "spg_territorycode" });
            indexattribute.Values.AddRange(TerritoryCode);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                entity = (Entity)index.Entities[0];

            }
            return entity;
        }

        private string removeSpecialCharacters(string Input)
        {
            string[] chars = new string[] { "~", "@", "#", "$", "^", "*", "(", ")" };
            for (int i = 0; i < chars.Length; i++)
            {
                if (Input.Contains(chars[i]))
                {
                    Input = Input.Replace(chars[i], "");
                }
            }
            return Input;
        }
        private  bool GettingNumbersOnly(string Numbers)
        {
            Regex rg = new Regex(@"^[0-9\s,]*$");

            if (rg.IsMatch(Numbers))
            {
                return false;
            }
            return true;
        }
        private void UpdateNumberofMeters(ref IOrganizationService service, EntityReference Opportunity )
        {
            int count = GetAccountsCount(ref service, Opportunity.Id);
            Entity OpportunityEntity = new Entity("opportunity");
            OpportunityEntity.Id = Opportunity.Id;
            OpportunityEntity.Attributes.Add("spg_numberofmeters", count);
            service.Update(OpportunityEntity);
        }
        private static int GetAccountsCount(ref IOrganizationService service, Guid OpportunityId)
        {
            
            int count = 0;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_opportunity_spg_account";
            indexattribute.Attributes.AddRange(new string[] { "opportunityid" });
            indexattribute.Values.AddRange(new object[] { OpportunityId });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                count = index.Entities.Count;
            }

            return count;
        }

        [Input("Import Accounts Id")]
        [ReferenceTarget("spg_importaccounts")]
        public InArgument<EntityReference> importAccountReference { get; set; }

        [Input("Opportunity Id")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> opportunityReference { get; set; }


    }
}
