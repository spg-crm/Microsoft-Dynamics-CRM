﻿using System;
using System.Xml;
using System.IO;
using System.Net;
using System.Net.Security;
using Microsoft.Xrm.Sdk;
using System.Data;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel.Description;
using Microsoft.Crm.Sdk.Messages;
using System.Configuration;

namespace SPGOppStatusUpdateConsoleApp
{
    class OpportunityStatusList
    {

        private string _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
        private string _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");
        private string oppid = "B3613D4D-DE89-E511-80CA-000D3A90E5FA";
        #region Class attributes used to integration opportunity to ESG Portal
        private string opportunity_Tkn = string.Empty;
        private string url = string.Empty;
        private string userId = string.Empty;
        private string password = string.Empty;
        private string service_parameters = string.Empty;
        private string service_data = string.Empty;

        private string logon_Userid = string.Empty;
        private string logon_Password = string.Empty;
        private string company_ID = string.Empty;


        private string opp_ID = string.Empty;
        private string customer_Name = string.Empty;
        private string contract_Start_Date = string.Empty;
        private string contract_Retail_Adder = string.Empty;
        private string contract_Rate = string.Empty;
        private string date_Priced = string.Empty;
        private string Product = string.Empty;
        private string product_Name = string.Empty;
        private string Term = string.Empty;
        private string payment_Terms = string.Empty;
        private string close_Date = string.Empty;
        private string meter_Fee = string.Empty;
        private string contract_ID = string.Empty;
        private string quote_ID = string.Empty;
        private string broker_Fee = string.Empty;
        private string source_Margin = string.Empty;
        private string source_Margin_UOM = string.Empty;
        private string annula_MWH = string.Empty;
        private string term_MWH = string.Empty;
        private string contract_Create_Date_Time = string.Empty;
        private string contract_Status = string.Empty;

        private int row_limit;
        private DateTime update_start_date;

        XmlDocument xmlResponse = null;

        #endregion

        #region Get/Set methods for attributes
        public string Opportunity_Tkn
        {
            get
            {
                return opportunity_Tkn;
            }

            set
            {
                opportunity_Tkn = value;
            }
        }

        public string Url
        {
            get
            {
                return url;
            }

            set
            {
                url = value;
            }
        }

        public string UserId
        {
            get
            {
                return userId;
            }

            set
            {
                userId = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Service_parameters
        {
            get
            {
                return service_parameters;
            }

            set
            {
                service_parameters = value;
            }
        }

        public string Service_data
        {
            get
            {
                return service_data;
            }

            set
            {
                service_data = value;
            }
        }

        public XmlDocument XmlResponse
        {
            get
            {
                return xmlResponse;
            }

            set
            {
                xmlResponse = value;
            }
        }

        public int Row_limit
        {
            get
            {
                return row_limit;
            }

            set
            {
                row_limit = value;
            }
        }

        public DateTime Update_start_date
        {
            get
            {
                return update_start_date;
            }

            set
            {
                update_start_date = value;
            }
        }

        public string Logon_Userid
        {
            get
            {
                return logon_Userid;
            }

            set
            {
                logon_Userid = value;
            }
        }

        public string Logon_Password
        {
            get
            {
                return logon_Password;
            }

            set
            {
                logon_Password = value;
            }
        }

        public string Company_ID
        {
            get
            {
                return company_ID;
            }

            set
            {
                company_ID = value;
            }
        }
        #endregion

        public OpportunityStatusList()
        {

        }

        public void FetchContractDetails()
        {
            string service_param = string.Empty;
            string myservice_data = string.Empty;

            #region Dynamic Parametrs
            string _OppToken = string.Empty;
            //string _ProcessType = string.Empty;
            //string _DistributorName = string.Empty;
            //string _LDCAccountNum = string.Empty;
            //string _CustomerName = string.Empty;
            //string _AccountName = string.Empty;
            //string _EquipmentID = string.Empty;
          
            //string _FirstName = string.Empty;
            //string _LastName = string.Empty;
            //string _RevenueClass = string.Empty;
            //string _PostalCode = string.Empty;
            //string _CityName = string.Empty;
            //string _Line1 = string.Empty;
            //string _Line2 = string.Empty;
            //string _State = string.Empty;
            //string _Country = string.Empty;
            //string _BillMethod = string.Empty;
            //string _ServiceAddress = string.Empty;
            //string _CustomerProspectToken = string.Empty;
            //string _CustomerAccountToken = string.Empty;
            //string _OppProspectToken = string.Empty;

            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.
            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = Program.DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = Program.FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                //organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    #region Loop through opportunities dataset to update status in CRM
                    //RetrieveMultipleRequest req = new RetrieveMultipleRequest();
                    //FetchExpression fetch = new FetchExpression("<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                    //                "<entity name ='opportunity'>" +
                    //                "<attribute name='spg_opportunityname'/>" +
                    //                "<attribute name ='statuscode'/>" +
                    //                //"<attribute name ='opportunityid'/>" +
                    //                //"<attribute name ='ownerid'/>" +
                    //                "<order attribute ='spg_opportunityname' descending ='false'/>" +
                    //                "</entity>" +
                    //                "</fetch>");
                    //req.Query = fetch;
                    //RetrieveMultipleResponse resp = (RetrieveMultipleResponse)service.Execute(req);
                    _OppToken = "859906634";
                    service_param = "<serviceParameters>" +
                                           "<logonUserid>webcrm</logonUserid>" +
                                           "<logonPassword>webcrm</logonPassword>" +
                                           "<companyID>CW_SOURCE</companyID>" +
                                           "<partName>Opportunity.Opportunity_Task_Create_New</partName>" +
                                           "<partFunction>process</partFunction>";
                                          
                    service_param +=       "<partTokens>Opportunity_Tkn=" + _OppToken + "</partTokens>" +
                                           "<partSearch></partSearch>" +
                                           "<partOrder></partOrder>" +
                                           "</serviceParameters>";
                    ColumnSet colset = new ColumnSet(new string[] {"spg_accountid"});
                    EntityCollection tempaccountcollection = GetEntityRecords(ref service, "spg_opportunity_spg_account", "opportunityid", "A0FE5A11-DE89-E511-80CA-000D3A90E5FA", colset);
                    foreach(Entity tempaccountentity  in tempaccountcollection.Entities)
                    {
                        EntityCollection accountcollection = GetEntityRecords(ref service,"spg_account","spg_accountid",tempaccountentity["spg_accountid"].ToString());
                        foreach (Entity account in accountcollection.Entities)
                        {
                            string _HistoricalUsage = string.Empty;
                            string _RequestStart = string.Empty;
                            string accountNumber = string.Empty;
                            string customerName = string.Empty;
                            string postalCode = string.Empty;
                            string cityName = string.Empty;
                            string stateName = string.Empty;
                            string billMethodDescription = string.Empty;

                            OptionSetValue _Historicalusagevalue = account.Attributes["spg_historicalusage"] as OptionSetValue;
                            if (_Historicalusagevalue.Value > 0)
                            {
                                _HistoricalUsage = GetOptionsSetTextForValue(service, "spg_account", "spg_historicalusage", _Historicalusagevalue.Value);
                            }

                            if (account.Attributes.Contains("spg_requestedstartdate"))
                            {
                                _RequestStart = account["spg_requestedstartdate"].ToString();
                            }

                            if (account.Attributes.Contains("spg_ldcaccountnumber"))
                            {
                                accountNumber = account["spg_ldcaccountnumber"].ToString();
                            }

                            if (account.Attributes.Contains("spg_customername"))
                            {
                                customerName = account["spg_customername"].ToString();
                            }

                            if (account.Attributes.Contains("spg_address1_postalcode"))
                            {
                                postalCode = account["spg_address1_postalcode"].ToString();
                            }
                            if (account.Attributes.Contains("spg_address1_city"))
                            {
                                cityName = account["spg_address1_city"].ToString();
                            }
                            if (account.Attributes.Contains("spg_address1_state"))
                            {
                                stateName = account["spg_address1_state"].ToString();
                            }
                            if (account.Attributes.Contains("spg_billmethoddesc"))
                            {
                                billMethodDescription = ((EntityReference)account["spg_billmethoddesc"]).Name;
                            }
                            myservice_data = "<serviceData>" +
                               "<Process_Type>SaveAccount</Process_Type>" +
                               "<Distributor_Name></Distributor_Name>" +
                               "<LDC_Account_Num>" + accountNumber + "</LDC_Account_Num>" +
                               "<Customer_Name>" + customerName + "</Customer_Name>" +
                               "<Account_Name></Account_Name>" +
                               "<Equipment_Id_Code></Equipment_Id_Code>" +
                               "<Historical_Usage_Desc>" + _HistoricalUsage + "</Historical_Usage_Desc>" +
                               "<Service_Type_Desc></Service_Type_Desc>" +
                               "<Requested_Start_Date>" + _RequestStart + "</Requested_Start_Date>" +
                               "<First_Name></First_Name>" +
                               "<Last_Name></Last_Name>" +
                               "<Revenue_Class_Desc></Revenue_Class_Desc>" +
                               "<Postal_Code>"+ postalCode + "</Postal_Code>" +
                               "<City_Name>" + cityName+ "</City_Name>" +
                               "<Ln1_Addr></Ln1_Addr>" +
                               "<Ln2_Addr></Ln2_Addr>" +
                               "<State_Name>" + stateName + "</State_Name>" +
                               "<State_Name>Texas</State_Name>" +

                               "<County_Name></County_Name>" +
                               "<Bill_Method_Desc>" + billMethodDescription  +"</Bill_Method_Desc>" +
                               "<Service_Address></Service_Address>" +
                               "<Status_Desc></Status_Desc>" +
                               "<Customer_Prospect_Tkn></Customer_Prospect_Tkn>" +
                               "<Customer_Prospect_Account_Tkn></Customer_Prospect_Account_Tkn>" +
                               "<Opportunity_Account_Tkn></Opportunity_Account_Tkn>" +
                               "</serviceData>";
                            XmlResponse = Program.HttpSOAPRequest("https://208.253.5.105/P2CAppSource/services/VersatilityWebServiceProxy", service_param, myservice_data);
                        }
                    }
                    
                }

                #endregion
            }



            

               
            #endregion
            
            try
            {
                
               //string[] array = new string[67];
               // for (int i = 0; i < array.Length; i++)
               // {
                 
                   
               // }
                //if (opportunity_Tkn != string.Empty)
                //{
                //    service_parameters = "<serviceParameters>" +
                //                            "<logonUserid> webcrm </logonUserid>" +
                //                            "<logonPassword> webcrm </logonPassword>" +
                //                            "<companyID>CW_SOURCE</companyID>" +
                //                            "<partName>Opportunity.Opportunity_List</partName>" +
                //                            string.Format("<partTokens>Opportunity_Tkn={0}</partTokens>", opportunity_Tkn) +
                //                            "<partFunction>list</partFunction>" +
                //                            string.Format("<partSearch>&lt;field rowLimit='{0}' name='Update_Start_Date_Sc' value='{1}' operator='=' ignoreCase='false' soundex='false'/&gt;</partSearch>", row_limit, update_start_date.ToString("yyyy-MM-dd")) +
                //                            "<partOrder></partOrder>" +
                //                            "</serviceParameters>";
                //}
                    //service_param = "<serviceParameters>" +
                    //                        "<logonUserid>webcrm</logonUserid>" +
                    //                        "<logonPassword>webcrm</logonPassword>" +
                    //                        "<companyID>CW_SOURCE</companyID>" +
                    //                        "<partName>Opportunity.Opportunity_Task_Create_New</partName>" +
                    //                        "<partTokens>Opportunity_Tkn=859906634</partTokens>" +
                    //                        "<partFunction>process</partFunction>" +
                    //                        "<partSearch></partSearch>" +
                    //                        "<partOrder></partOrder>" +
                    //                        "</serviceParameters>";
                //       137279 - 3910
                //1052868
                //137140
               

               

                //if (XmlResponse != null)
                //{
                //    string MyResponse = XmlResponse.InnerXml;
                //    Console.WriteLine(MyResponse);
                //    MyResponse = MyResponse.Replace(":", "_");

                //    XmlDocument xmlDoc = new XmlDocument();
                //    xmlDoc.LoadXml(MyResponse);

                //    XmlNode logonuserid = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceParameters/logonUserid");
                //    XmlNode logonpassword = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceParameters/logonPassword");
                //    XmlNode companyid = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceParameters/companyID");
                //    XmlNode oppID = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceParameters/partName");
                //    XmlNode customerName = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/cust_name");
                //    XmlNode contractStartDate = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_start_date");
                //    XmlNode contractRetailAdder = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_retail_adder");
                //    XmlNode contractRate = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_rate");
                //    XmlNode datePriced = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/date_priced");
                //    XmlNode product = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/product");
                //    XmlNode productName = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/product_name");
                //    XmlNode term = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/term");
                //    XmlNode paymentTerms = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/payment_terms");
                //    XmlNode closeDate = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/close_date");
                //    XmlNode meterFee = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/meter_fee");
                //    XmlNode contracID = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_id");
                //    XmlNode quoteID = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/quote_id");
                //    XmlNode brokerFee = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/broker_fee");
                //    XmlNode sourceMargin = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/source_margin");
                //    XmlNode sourceMarginUOM = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/source_margin_uom");
                //    XmlNode annulaMWH = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/annual_mwh");
                //    XmlNode termMWH = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/term_mwh");
                //    XmlNode contractCreateDateTime = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_create_date_time");
                //    XmlNode contractStatus = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_status");





                //    //XmlNode statusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Status_Desc");
                //    //XmlNode subStatusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Sub_Status_Desc");

                //    if (logonuserid.InnerText != "")
                //        logon_Userid = logonuserid.InnerText;

                //    if (logonpassword.InnerText != "")
                //        logon_Password = logonpassword.InnerText;

                //    if (companyid.InnerText != "")
                //        company_ID = companyid.InnerText;

                //    if (oppID.InnerText != "")
                //        opp_ID = oppID.InnerText;

                //    if (customerName.InnerText != "")
                //        customer_Name = customerName.InnerText;

                //    if (contractStartDate.InnerText != "")
                //        contract_Start_Date = contractStartDate.InnerText;

                //    if (contractRetailAdder.InnerText != "")
                //        contract_Retail_Adder = contractRetailAdder.InnerText;

                //    if (contractRate.InnerText != "")
                //        contract_Rate = contractRate.InnerText;

                //    if (datePriced.InnerText != "")
                //        date_Priced = datePriced.InnerText;

                //    if (product.InnerText != "")
                //        Product = product.InnerText;

                //    if (productName.InnerText != "")
                //        product_Name = productName.InnerText;

                //    if (term.InnerText != "")
                //        Term = term.InnerText;

                //    if (paymentTerms.InnerText != "")
                //        payment_Terms = paymentTerms.InnerText;

                //    if (closeDate.InnerText != "")
                //        close_Date = closeDate.InnerText;

                //    if (meterFee.InnerText != "")
                //        meter_Fee = meterFee.InnerText;

                //    if (contracID.InnerText != "")
                //        contract_ID = contracID.InnerText;

                //    if (quoteID.InnerText != "")
                //        quote_ID = quoteID.InnerText;

                //    if (brokerFee.InnerText != "")
                //        broker_Fee = brokerFee.InnerText;

                //    if (sourceMargin.InnerText != "")
                //        source_Margin = sourceMargin.InnerText;

                //    if (sourceMarginUOM.InnerText != "")
                //        source_Margin_UOM = sourceMarginUOM.InnerText;

                //    if (annulaMWH.InnerText != "")
                //        annula_MWH = annulaMWH.InnerText;

                //    if (termMWH.InnerText != "")
                //        term_MWH = termMWH.InnerText;

                //    if (contractCreateDateTime.InnerText != "")
                //        contract_Create_Date_Time = contractCreateDateTime.InnerText;

                //    if (contractStatus.InnerText != "")
                //        contract_Status = contractStatus.InnerText;


                //    //if (statusDesc.InnerText != "")
                //    //    status_Desc = statusDesc.InnerText;

                //    //if (subStatusDesc.InnerText != "")
                //    //    sub_Status_Desc = subStatusDesc.InnerText;

                //    //if (Convert.ToInt32(returnCode.InnerText) == (int)ESGWebServiceReturnCode.TaskCompletedOk)
                //    //{
                //    //    XmlNode opportunityToken = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_Tkn");
                //    //    XmlNode opportunityId = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_ID");

                //    //    if (opportunityId.InnerText != "")
                //    //        opportunity_ID = opportunityId.InnerText;

                //    //    if (opportunityToken.InnerText != "")
                //    //        opportunity_Tkn = opportunityToken.InnerText;

                //    //    return true;
                //    //}
                //    //else
                //    //{
                //    //    return false;
                //    //}

                //    //return true;
                //}
                //else
                //{
                //    //return false;
                //}
            }
            catch (Exception ex)
            {
                string mymsg = string.Empty;

                mymsg = mymsg + "https://208.253.5.105/P2CAppSource/services/VersatilityWebServiceProxy";
                mymsg = mymsg + "webcrm";
                mymsg = mymsg + "webcrm";

                throw new Exception(string.Format("Error occured {0}", ex.ToString()));


                if (XmlResponse != null)
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, xmlResponse.InnerXml);
                }
                else
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, ErrorMessage);
                }
                //return false;
            }
        }

        private static string GetOptionsSetTextForValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = null;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.LocalizedLabels[0].Label.ToString();
                    break;
                }
            }
            return selectedOptionLabel;
        }

        private static EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = columnSet;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private static EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue)
        {
            ColumnSet indexCol = new ColumnSet(true);

            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = indexCol;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }


        public Boolean GetOpportunityStatus()
        {
            try
            {
                if (opportunity_Tkn != String.Empty)
                {
                    service_parameters = "<serviceParameters>" +
                                            "<logonUserid>" + userId + "</logonUserid>" +
                                            "<logonPassword>" + password + "</logonPassword>" +
                                            "<companyID>CW_SOURCE</companyID>" +
                                            "<partName>Opportunity.Opportunity_List</partName>" +
                                            String.Format("<partTokens>Opportunity_Tkn={0}</partTokens>", opportunity_Tkn) +
                                            "<partFunction>list</partFunction>" +
                                            String.Format("<partSearch>&lt;field rowLimit='{0}' name='Update_Start_Date_Sc' value='{1}' operator='=' ignoreCase='false' soundex='false'/&gt;</partSearch>", row_limit, update_start_date.ToString("yyyy-MM-dd")) +
                                            "<partOrder></partOrder>" +
                                            "</serviceParameters>";
                }
                else
                {
                    service_parameters = "<serviceParameters>" +
                                            "<logonUserid>" + userId + "</logonUserid>" +
                                            "<logonPassword>" + password + "</logonPassword>" +
                                            "<companyID>CW_SOURCE</companyID>" +
                                            "<partName>Opportunity.Opportunity_List</partName>" +
                                            "<partTokens>Opportunity_Tkn=</partTokens>" +
                                            "<partFunction>list</partFunction>" +
                                            String.Format("<partSearch>&lt;field rowLimit='{0}' name='Update_Start_Date_Sc' value='{1}' operator='=' ignoreCase='false' soundex='false'/&gt;</partSearch>", row_limit, update_start_date.ToString("yyyy-MM-dd")) +
                                            //"<partSearch>\"<field rowLimit='500' name='Update_Start_Date_Sc' value='2015-10-01' operator='=' ignoreCase='false' soundex='false'/>\"</partSearch>" +
                                            "<partOrder></partOrder>" +
                                            "</serviceParameters>";
                }

                service_data = "<serviceData>" +
                                "<Opportunity_Id></Opportunity_Id>" +
                                "<Opportunity_Name></Opportunity_Name>" +
                                "<Internal_Master_Code></Internal_Master_Code>" +
                                "<External_Master_Code></External_Master_Code>" +
                                "<Status_Substatus_Desc></Status_Substatus_Desc>" +
                                "<Create_Date></Create_Date>" +
                                "<Num_Accounts></Num_Accounts>" +
                                "<Total_HU_Num></Total_HU_Num>" +
                                "<HU_Days_Cnt></HU_Days_Cnt>" +
                                "<Average_HU_Num></Average_HU_Num>" +
                                "<Update_Tstamp></Update_Tstamp>" +
                                "</serviceData>";

                XmlResponse = Program.HttpSOAPRequest("https://208.253.5.105/P2CAppSource/services/VersatilityWebServiceProxy", Service_parameters, Service_data);

                if (XmlResponse != null)
                {
                    string Response = XmlResponse.InnerXml;

                    Response = Response.Replace(":", "_");

                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(Response);

                    XmlNode returnCode = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnCode");
                    XmlNode returnMessage = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnMessage");
                    XmlNode returnDetails = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnDetails");

                    //XmlNode statusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Status_Desc");
                    //XmlNode subStatusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Sub_Status_Desc");

                    //if (returnCode.InnerText != "")
                    //    return_Code = returnCode.InnerText;

                    //if (returnMessage.InnerText != "")
                    //    return_Message = returnMessage.InnerText;

                    //if (returnDetails.InnerText != "")
                    //    return_Details = returnMessage.InnerText;

                    //if (statusDesc.InnerText != "")
                    //    status_Desc = statusDesc.InnerText;

                    //if (subStatusDesc.InnerText != "")
                    //    sub_Status_Desc = subStatusDesc.InnerText;

                    //if (Convert.ToInt32(returnCode.InnerText) == (int)ESGWebServiceReturnCode.TaskCompletedOk)
                    //{
                    //    XmlNode opportunityToken = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_Tkn");
                    //    XmlNode opportunityId = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_ID");

                    //    if (opportunityId.InnerText != "")
                    //        opportunity_ID = opportunityId.InnerText;

                    //    if (opportunityToken.InnerText != "")
                    //        opportunity_Tkn = opportunityToken.InnerText;

                    //    return true;
                    //}
                    //else
                    //{
                    //    return false;
                    //}

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                string msg = string.Empty;

                msg = msg + Url;
                msg = msg + Password;
                msg = msg + UserId;

                throw new Exception(string.Format("Error occured {0}", ex.ToString()));


                if (XmlResponse != null)
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, xmlResponse.InnerXml);
                }
                else
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, ErrorMessage);
                }
                return false;
            }
        }

        private static TProxy GetProxy<TService, TProxy>(
           IServiceManagement<TService> serviceManagement,
           AuthenticationCredentials authCredentials)
           where TService : class
           where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();

            String _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
            String _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");

            // Provide your user name and password.
            String _userName = ConfigurationManager.AppSettings.Get("UserName");
            String _password = ConfigurationManager.AppSettings.Get("Password");

            // Provide domain name for the On-Premises org.
            String _domain = ConfigurationManager.AppSettings.Get("DomainName");

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);
                    break;
            }

            return authCredentials;
        }

    }
}
