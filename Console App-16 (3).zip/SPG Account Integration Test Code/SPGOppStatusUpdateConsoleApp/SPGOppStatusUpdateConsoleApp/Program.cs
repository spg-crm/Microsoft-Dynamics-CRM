﻿using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Xml;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel.Description;
using Microsoft.Crm.Sdk.Messages;

namespace SPGOppStatusUpdateConsoleApp
{
    class Program
    {
        #region Attributes
        private string _entOpportunity = "opportunity";
        private string _entIntegrationStatus = "spg_integrationstatus";
        private string _entIntegrationCredential = "spg_integrationcredential";

        private string _attrESGPortalOpportunityId = "spg_esgportalopportunityid";
        private string _attrStatus = "spg_status";
        private string _attrSubStatus = "spg_substatus";
        private string _attrStatusUpdateDate = "spg_statusupdatedate";
        private string _attrLastSuccessfulRunOn = "spg_lastsuccessfulrunon";
        private string _attrLastStatus = "spg_laststatus";

        private string _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
        private string _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");

        // Provide your user name and password.
        private string _userName = ConfigurationManager.AppSettings.Get("UserName");
        private string _password = ConfigurationManager.AppSettings.Get("Password");

        // Provide domain name for the On-Premises org.
        private string _domain = ConfigurationManager.AppSettings.Get("DomainName");

        private string _responseFileName = ConfigurationManager.AppSettings.Get("ResponseFileNamePrefix");
        private string _responseFileExt = ConfigurationManager.AppSettings.Get("ResponseFileNameExt");
        private string _requestFileName = ConfigurationManager.AppSettings.Get("RequestFileNamePrefix");
        private string _requestFileExt = ConfigurationManager.AppSettings.Get("RequestFileNameExt");
        private string _logFileName = ConfigurationManager.AppSettings.Get("LogFileNamePrefix");
        private string _logFileExt = ConfigurationManager.AppSettings.Get("LogFileNameExt");

        private string _hoursToSubtract = ConfigurationManager.AppSettings.Get("HoursToSubtract");
        private string _timeStamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

        private string _attrIntAPIUrl = "spg_apiurl";
        private string _attrIntAPIHost = "spg_apihost";
        private string _attrIntAPIAccount = "spg_apiaccount";
        private string _attrIntAPIPassword = "spg_apipassword";

        private DateTime lastSuccessfulRunOn = new DateTime();

        #endregion

        static void Main(string[] args)
        {
            //Console.WriteLine("App started at {0}", DateTime.Now);
            Program app = new Program();
            app.Run();
            //Console.WriteLine("App ended at {0}", DateTime.Now);
            //Console.ReadLine();
        }

        private void Run()
        {
            Boolean result;
            Boolean result2;
            //StringReader stream = null;
            XmlTextReader rdr = null;
            OpportunityStatusList oppStatusList = new OpportunityStatusList();
            oppStatusList.FetchContractDetails();
            //DataSet ds2 = new DataSet();
            //if (result2)
            //{
            //    //stream = new StringReader(oppStatusList.XmlResponse.InnerXml);
            //    // Load the XmlTextReader from the stream
            //    //rdr = new XmlTextReader(stream);
            //    //ds2.ReadXml(stream);
            //    //System.IO.File.WriteAllText(String.Format("{0}_{1}.{2}", _responseFileName, _timeStamp, _responseFileExt), oppStatusList.XmlResponse.InnerXml);
            //    XmlNodeReader rdr = new XmlNodeReader(oppStatusList.XmlResponse);
            //    ds2.ReadXml(rdr);
            //    foreach (DataRow dr in ds2.Tables["SalesPortal.GetContractList"].Rows)
            //    {
            //        string temp = dr[""].ToString();
            //    }


            //}

            lastSuccessfulRunOn = GetLastSuccessfulRunDate();

            #region New code to fetch integration credentials from service

            EntityCollection integrationCredentials = GetIntCredentials();

            if (integrationCredentials != null)
            {
                if (integrationCredentials.Entities.Count > 0)
                {
                    Entity integrationCredential = (Entity)integrationCredentials.Entities[0];

                    if (integrationCredential.Attributes.Contains(_attrIntAPIUrl))
                        oppStatusList.Url = integrationCredential.Attributes[_attrIntAPIUrl].ToString();

                    if (integrationCredential.Attributes.Contains(_attrIntAPIAccount))
                        oppStatusList.UserId = integrationCredential.Attributes[_attrIntAPIAccount].ToString();

                    if (integrationCredential.Attributes.Contains(_attrIntAPIPassword))
                        oppStatusList.Password = integrationCredential.Attributes[_attrIntAPIPassword].ToString();
                }
                else
                {
                    System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("Integration credentials not found for ESP Portal {0}{1}", lastSuccessfulRunOn, lastSuccessfulRunOn.ToLocalTime(), Environment.NewLine, Environment.NewLine));
                    throw new Exception("Integration credentials not found for ESP Portal.");
                }
            }
            else
            {
                System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("Could not retrieve Integration credentials {0}{1}", lastSuccessfulRunOn, lastSuccessfulRunOn.ToLocalTime(), Environment.NewLine, Environment.NewLine));
                throw new Exception("Could not retrieve Integration Credentials.");
            }

            #endregion

            oppStatusList.Row_limit = Convert.ToInt32(ConfigurationManager.AppSettings.Get("RowLimit"));
            //oppStatusList.Update_start_date = lastSuccessfulRunOn.ToLocalTime().AddHours(-1*Convert.ToInt32(_hoursToSubtract));

            result = oppStatusList.GetOpportunityStatus();

            //Console.WriteLine("return code {0} - message {1} - details {2}", oppStatusList.Return_Code, oppStatusList.Return_Message, oppStatusList.Return_Details);

            DataSet ds = new DataSet();

            System.IO.File.WriteAllText(String.Format("{0}_{1}.{2}", _requestFileName, _timeStamp, _requestFileExt), string.Concat(oppStatusList.Service_parameters, oppStatusList.Service_data));

            if (result)
            {
                System.IO.File.WriteAllText(String.Format("{0}_{1}.{2}", _responseFileName, _timeStamp, _responseFileExt), oppStatusList.XmlResponse.InnerXml);
                XmlNodeReader reader = new XmlNodeReader(oppStatusList.XmlResponse);
                ds.ReadXml(reader);

                //if (oppStatusList.Return_Code == "100" || oppStatusList.Return_Code == "0")
                //{
                //    //Console.WriteLine("total opportunity statuses {0}", ds.Tables["Opportunity"].Rows.Count);
                //    UpdateOpportunityStatus(ds);
                //}
            }
            else
            {
                //Console.WriteLine("Failure...");
            }

            CreateIntegrationStatusRecord(oppStatusList);
        }

        private DateTime GetLastSuccessfulRunDate()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    RetrieveMultipleRequest req = new RetrieveMultipleRequest();
                    FetchExpression fetch = new FetchExpression("<fetch distinct='false' mapping='logical' aggregate='true'>" +
                       "<entity name='spg_integrationstatus'>" +
                       "<attribute name='spg_lastsuccessfulrunon' aggregate='max' alias='spg_lastsuccessfulrunon'/>" +
                       "</entity>" +
                       "</fetch>");
                    req.Query = fetch;
                    RetrieveMultipleResponse resp = (RetrieveMultipleResponse)service.Execute(req);

                    EntityCollection integrationStatus = resp.EntityCollection;

                    if (integrationStatus.Entities.Count > 0)
                    {
                        Entity intStatus = integrationStatus.Entities[0];

                        if (intStatus.Attributes.Contains("spg_lastsuccessfulrunon"))
                        {
                            AliasedValue lastSuccessfulRun = new AliasedValue();
                            lastSuccessfulRun = (AliasedValue)intStatus.Attributes["spg_lastsuccessfulrunon"];
                            return Convert.ToDateTime(lastSuccessfulRun.Value);
                        }
                        else
                        {
                            throw new Exception("Record not found in Integration Status entity.");
                            //return Convert.ToDateTime(ConfigurationManager.AppSettings.Get("UpdateStartDate"));
                        }
                    }
                    else
                    {
                        throw new Exception("Record not found in Integration Status entity.");
                        //return Convert.ToDateTime(ConfigurationManager.AppSettings.Get("UpdateStartDate"));
                    }
                }
            }
            return DateTime.Now;
        }

        private void CreateIntegrationStatusRecord(OpportunityStatusList oppStatusList)
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    Entity integrationStatus = new Entity(_entIntegrationStatus);

                    integrationStatus[_attrLastSuccessfulRunOn] = DateTime.Now;
                    //integrationStatus[_attrLastStatus] = String.Format("{0} - {1}", oppStatusList.Return_Code, oppStatusList.Return_Message);

                    Guid integrationStatusId = service.Create(integrationStatus);
                }
            }
        }

        private void UpdateOpportunityStatus(DataSet oppDataSet)
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.
            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    #region Loop through opportunities dataset to update status in CRM

                    for (int i = 0; i < oppDataSet.Tables["Opportunity"].Rows.Count; i++)
                    {
                        DataRow row = oppDataSet.Tables["Opportunity"].Rows[i];

                        string opportunityId = string.Empty;
                        string opportunityCompleteStatus = string.Empty;
                        string opportunityStatus = string.Empty;
                        string opportunitySubStatus = string.Empty;
                        bool opportunityStatusUpdateRequired = false;

                        opportunityId = oppDataSet.Tables["Opportunity"].Rows[i]["Opportunity_Id"].ToString();
                        opportunityCompleteStatus = oppDataSet.Tables["Opportunity"].Rows[i]["Status_Substatus_Desc"].ToString();

                        int subStatusChar = opportunityCompleteStatus.IndexOf(@"/");

                        if (i == 0)
                        {
                            System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("Last successful run was on {0}\t{1}{2}{3}", lastSuccessfulRunOn, lastSuccessfulRunOn.ToLocalTime(), Environment.NewLine, Environment.NewLine));
                            System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("{0}\t{1}\t{2}\t{3}\t{4}", "Opportunity Id", "Status","Status from portal","Error (if any)", Environment.NewLine));
                        }

                        if (subStatusChar == -1)
                        {
                            opportunityStatus = opportunityCompleteStatus;
                        }
                        else
                        {
                            opportunityStatus = opportunityCompleteStatus.Substring(0, subStatusChar);
                            opportunitySubStatus = opportunityCompleteStatus;
                        }

                        if (opportunityCompleteStatus != string.Empty)
                        {
                            //UpdateOpportunityStatus(opportunityId, opportunityStatus, opportunitySubStatus);
                            ColumnSet statusColumns = new ColumnSet(_attrESGPortalOpportunityId, _attrStatus, _attrSubStatus, _attrStatusUpdateDate);

                            //EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _attrESGPortalOpportunityId, opportunityId, statusColumns);
                            EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, "spg_status", "2", statusColumns);

                            if (opportunities.Entities.Count > 0)
                            {
                                Entity opportunity = opportunities.Entities[0];

                                OptionSetValue existingOppStatusValue = new OptionSetValue();
                                OptionSetValue existingOppSubStatusValue = new OptionSetValue();

                                OptionSetValue opportunityStatusValue = new OptionSetValue();
                                OptionSetValue opportunitySubStatusValue = new OptionSetValue();

                                string existingOppStatusText = string.Empty;
                                string existingOppSubStatusText = string.Empty;

                                if (opportunity.Attributes.Contains(_attrStatus))
                                {
                                    existingOppStatusValue = opportunity.Attributes[_attrStatus] as OptionSetValue;
                                    existingOppStatusText = GetOptionsSetTextForValue(service, _entOpportunity, _attrStatus, existingOppStatusValue.Value);

                                    if (existingOppStatusText != "Lost" &&
                                       existingOppStatusText != "Not Viable" &&
                                       existingOppStatusText != "Cancel") 
                                    {
                                        opportunityStatusUpdateRequired = true;
                                    }

                                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _attrStatus, opportunityStatus);
                                    opportunity.Attributes[_attrStatus] = opportunityStatusValue;
                                }

                                if (opportunity.Attributes.Contains(_attrSubStatus) && subStatusChar != -1)
                                {
                                    existingOppSubStatusValue = opportunity.Attributes[_attrSubStatus] as OptionSetValue;
                                    existingOppSubStatusText = GetOptionsSetTextForValue(service, _entOpportunity, _attrSubStatus, existingOppSubStatusValue.Value);

                                    opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _attrSubStatus, opportunitySubStatus);
                                    opportunity.Attributes[_attrSubStatus] = opportunitySubStatusValue;
                                }

                                if (opportunity.Attributes.Contains(_attrStatusUpdateDate))
                                {
                                    opportunity.Attributes[_attrStatusUpdateDate] = DateTime.Now;
                                }
                                else
                                {
                                    opportunity.Attributes.Add(_attrStatusUpdateDate, DateTime.Now);
                                }

                                if (opportunityStatusUpdateRequired)
                                {
                                    if (existingOppStatusValue.Value != opportunityStatusValue.Value || existingOppSubStatusValue.Value != opportunitySubStatusValue.Value)
                                    {
                                        try
                                        {
                                            //service.Update(opportunity);
                                            System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("{0}\tFound    \t{1}\t{2}", opportunityId.PadRight(10, ' '), opportunityCompleteStatus, Environment.NewLine));
                                        }
                                        catch (Exception ex)
                                        {
                                            System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("{0}\tUpdate failed\t{1}\t{2}{3}", opportunityId.PadRight(10, ' '), opportunityCompleteStatus, ex.Message, Environment.NewLine));
                                            //Console.WriteLine();
                                            //Console.WriteLine(ex.Message);
                                        }
                                    }
                                    else
                                    {
                                        System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("{0}\tUpdate not required\t{1}\t{2}", opportunityId.PadRight(10, ' '), opportunityCompleteStatus, Environment.NewLine));
                                    }
                                }
                                else
                                {
                                    System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("{0}\tStatus does not require update\t{1}\t{2}", opportunityId.PadRight(10, ' '), opportunityCompleteStatus, Environment.NewLine));
                                }

                            }
                            else
                            {
                                System.IO.File.AppendAllText(String.Format("{0}_{1}.{2}", _logFileName, _timeStamp, _logFileExt), String.Format("{0}\tNot Found\t{1}\t{2}", opportunityId.PadRight(10, ' '), opportunityCompleteStatus, Environment.NewLine));
                                //Console.WriteLine("{0}\tNot Found\t{1}", opportunityId, opportunityCompleteStatus);
                            }
                        }
                    }
                }

                    #endregion
            }
        }

        private void UpdateOpportunityStatus(string opportunityId, string opportunityStatus, string opportunitySubStatus)
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.
            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    // Now make an SDK call with the organization service proxy.
                    // Display information about the logged on user.
                    Guid userid = ((WhoAmIResponse)organizationProxy.Execute(new WhoAmIRequest())).UserId;

                    ColumnSet statusColumns = new ColumnSet(_attrESGPortalOpportunityId, _attrStatus, _attrSubStatus, _attrStatusUpdateDate);

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _attrESGPortalOpportunityId, opportunityId, statusColumns);

                    if (opportunities.TotalRecordCount > 0)
                    {
                        Entity opportunity = opportunities.Entities[0];

                        //if (opportunity.Attributes.Contains("spg_esgportalopportunityid"))
                        //    System.Console.WriteLine("spg_esgportalopportunityid: " + opportunity.Attributes["spg_esgportalopportunityid"]);

                        if (opportunity.Attributes.Contains(_attrStatus))
                        {
                            OptionSetValue opportunityStatusValue = new OptionSetValue();
                            opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _attrStatus, opportunityStatus);
                            opportunity.Attributes[_attrStatus] = opportunityStatusValue;
                        }

                        if (opportunity.Attributes.Contains(_attrSubStatus))
                        {
                            OptionSetValue opportunitySubStatusValue = new OptionSetValue();
                            opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _attrSubStatus, opportunitySubStatus);
                            opportunity.Attributes[_attrSubStatus] = opportunitySubStatusValue;
                        }

                        if (opportunity.Attributes.Contains(_attrStatusUpdateDate))
                        {
                            opportunity.Attributes[_attrStatusUpdateDate] = DateTime.Now;
                        }
                        else
                        {
                            opportunity.Attributes.Add(_attrStatusUpdateDate, DateTime.Now);
                        }

                        service.Update(opportunity);

                        //Console.WriteLine("{0}\tFound    \t{1}", opportunityId, DateTime.Now);
                    }
                    else
                    {
                        //Console.WriteLine("{0}\tNot Found\t{1}", opportunityId, DateTime.Now);
                    }
                }
            }
        }

        public static XmlDocument HttpSOAPRequest(string url, string serviceParameters, string serviceData)
        {
            // trust all certs
            ServicePointManager.ServerCertificateValidationCallback = ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });

            System.Net.ServicePointManager.Expect100Continue = false;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);

            req.KeepAlive = false;
            req.ConnectionGroupName = Guid.NewGuid().ToString();
            req.Headers.Add("SOAPAction", "\"\"");
            req.ContentType = "text/xml;charset=utf-8";
            req.Accept = "text/xml";
            req.Method = "POST";
            Stream stm = req.GetRequestStream();

            string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
            string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
            string input = string.Concat(soapHdr, serviceParameters, serviceData, soapTrl);
            //Console.WriteLine("--------------------------------------------------");
            //Console.WriteLine(input);
            //Console.WriteLine("--------------------------------------------------");
            // Util.FileWrite(strNTXPath, "Request-" + CustomerID, input);
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(soapHdr + serviceParameters + serviceData + soapTrl);
            stm.Write(bytes, 0, bytes.Length);
            stm.Close();

            HttpWebResponse resp;

            try
            {
                resp = (HttpWebResponse)req.GetResponse();

                Stream objResponseStream = resp.GetResponseStream();
                XmlTextReader objXMLReader = new XmlTextReader(objResponseStream);
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(objXMLReader);
                XmlDocument XMLResponse = xmldoc;
                objXMLReader.Close();
                return XMLResponse;
            }
            catch (WebException exc)
            {
                if (exc.Status == WebExceptionStatus.ProtocolError)
                {
                    StreamReader reader = new StreamReader(exc.Response.GetResponseStream());
                    throw new Exception(reader.ReadToEnd());
                }
                return null;
            }
        }

        /// <summary>
        /// Obtain the AuthenticationCredentials based on AuthenticationProviderType.
        /// </summary>
        /// <param name="service">A service management object.</param>
        /// <param name="endpointType">An AuthenticationProviderType of the CRM environment.</param>
        /// <returns>Get filled credentials.</returns>
        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();

            String _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
            String _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");

            // Provide your user name and password.
            String _userName = ConfigurationManager.AppSettings.Get("UserName");
            String _password = ConfigurationManager.AppSettings.Get("Password");

            // Provide domain name for the On-Premises org.
            String _domain = ConfigurationManager.AppSettings.Get("DomainName");

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);
                    break;
            }

            return authCredentials;
        }

        /// <summary>
        /// Discovers the organizations that the calling user belongs to.
        /// </summary>
        /// <param name="service">A Discovery service proxy instance.</param>
        /// <returns>Array containing detailed information on each organization that 
        /// the user belongs to.</returns>
        public static OrganizationDetailCollection DiscoverOrganizations(
            IDiscoveryService service)
        {
            if (service == null) throw new ArgumentNullException("service");
            RetrieveOrganizationsRequest orgRequest = new RetrieveOrganizationsRequest();
            RetrieveOrganizationsResponse orgResponse =
                (RetrieveOrganizationsResponse)service.Execute(orgRequest);

            return orgResponse.Details;
        }

        /// <summary>
        /// Finds a specific organization detail in the array of organization details
        /// returned from the Discovery service.
        /// </summary>
        /// <param name="orgUniqueName">The unique name of the organization to find.</param>
        /// <param name="orgDetails">Array of organization detail object returned from the discovery service.</param>
        /// <returns>Organization details or null if the organization was not found.</returns>
        /// <seealso cref="DiscoveryOrganizations"/>
        public static OrganizationDetail FindOrganization(string orgUniqueName,
            OrganizationDetail[] orgDetails)
        {
            if (String.IsNullOrWhiteSpace(orgUniqueName))
                throw new ArgumentNullException("orgUniqueName");
            if (orgDetails == null)
                throw new ArgumentNullException("orgDetails");
            OrganizationDetail orgDetail = null;

            foreach (OrganizationDetail detail in orgDetails)
            {
                if (String.Compare(detail.UniqueName, orgUniqueName,
                    StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    orgDetail = detail;
                    break;
                }
            }
            return orgDetail;
        }

        /// <summary>
        /// Generic method to obtain discovery/organization service proxy instance.
        /// </summary>
        /// <typeparam name="TService">
        /// Set IDiscoveryService or IOrganizationService type to request respective service proxy instance.
        /// </typeparam>
        /// <typeparam name="TProxy">
        /// Set the return type to either DiscoveryServiceProxy or OrganizationServiceProxy type based on TService type.
        /// </typeparam>
        /// <param name="serviceManagement">An instance of IServiceManagement</param>
        /// <param name="authCredentials">The user's Microsoft Dynamics CRM logon credentials.</param>
        /// <returns></returns>
        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        /// <summary>
        /// This function is used to retrieve the optionset value using the optionset text label
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedLabel"></param>
        /// <returns></returns>
        private static int GetOptionsSetValueForLabel(IOrganizationService service, string entityName, string attributeName, string selectedLabel)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            int selectedOptionValue = 0;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                {
                    selectedOptionValue = oMD.Value.Value;
                    break;
                }
            }
            return selectedOptionValue;
        }

        /// <summary>
        /// This function is used to retrieve the optionset labek using the optionset value
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedValue"></param>
        /// <returns></returns>
        private static string GetOptionsSetTextForValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = null;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.LocalizedLabels[0].Label.ToString();
                    break;
                }
            }
            return selectedOptionLabel;
        }

        private static EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue)
        {
            ColumnSet indexCol = new ColumnSet(true);

            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = indexCol;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private static EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = columnSet;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private EntityCollection GetIntCredentials()
        {

            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            EntityCollection integrationCredentials = new EntityCollection();

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    integrationCredentials = GetEntityRecords(ref service, _entIntegrationCredential, _attrIntAPIHost, "1");
                }
            }

            return integrationCredentials;
            /*
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_integrationcredential";
            indexattribute.Attributes.AddRange(new string[] { "spg_apihost" });
            indexattribute.Values.AddRange(apiHost);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
            */
        }
    }
}
