﻿using System;
using System.Configuration;
using System.Collections.Generic;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Client;
using Microsoft.Xrm.Client.Services;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using System.ServiceModel.Description;
using System.Linq;
using System.Globalization;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]


namespace SPGCloseOpportunityConsoleApp
{
    class Program
    {
        private static readonly log4net.ILog m_Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);




        private const  string m_Spg_StatusFieldName = "spg_status";
        private const string m_StateCode = "statecode";
        private const string m_Spg_SubStatusFieldName = "spg_substatus";
        private const string m_OpportunityEntityName = "opportunity";
        private const string m_StartMonthYearFieldName = "spg_startmonthyear";
        private const string m_OpportunityName = "spg_opportunityname";
        private const string m_OpportunityId = "spg_esgportalopportunityid";
        private static int m_OpportunitiesCount = 0;

        private string m_GlobalOppName = string.Empty;
        private string m_DiscoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
        private string m_OrganizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");
        private string m_ServerUrl = ConfigurationManager.AppSettings.Get("ServerUrl");
        private string m_ConnectionString = string.Empty;

        // Provide your user name and password.
        private string m_UserName = string.Empty;
        private string m_Password = string.Empty;

        // Provide domain name for the On-Premises org.
        private string m_Domain = string.Empty;

        private CrmConnection m_Monnection;
        private OrganizationService m_OrgService;

        static void Main(string[] args)
        {
            try
            {
                m_Log.Info("App started:");
                Program app = new Program();
              
                app.CloseOpportunities_Win();
                m_Log.Info("Total:" +m_OpportunitiesCount+ " Opportunities updated as lost" );
                m_Log.Info(String.Format("App completed:{0}", Environment.NewLine));
            }
            catch (Exception ex)
            {
              m_Log.Error("Error occured.", ex);
            }
            //Console.ReadLine();
        }

      
       

        private void CloseOpportunities_Win()
        {
            const string StartMonthYearFieldName = "spg_startmonthyear";
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(m_DiscoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(m_OrganizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
               
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();
                    IOrganizationService service = (IOrganizationService)organizationProxy;
                    EntityCollection _opportunitiesCollection = GetOpenOpportunities(ref service);
                    DateTime _currentDate = DateTime.Now;
                   if (_opportunitiesCollection != null)
                   {
                        try
                        { 
                        foreach (Entity eEntity in _opportunitiesCollection.Entities)
                        {
                            DateTime? _startMonthYear = null;
                            string _recordName = string.Empty;
                            if(eEntity.Attributes.Contains(m_OpportunityName))
                            { 
                                _recordName = eEntity.Attributes[m_OpportunityName].ToString();
                                m_GlobalOppName = _recordName;
                            }
                            else { _recordName = ""; }
                            string _recordId = string.Empty;
                            if (eEntity.Attributes.Contains(m_OpportunityId))
                            {
                                _recordId = eEntity.Attributes[m_OpportunityId].ToString();
                            }
                            else
                            { _recordId = ""; }
                            if (eEntity.Attributes.Contains(m_OpportunityName))
                            { 
                                eEntity.Attributes.Remove(m_OpportunityName);
                            }
                            if (eEntity.Attributes.Contains(StartMonthYearFieldName))
                            {
                                _startMonthYear = ((DateTime)eEntity.Attributes[StartMonthYearFieldName]).ToLocalTime();
                                    


                                        if (_startMonthYear != null)
                                        {
                                            if ((_startMonthYear.Value.Month < _currentDate.Month) && (_startMonthYear.Value.Year == _currentDate.Year))
                                            {
                                                UpdateOpportunitiesAsLost(ref service, eEntity);
                                                CloseOpportunityAsLost(ref service, eEntity);
                                                m_Log.Info("Updated: Opportunity Name: " + _recordName + " :Opportunity ID: " + _recordId);
                                            }
                                            else if ((_startMonthYear.Value.Month <= _currentDate.Month || _startMonthYear.Value.Month >= _currentDate.Month) && (_startMonthYear.Value.Year < _currentDate.Year))
                                            {
                                                UpdateOpportunitiesAsLost(ref service, eEntity);
                                                CloseOpportunityAsLost(ref service, eEntity);
                                                m_Log.Info("Updated: Opportunity Name: " + _recordName + " :Opportunity ID: " + _recordId);
                                            }
                                        }
                                
                            }
                            }
                        }
                        catch(Exception e)
                        {
                            m_Log.Error(e + "Exception in " + m_GlobalOppName);
                        }
                   }

                  


                }
            }
        }

      

        /// <summary>
        /// Obtain the AuthenticationCredentials based on AuthenticationProviderType.
        /// </summary>
        /// <param name="service">A service management object.</param>
        /// <param name="endpointType">An AuthenticationProviderType of the CRM environment.</param>
        /// <returns>Get filled credentials.</returns>
        private AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(m_UserName,
                            m_Password,
                            m_Domain);
                    break;
            }

            return authCredentials;
        }

        /// <summary>
        /// Discovers the organizations that the calling user belongs to.
        /// </summary>
        /// <param name="service">A Discovery service proxy instance.</param>
        /// <returns>Array containing detailed information on each organization that 
        /// the user belongs to.</returns>
        public OrganizationDetailCollection DiscoverOrganizations(
            IDiscoveryService service)
        {
            if (service == null) throw new ArgumentNullException("service");
            RetrieveOrganizationsRequest orgRequest = new RetrieveOrganizationsRequest();
            RetrieveOrganizationsResponse orgResponse =
                (RetrieveOrganizationsResponse)service.Execute(orgRequest);

            return orgResponse.Details;
        }

        /// <summary>
        /// Finds a specific organization detail in the array of organization details
        /// returned from the Discovery service.
        /// </summary>
        /// <param name="orgUniqueName">The unique name of the organization to find.</param>
        /// <param name="orgDetails">Array of organization detail object returned from the discovery service.</param>
        /// <returns>Organization details or null if the organization was not found.</returns>
        /// <seealso cref="DiscoveryOrganizations"/>
        public OrganizationDetail FindOrganization(string orgUniqueName,
            OrganizationDetail[] orgDetails)
        {
            if (String.IsNullOrWhiteSpace(orgUniqueName))
                throw new ArgumentNullException("orgUniqueName");
            if (orgDetails == null)
                throw new ArgumentNullException("orgDetails");
            OrganizationDetail orgDetail = null;

            foreach (OrganizationDetail detail in orgDetails)
            {
                if (String.Compare(detail.UniqueName, orgUniqueName,
                    StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    orgDetail = detail;
                    break;
                }
            }
            return orgDetail;
        }

        /// <summary>
        /// Generic method to obtain discovery/organization service proxy instance.
        /// </summary>
        /// <typeparam name="TService">
        /// Set IDiscoveryService or IOrganizationService type to request respective service proxy instance.
        /// </typeparam>
        /// <typeparam name="TProxy">
        /// Set the return type to either DiscoveryServiceProxy or OrganizationServiceProxy type based on TService type.
        /// </typeparam>
        /// <param name="serviceManagement">An instance of IServiceManagement</param>
        /// <param name="authCredentials">The user's Microsoft Dynamics CRM logon credentials.</param>
        /// <returns></returns>
        private TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

       
        

        private static EntityCollection GetOpenOpportunities(ref IOrganizationService service )
        {
            //ColumnSet Indexcol = new ColumnSet(new string[] { m_StartMonthYearFieldName, m_OpportunityName, m_OpportunityId});
            ConditionExpression condition1 = new ConditionExpression();
            condition1.AttributeName = "spg_startmonthyear";
            condition1.Operator = ConditionOperator.OnOrBefore;
            condition1.Values.Add(DateTime.Now.ToLocalTime());       //current date  
            
            ConditionExpression condition2 = new ConditionExpression();
            condition2.AttributeName = m_Spg_StatusFieldName;
            condition2.Operator = ConditionOperator.Equal;
            condition2.Values.Add(1);

            ConditionExpression condition3 = new ConditionExpression();
            condition3.AttributeName = m_StateCode;
            condition3.Operator = ConditionOperator.Equal;
            condition3.Values.Add(0);

            FilterExpression filter1 = new FilterExpression();
            filter1.Conditions.Add(condition1);
            filter1.Conditions.Add(condition2);
            filter1.Conditions.Add(condition3);

            QueryExpression query = new QueryExpression(m_OpportunityEntityName);
            query.ColumnSet.AllColumns = true;
            query.Criteria.AddFilter(filter1);
            
            EntityCollection index = service.RetrieveMultiple(query);
            return index;
      }
        private static void UpdateOpportunitiesAsLost(ref IOrganizationService service, Entity OpportunityEntityObject)
        {
            try
            {
                if (OpportunityEntityObject.Attributes.Contains(m_Spg_StatusFieldName))
                {
                    OpportunityEntityObject.Attributes[m_Spg_StatusFieldName] = new OptionSetValue(3);
                }
                else
                {
                    OpportunityEntityObject.Attributes.Add(m_Spg_StatusFieldName, new OptionSetValue(3));
                }

                if (OpportunityEntityObject.Attributes.Contains(m_Spg_SubStatusFieldName))
                {
                    OpportunityEntityObject.Attributes[m_Spg_SubStatusFieldName] = new OptionSetValue(19);
                }
                else
                {
                    OpportunityEntityObject.Attributes.Add(m_Spg_SubStatusFieldName, new OptionSetValue(19));
                }

                
            service.Update(OpportunityEntityObject);
            }
            catch(Exception e)
            {
                m_Log.Error(e + " Exception in " + OpportunityEntityObject.Id.ToString());
            }
        }
        private static void CloseOpportunityAsLost(ref IOrganizationService service, Entity OpportunityObject )
        {
            try
            {
                const string OpportunityCloseEntityName = "opportunityclose";
                const string SubjectFieldName = "subject";
                const string OpportunityId = "opportunityid";
                const string OpportunityEntityName = "opportunity";
                const string ActualEndFieldName = "actualend";
            Entity opportunityClose = new Entity(OpportunityCloseEntityName);
            opportunityClose.Attributes[SubjectFieldName] = "Lost opportunity by App";
            opportunityClose.Attributes[OpportunityId] = new EntityReference(OpportunityEntityName, OpportunityObject.Id);
            opportunityClose.Attributes[ActualEndFieldName] = DateTime.Now;

            LoseOpportunityRequest loseOppReq = new LoseOpportunityRequest();
            loseOppReq.OpportunityClose = opportunityClose;
            loseOppReq.Status = new OptionSetValue(-1);

            service.Execute(loseOppReq);
            m_OpportunitiesCount = m_OpportunitiesCount+1;
            }
            catch(Exception e)
            {
                m_Log.Error(e + " Exception in " + OpportunityObject.Id);
            }
        }
    
    }
}

