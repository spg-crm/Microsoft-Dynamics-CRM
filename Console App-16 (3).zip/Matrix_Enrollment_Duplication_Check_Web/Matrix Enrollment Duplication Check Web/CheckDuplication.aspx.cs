﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Matrix_Enrollment_Duplication_Check_DLL;

namespace Matrix_Enrollment_Duplication_Check_Web
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                DuplicationCheckClass obj = new DuplicationCheckClass();
                //string[] arr = obj.DuplicationCheck("CREATIVE SOLUTIONS IN HEALTH CARE, INC.", "aalam@spg.source.com", "Welcome$1", "https://azspg.dev.spgenergy.com");
                //string[] arr = obj.DuplicationCheck("hjhjhjshjshs.", "aalam@spg.source.com", "Welcome$1", "https://azspg.dev.spgenergy.com");
                //string rslt = obj.Test("CREATIVE SOLUTIONS IN HEALTH CARE, INC.", "aalam@spg.source.com", "Welcome$1", "https://azspg.dev.spgenergy.com");
                //string rslt = obj.Test("hjhjhjshjshs.", "aalam@spg.source.com", "Welcome$1", "https://azspg.dev.spgenergy.com");
            }
        }
    }
}