﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Client;
using System.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Description;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace SPG_Status_Update_App_for_Credit_Status
{
    class Program
    {
       
        static void Main(string[] args)
        {
            try
            { 
                log.Info("App started.");
                Program app = new Program();
                app.creditStatusUpdateOnOpportunity();
                log.Info(String.Format("App completed.{0}", Environment.NewLine));
            }
            catch(Exception ex)
            {
                log.Error("Error occured.", ex);
            }
            
        }

        private void creditStatusUpdateOnOpportunity()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    opportunityStatusText = "Open";
                    creditStatusText = "Approved";
                    

                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service,_entOpportunity,_oppAttrStatus,opportunityStatusText);
                    creditStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _creditAttrStatus, creditStatusText);

                    ColumnSet opportunityColumns = new ColumnSet(new string[] { _oppAttrName, _oppAttrStatus, _esgportalOppId });
                    string[] columnAttributeNames = new string[] { _oppAttrStatus  , _creditAttrStatus };
                    object[] attributeValues= new object[] { opportunityStatusValue.Value , creditStatusValue.Value };
                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, columnAttributeNames, attributeValues, opportunityColumns);

                    int totalOpportunities = opportunities.Entities.Count;
                    int UpdatedOpportunities = 0;
                    log.Info(String.Format("{0} opportunity records with {1} status", opportunities.Entities.Count, opportunityStatusText));
                    DateTime currentdate = DateTime.Now;
                    if (opportunities != null && opportunities.Entities.Count > 0)
                    {
                        for (int i = 0; i < totalOpportunities; i++)
                        {
                            Entity opportunity = opportunities.Entities[i];
                            ColumnSet creditColumns = new ColumnSet(new string[] { _creditcheckdate });
                            string[] creditColumnAttributeNames = new string[] { _opportunitylookupid };
                            object[] creditAttributeValues = new object[] { opportunity.Id };
                            EntityCollection creditCollection = GetEntityRecords(ref service, _creditEntityName, creditColumnAttributeNames, creditAttributeValues, creditColumns);
                            if (creditCollection != null && creditCollection.Entities.Count > 0)
                            {
                                Entity entity = creditCollection.Entities[0];                    
                                    if (entity.Attributes.Contains(_creditcheckdate))
                                    {
                                        DateTime creditcheckDate = (DateTime)entity.Attributes[_creditcheckdate];
                                        if ((int)(currentdate - creditcheckDate).TotalDays > 181)
                                        {
                                        if(opportunity.Attributes.Contains(_esgportalOppId))
                                        {
                                            log.Info(String.Format("Opportunity updated with name {0} and ID {1}", opportunity.Attributes[_oppAttrName], opportunity.Attributes[_esgportalOppId]));
                                        }
                                        else
                                        {
                                            log.Info(String.Format("Opportunity updated with name {0}", opportunity.Attributes[_oppAttrName]));
                                        }
                                            opportunity.Attributes.Add(_creditAttrStatus, new OptionSetValue(2));
                                            service.Update(opportunity);
                                            UpdatedOpportunities += 1;
                                        }
                                    
                                }
                            }
                            
                        }
                        log.Info(String.Format("Total {0} Opportunties Updated", UpdatedOpportunities));
                    }
                }
            }
        }

        /// <summary>
        /// Obtain the AuthenticationCredentials based on AuthenticationProviderType.
        /// </summary>
        /// <param name="service">A service management object.</param>
        /// <param name="endpointType">An AuthenticationProviderType of the CRM environment.</param>
        /// <returns>Get filled credentials.</returns>
        private AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);
                    break;
            }

            return authCredentials;
        }

        /// <summary>
        /// Generic method to obtain discovery/organization service proxy instance.
        /// </summary>
        /// <typeparam name="TService">
        /// Set IDiscoveryService or IOrganizationService type to request respective service proxy instance.
        /// </typeparam>
        /// <typeparam name="TProxy">
        /// Set the return type to either DiscoveryServiceProxy or OrganizationServiceProxy type based on TService type.
        /// </typeparam>
        /// <param name="serviceManagement">An instance of IServiceManagement</param>
        /// <param name="authCredentials">The user's Microsoft Dynamics CRM logon credentials.</param>
        /// <returns></returns>
        private TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        /// <summary>
        /// Discovers the organizations that the calling user belongs to.
        /// </summary>
        /// <param name="service">A Discovery service proxy instance.</param>
        /// <returns>Array containing detailed information on each organization that 
        /// the user belongs to.</returns>
        public OrganizationDetailCollection DiscoverOrganizations(
            IDiscoveryService service)
        {
            if (service == null) throw new ArgumentNullException("service");
            RetrieveOrganizationsRequest orgRequest = new RetrieveOrganizationsRequest();
            RetrieveOrganizationsResponse orgResponse =
                (RetrieveOrganizationsResponse)service.Execute(orgRequest);

            return orgResponse.Details;
        }

        /// <summary>
        /// Finds a specific organization detail in the array of organization details
        /// returned from the Discovery service.
        /// </summary>
        /// <param name="orgUniqueName">The unique name of the organization to find.</param>
        /// <param name="orgDetails">Array of organization detail object returned from the discovery service.</param>
        /// <returns>Organization details or null if the organization was not found.</returns>
        /// <seealso cref="DiscoveryOrganizations"/>
        public OrganizationDetail FindOrganization(string orgUniqueName,
            OrganizationDetail[] orgDetails)
        {
            if (String.IsNullOrWhiteSpace(orgUniqueName))
                throw new ArgumentNullException("orgUniqueName");
            if (orgDetails == null)
                throw new ArgumentNullException("orgDetails");
            OrganizationDetail orgDetail = null;

            foreach (OrganizationDetail detail in orgDetails)
            {
                if (String.Compare(detail.UniqueName, orgUniqueName,
                    StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    orgDetail = detail;
                    break;
                }
            }
            return orgDetail;
        }

        /// <summary>
        /// This function is used to retrieve the optionset value using the optionset text label
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedLabel"></param>
        /// <returns></returns>
        private static int GetOptionsSetValueForLabel(IOrganizationService service, string entityName, string attributeName, string selectedLabel)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            int selectedOptionValue = 0;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                {
                    selectedOptionValue = oMD.Value.Value;
                    break;
                }
            }
            return selectedOptionValue;
        }

        private static EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string[] columnAttributeName,object[] columnAttributeValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.ColumnSet = columnSet;
            indexAttribute.Attributes.AddRange(columnAttributeName);
            indexAttribute.Values.AddRange(columnAttributeValue);
            indexAttribute.AddOrder("createdon",OrderType.Descending);
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private string _entOpportunity = "opportunity";
        private string _opportunitylookupid = "spg_opportunity";
        private string _creditcheckdate = "spg_dateofcreditcheck";
        private string _oppAttrName = "name";
        private string _esgportalOppId = "spg_esgportalopportunityid";
        private string _oppAttrStatus = "spg_status";
        private string _creditAttrStatus = "spg_creditstatus";
        private string _creditEntityName = "spg_credit";
        private string _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
        private string _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");
        private string _serverUrl = ConfigurationManager.AppSettings.Get("ServerUrl");
        private string _connectionString = string.Empty;

        private OptionSetValue opportunityStatusValue = new OptionSetValue();
        private OptionSetValue creditStatusValue = new OptionSetValue();


        private string opportunityStatusText = string.Empty;
        private string creditStatusText = string.Empty;
        
        // Provide your user name and password.
        private string _userName = string.Empty;
        private string _password = string.Empty;

        // Provide domain name for the On-Premises org.
        private string _domain = string.Empty;
    }
}
