﻿using System;
using System.Configuration;
using System.Collections.Generic;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Client;
using Microsoft.Xrm.Client.Services;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using System.ServiceModel.Description;
using System.Linq;
using System.Globalization;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]


namespace SPGCloseOpportunityConsoleApp
{
    class Program
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private string _entOpportunity = "opportunity";
        private string _oppAttrName = "name";
        private string _oppAttrStatus = "spg_status";
        private string _oppAttrSubStatus = "spg_substatus";
        private string _oppAttrStage = "spg_stage";
        private string _oppAttrProfitOpportunity = "spg_historicaldataid";
        private string _oppAttrActualCloseDate = "actualclosedate";

        private OptionSetValue opportunityStatusValue = new OptionSetValue();
        private OptionSetValue opportunitySubStatusValue = new OptionSetValue();
        private OptionSetValue opportunityStageValue = new OptionSetValue();

        private string opportunityStatusText = string.Empty;
        private string opportunitySubStatusText = string.Empty;
        private string opportunityStageText = string.Empty;

        private Guid _profitOpportunityId;
        private string _entProfitOpportunity = "spg_prophetopportunity";
        private string _proOppAttrCloseDate = "spg_closedate";
        private string _proOppAttrModifiedDateTime = "spg_modifieddatetime";
        private string _proOppAttrUserDefined103 = "spg_userdefined103";

        private string _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
        private string _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");
        private string _serverUrl = ConfigurationManager.AppSettings.Get("ServerUrl");
        private string _connectionString = string.Empty;

        // Provide your user name and password.
        private string _userName = string.Empty;
        private string _password = string.Empty;

        // Provide domain name for the On-Premises org.
        private string _domain = string.Empty;

        private CrmConnection _connection;
        private OrganizationService _orgService;

        static void Main(string[] args)
        {
            try
            {
                log.Info("App started.");
                Program app = new Program();
                //app.CloseOpportunities_NotViable();
                //app.CloseOpportunities_Cancel();
                app.CloseOpportunities_Win();
                app.CloseOpportunities_Lost();
                //app.CloseOpportunities_LostDate();
                //app.CloseOpportunities_WinDate();
                log.Info(String.Format("App completed.{0}", Environment.NewLine));
            }
            catch (Exception ex)
            {
                log.Error("Error occured.", ex);
            }
            Console.ReadLine();
        }

        private void CloseOpportunities_NotViable()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    opportunityStatusText = "Not Viable";

                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStatus, opportunityStatusText);

                    ColumnSet opportunityColumns = new ColumnSet(_oppAttrName, _oppAttrStage, _oppAttrStatus, _oppAttrSubStatus, _oppAttrProfitOpportunity);
                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _oppAttrStatus, opportunityStatusValue.Value.ToString(), opportunityColumns);

                    int totalOpportunities = opportunities.Entities.Count;

                    log.Info(String.Format("Going to update {0} opportunity records with {1} status ({2})", opportunities.Entities.Count, opportunityStatusText, opportunityStatusValue.Value ));

                    for (int i = 0; i < totalOpportunities; i++)
                    {
                        Entity opportunity = opportunities.Entities[i];

                        log.Info(String.Format("Upading {0} - {1}", opportunity.Id, opportunity.Attributes[_oppAttrName]));

                        ColumnSet profitOppColumns = new ColumnSet(_proOppAttrCloseDate, _proOppAttrUserDefined103, _proOppAttrModifiedDateTime);
                        //Entity profitOpportunity = GetEntityRecord(ref service, _entProfitOpportunity, _profitOpportunityId, profitOppColumns);

                        opportunitySubStatusText = "Cancel/Cancel";
                        opportunityStageText = "Closed";

                        if (opportunity.Attributes.Contains(_oppAttrSubStatus))
                        {
                            opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrSubStatus, opportunitySubStatusText);
                            opportunity.Attributes[_oppAttrSubStatus] = opportunitySubStatusValue;
                        }

                        if (opportunity.Attributes.Contains(_oppAttrStage))
                        {
                            opportunityStageValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStage, opportunityStageText);
                            opportunity.Attributes[_oppAttrStage] = opportunityStageValue;
                        }

                        service.Update(opportunity);

                        //log.Info("Update successful.");
                    }
                }
            }
        }

        private void CloseOpportunities_Cancel()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    opportunityStatusText = "Cancel";

                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStatus, opportunityStatusText);

                    ColumnSet opportunityColumns = new ColumnSet(_oppAttrName, _oppAttrStage, _oppAttrStatus, _oppAttrSubStatus, _oppAttrProfitOpportunity);
                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _oppAttrStatus, opportunityStatusValue.Value.ToString(), opportunityColumns);

                    int totalOpportunities = opportunities.Entities.Count;

                    log.Info(String.Format("Going to update {0} opportunity records with {1} status ({2})", opportunities.Entities.Count, opportunityStatusText, opportunityStatusValue.Value));

                    for (int i = 0; i < totalOpportunities; i++)
                    {
                        Entity opportunity = opportunities.Entities[i];

                        log.Info(String.Format("{0} - {1}", opportunity.Id, opportunity.Attributes[_oppAttrName]));

                        ColumnSet profitOppColumns = new ColumnSet(_proOppAttrCloseDate, _proOppAttrUserDefined103, _proOppAttrModifiedDateTime);
                        //Entity profitOpportunity = GetEntityRecord(ref service, _entProfitOpportunity, _profitOpportunityId, profitOppColumns);

                        opportunitySubStatusText = "Cancel/Cancel";
                        opportunityStageText = "Closed";

                        if (opportunity.Attributes.Contains(_oppAttrSubStatus))
                        {
                            opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrSubStatus, opportunitySubStatusText);
                            opportunity.Attributes[_oppAttrSubStatus] = opportunitySubStatusValue;
                        }

                        if (opportunity.Attributes.Contains(_oppAttrStage))
                        {
                            opportunityStageValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStage, opportunityStageText);
                            opportunity.Attributes[_oppAttrStage] = opportunityStageValue;
                        }

                        service.Update(opportunity);

                        //log.Info("Update successful.");
                    }
                }
            }
        }

        private void CloseOpportunities_Lost()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    opportunityStatusText = "Lost";

                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStatus, opportunityStatusText);

                    ColumnSet opportunityColumns = new ColumnSet(_oppAttrName, _oppAttrStage, _oppAttrStatus, _oppAttrSubStatus, _oppAttrProfitOpportunity);
                    /*
                    Guid oppId = new Guid("FEDE5A11-DE89-E511-80CA-000D3A90E5FA");
                    Entity opportunity = GetEntityRecord(ref service, _entOpportunity, oppId, opportunityColumns);
                    */
                    DateTime lostDate = new DateTime();
                    string lostDateStr = String.Empty;

                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _oppAttrStatus, opportunityStatusValue.Value.ToString(), opportunityColumns);

                    int totalOpportunities = opportunities.Entities.Count;

                    log.Info(String.Format("Going to update {0} opportunity records with {1} status ({2})", opportunities.Entities.Count, opportunityStatusText, opportunityStatusValue.Value));

                    for (int i = 0; i < totalOpportunities; i++)
                    {
                        try
                        {
                            Entity opportunity = opportunities.Entities[i];

                            if (opportunity.Attributes.Contains(_oppAttrProfitOpportunity))
                            {
                                EntityReference profitOpportunityReference = (EntityReference)opportunity.Attributes[_oppAttrProfitOpportunity];

                                _profitOpportunityId = profitOpportunityReference.Id;

                                log.Info(String.Format("Upading {0} - {1}", opportunity.Id, opportunity.Attributes[_oppAttrName]));

                                ColumnSet profitOppColumns = new ColumnSet(_proOppAttrCloseDate, _proOppAttrUserDefined103, _proOppAttrModifiedDateTime);
                                Entity profitOpportunity = GetEntityRecord(ref service, _entProfitOpportunity, _profitOpportunityId, profitOppColumns);

                                if (profitOpportunity != null)
                                {
                                    //log.Info(String.Format("Opportunity id {0}", opportunity.Attributes[_oppAttrId]));

                                    if (profitOpportunity.Attributes.Contains(_proOppAttrUserDefined103))
                                    {
                                        lostDate = DateTime.ParseExact(profitOpportunity.GetAttributeValue<string>(_proOppAttrUserDefined103), "dd-MM-yy", CultureInfo.InvariantCulture);
                                    }
                                    else if (profitOpportunity.Attributes.Contains(_proOppAttrModifiedDateTime))
                                    {
                                        lostDate = DateTime.ParseExact(profitOpportunity.GetAttributeValue<string>(_proOppAttrModifiedDateTime), "dd-MM-yy", CultureInfo.InvariantCulture);
                                    }
                                }

                                opportunitySubStatusText = "Lost/Lost";
                                opportunityStageText = "Closed";

                                if (opportunity.Attributes.Contains(_oppAttrSubStatus))
                                {
                                    opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrSubStatus, opportunitySubStatusText);
                                    opportunity.Attributes[_oppAttrSubStatus] = opportunitySubStatusValue;
                                }

                                if (opportunity.Attributes.Contains(_oppAttrStage))
                                {
                                    opportunityStageValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStage, opportunityStageText);
                                    opportunity.Attributes[_oppAttrStage] = opportunityStageValue;
                                }

                                service.Update(opportunity);

                                #region Request for closing an opportunity as Lost

                                Entity opportunityClose = new Entity("opportunityclose");
                                opportunityClose.Attributes["subject"] = "Lost opportunity by App";
                                opportunityClose.Attributes["opportunityid"] = new EntityReference("opportunity", opportunity.Id);
                                opportunityClose.Attributes["actualend"] = lostDate;

                                LoseOpportunityRequest loseOppReq = new LoseOpportunityRequest();
                                loseOppReq.OpportunityClose = opportunityClose;
                                loseOppReq.Status = new OptionSetValue(-1);

                                service.Execute(loseOppReq);

                                #endregion

                                //log.Info("Update successful.");
                            }
                            else
                            {
                                log.Warn(String.Format("History record for opportunity id {0} could not be found.", opportunity.Id));
                            }
                        }
                        catch (Exception ex)
                        {
                            log.Error("Error occured.", ex);
                        }
                    }
                }
            }
        }

        private void CloseOpportunities_Win()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    opportunityStatusText = "Won";

                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStatus, opportunityStatusText);

                    ColumnSet opportunityColumns = new ColumnSet(_oppAttrName, _oppAttrStage, _oppAttrStatus, _oppAttrSubStatus, _oppAttrProfitOpportunity);
                    /*
                    Guid oppId = new Guid("FEDE5A11-DE89-E511-80CA-000D3A90E5FA");
                    Entity opportunity = GetEntityRecord(ref service, _entOpportunity, oppId, opportunityColumns);
                    */
                    DateTime lostDate = new DateTime();
                    string lostDateStr = String.Empty;

                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _oppAttrStatus, opportunityStatusValue.Value.ToString(), opportunityColumns);

                    int totalOpportunities = opportunities.Entities.Count;

                    log.Info(String.Format("Going to update {0} opportunity records with {1} status ({2})", opportunities.Entities.Count, opportunityStatusText, opportunityStatusValue.Value));

                    for (int i = 0; i < totalOpportunities; i++)
                    {
                        try
                        {
                            Entity opportunity = opportunities.Entities[i];

                            if (opportunity.Attributes.Contains(_oppAttrProfitOpportunity))
                            {
                                EntityReference profitOpportunityReference = (EntityReference)opportunity.Attributes[_oppAttrProfitOpportunity];

                                _profitOpportunityId = profitOpportunityReference.Id;

                                //log.Info(String.Format("Upading {0} - {1}", opportunity.Id, opportunity.Attributes[_oppAttrName]));

                                ColumnSet profitOppColumns = new ColumnSet(_proOppAttrCloseDate, _proOppAttrUserDefined103, _proOppAttrModifiedDateTime);
                                Entity profitOpportunity = GetEntityRecord(ref service, _entProfitOpportunity, _profitOpportunityId, profitOppColumns);

                                if (profitOpportunity != null)
                                {
                                    //log.Info(String.Format("Opportunity id {0}", opportunity.Attributes[_oppAttrId]));

                                    if (profitOpportunity.Attributes.Contains(_proOppAttrCloseDate))
                                    {
                                        log.Info(String.Format("{0}-{1}",opportunity.Id,profitOpportunity.GetAttributeValue<string>(_proOppAttrCloseDate)));
                                        lostDate = DateTime.ParseExact(profitOpportunity.GetAttributeValue<string>(_proOppAttrCloseDate), "dd-MM-yy", CultureInfo.InvariantCulture);
                                        log.Info(String.Format("Won Date {0} - {1}", profitOpportunity.GetAttributeValue<string>(_proOppAttrCloseDate),lostDate.ToString("MM/dd/yyyy")));
                                    }
                                    else if (profitOpportunity.Attributes.Contains(_proOppAttrModifiedDateTime))
                                    {
                                        lostDate = DateTime.ParseExact(profitOpportunity.GetAttributeValue<string>(_proOppAttrModifiedDateTime), "dd-MM-yy", CultureInfo.InvariantCulture);
                                        //lostDateStr = profitOpportunity.GetAttributeValue<string>(_proOppAttrModifiedDateTime);
                                        //string[] lostDateSplit = lostDateStr.Split('/');

                                        //lostDate = new DateTime(Convert.ToInt16(lostDateSplit[2]),
                                        //                        Convert.ToInt16(lostDateSplit[0]),
                                        //                        Convert.ToInt16(lostDateSplit[1]));
                                    }
                                }

                                opportunitySubStatusText = "Won/Ready to Enroll";
                                opportunityStageText = "Closed";

                                if (opportunity.Attributes.Contains(_oppAttrSubStatus))
                                {
                                    opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrSubStatus, opportunitySubStatusText);
                                    opportunity.Attributes[_oppAttrSubStatus] = opportunitySubStatusValue;
                                }

                                if (opportunity.Attributes.Contains(_oppAttrStage))
                                {
                                    opportunityStageValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStage, opportunityStageText);
                                    opportunity.Attributes[_oppAttrStage] = opportunityStageValue;
                                }

                                service.Update(opportunity);

                                #region Request for closing an opportunity as Won

                                Entity opportunityClose = new Entity("opportunityclose");
                                opportunityClose.Attributes["subject"] = "Won opportunity by App";
                                opportunityClose.Attributes["opportunityid"] = new EntityReference("opportunity", opportunity.Id);
                                opportunityClose.Attributes["actualend"] = lostDate;

                                WinOpportunityRequest winOppReq = new WinOpportunityRequest();
                                winOppReq.OpportunityClose = opportunityClose;
                                winOppReq.Status = new OptionSetValue(-1);

                                service.Execute(winOppReq);

                                #endregion

                                //log.Info("Update successful.");
                            }
                            else
                            {
                                log.Warn(String.Format("History record for opportunity id {0} could not be found.", opportunity.Id));
                            }
                        }
                        catch (Exception ex)
                        {
                            log.Error("Error occured.", ex);
                        }
                    }
                }
            }
        }

        private void CloseOpportunities_LostDate()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    opportunityStatusText = "Lost";

                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStatus, opportunityStatusText);

                    ColumnSet opportunityColumns = new ColumnSet(_oppAttrName, _oppAttrStage, _oppAttrStatus, _oppAttrSubStatus, _oppAttrProfitOpportunity, _oppAttrActualCloseDate);

                    DateTime lostDate = new DateTime();
                    string lostDateStr = String.Empty;

                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _oppAttrStatus, opportunityStatusValue.Value.ToString(), opportunityColumns);

                    int totalOpportunities = opportunities.Entities.Count;

                    log.Info(String.Format("Going to update {0} opportunity records with {1} status ({2})", opportunities.Entities.Count, opportunityStatusText, opportunityStatusValue.Value));

                    for (int i = 0; i < totalOpportunities; i++)
                    {
                        try
                        {
                            Entity opportunity = opportunities.Entities[i];

                            if (opportunity.Attributes.Contains(_oppAttrProfitOpportunity))
                            {
                                EntityReference profitOpportunityReference = (EntityReference)opportunity.Attributes[_oppAttrProfitOpportunity];

                                _profitOpportunityId = profitOpportunityReference.Id;

                                ColumnSet profitOppColumns = new ColumnSet(_proOppAttrCloseDate, _proOppAttrUserDefined103, _proOppAttrModifiedDateTime);
                                Entity profitOpportunity = GetEntityRecord(ref service, _entProfitOpportunity, _profitOpportunityId, profitOppColumns);

                                if (profitOpportunity != null)
                                {
                                    if (profitOpportunity.Attributes.Contains(_proOppAttrUserDefined103) && opportunity.Attributes.Contains(_oppAttrActualCloseDate))
                                    {
                                        log.Info(String.Format("Upading {0} - {1}", opportunity.Id, opportunity.Attributes[_oppAttrName]));
                                        lostDate = DateTime.ParseExact(profitOpportunity.GetAttributeValue<string>(_proOppAttrUserDefined103), "dd-MM-yy", CultureInfo.InvariantCulture);
                                        opportunity.Attributes[_oppAttrActualCloseDate] = lostDate;
                                        log.Info(String.Format("Lost Date {0} - {1}", profitOpportunity.GetAttributeValue<string>(_proOppAttrUserDefined103), lostDate.ToString("yyyy-MM-dd")));
                                        service.Update(opportunity);
                                    }
                                }
                            }
                            else
                            {
                                log.Warn(String.Format("History record for opportunity id {0} could not be found.", opportunity.Id));
                            }
                        }
                        catch (Exception ex)
                        {
                            log.Error("Error occured.", ex);
                        }
                    }
                }
            }
        }

        private void CloseOpportunities_WinDate()
        {
            IServiceManagement<IDiscoveryService> serviceManagement = ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(new Uri(_discoveryServiceAddress));
            AuthenticationProviderType endpointType = serviceManagement.AuthenticationType;

            // Set the credentials.
            AuthenticationCredentials authCredentials = GetCredentials(serviceManagement, endpointType);

            String organizationUri = String.Empty;
            // Get the discovery service proxy.

            using (DiscoveryServiceProxy discoveryProxy = GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, authCredentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    OrganizationDetailCollection orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    organizationUri = FindOrganization(_organizationUniqueName,
                        orgs.ToArray()).Endpoints[EndpointType.OrganizationService];

                }
            }

            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                organizationUri = organizationUri.Replace("spgazcrm01", "10.10.220.33");
                //Console.WriteLine(organizationUri);
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(organizationUri));

                // Set the credentials.
                AuthenticationCredentials credentials = GetCredentials(orgServiceManagement, endpointType);

                // Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials))
                {
                    // This statement is required to enable early-bound type support.
                    organizationProxy.EnableProxyTypes();

                    IOrganizationService service = (IOrganizationService)organizationProxy;

                    opportunityStatusText = "Won";

                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(service, _entOpportunity, _oppAttrStatus, opportunityStatusText);

                    ColumnSet opportunityColumns = new ColumnSet(_oppAttrName, _oppAttrStage, _oppAttrStatus, _oppAttrSubStatus, _oppAttrProfitOpportunity, _oppAttrActualCloseDate);

                    DateTime lostDate = new DateTime();
                    string lostDateStr = String.Empty;

                    EntityCollection opportunities = GetEntityRecords(ref service, _entOpportunity, _oppAttrStatus, opportunityStatusValue.Value.ToString(), opportunityColumns);

                    int totalOpportunities = opportunities.Entities.Count;

                    log.Info(String.Format("Going to update {0} opportunity records with {1} status ({2})", opportunities.Entities.Count, opportunityStatusText, opportunityStatusValue.Value));

                    for (int i = 0; i < totalOpportunities; i++)
                    {
                        try
                        {
                            Entity opportunity = opportunities.Entities[i];

                            if (opportunity.Attributes.Contains(_oppAttrProfitOpportunity))
                            {
                                EntityReference profitOpportunityReference = (EntityReference)opportunity.Attributes[_oppAttrProfitOpportunity];

                                _profitOpportunityId = profitOpportunityReference.Id;

                                ColumnSet profitOppColumns = new ColumnSet(_proOppAttrCloseDate, _proOppAttrCloseDate, _proOppAttrModifiedDateTime);
                                Entity profitOpportunity = GetEntityRecord(ref service, _entProfitOpportunity, _profitOpportunityId, profitOppColumns);

                                if (profitOpportunity != null)
                                {
                                    if (profitOpportunity.Attributes.Contains(_proOppAttrCloseDate) && opportunity.Attributes.Contains(_oppAttrActualCloseDate))
                                    {
                                        //log.Info(String.Format("Upading {0} - {1}", opportunity.Id, opportunity.Attributes[_oppAttrName]));
                                        lostDate = DateTime.ParseExact(profitOpportunity.GetAttributeValue<string>(_proOppAttrCloseDate), "MM/dd/yy", CultureInfo.InvariantCulture);
                                        opportunity.Attributes[_oppAttrActualCloseDate] = lostDate;
                                        log.Info(String.Format("Lost Date {0} - {1}", profitOpportunity.GetAttributeValue<string>(_proOppAttrCloseDate), lostDate.ToString("MM/dd/yyy")));
                                        service.Update(opportunity);
                                    }
                                }
                            }
                            else
                            {
                                log.Warn(String.Format("History record for opportunity id {0} could not be found.", opportunity.Id));
                            }
                        }
                        catch (Exception ex)
                        {
                            log.Error("Error occured.", ex);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Obtain the AuthenticationCredentials based on AuthenticationProviderType.
        /// </summary>
        /// <param name="service">A service management object.</param>
        /// <param name="endpointType">An AuthenticationProviderType of the CRM environment.</param>
        /// <returns>Get filled credentials.</returns>
        private AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);
                    break;
            }

            return authCredentials;
        }

        /// <summary>
        /// Discovers the organizations that the calling user belongs to.
        /// </summary>
        /// <param name="service">A Discovery service proxy instance.</param>
        /// <returns>Array containing detailed information on each organization that 
        /// the user belongs to.</returns>
        public OrganizationDetailCollection DiscoverOrganizations(
            IDiscoveryService service)
        {
            if (service == null) throw new ArgumentNullException("service");
            RetrieveOrganizationsRequest orgRequest = new RetrieveOrganizationsRequest();
            RetrieveOrganizationsResponse orgResponse =
                (RetrieveOrganizationsResponse)service.Execute(orgRequest);

            return orgResponse.Details;
        }

        /// <summary>
        /// Finds a specific organization detail in the array of organization details
        /// returned from the Discovery service.
        /// </summary>
        /// <param name="orgUniqueName">The unique name of the organization to find.</param>
        /// <param name="orgDetails">Array of organization detail object returned from the discovery service.</param>
        /// <returns>Organization details or null if the organization was not found.</returns>
        /// <seealso cref="DiscoveryOrganizations"/>
        public OrganizationDetail FindOrganization(string orgUniqueName,
            OrganizationDetail[] orgDetails)
        {
            if (String.IsNullOrWhiteSpace(orgUniqueName))
                throw new ArgumentNullException("orgUniqueName");
            if (orgDetails == null)
                throw new ArgumentNullException("orgDetails");
            OrganizationDetail orgDetail = null;

            foreach (OrganizationDetail detail in orgDetails)
            {
                if (String.Compare(detail.UniqueName, orgUniqueName,
                    StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    orgDetail = detail;
                    break;
                }
            }
            return orgDetail;
        }

        /// <summary>
        /// Generic method to obtain discovery/organization service proxy instance.
        /// </summary>
        /// <typeparam name="TService">
        /// Set IDiscoveryService or IOrganizationService type to request respective service proxy instance.
        /// </typeparam>
        /// <typeparam name="TProxy">
        /// Set the return type to either DiscoveryServiceProxy or OrganizationServiceProxy type based on TService type.
        /// </typeparam>
        /// <param name="serviceManagement">An instance of IServiceManagement</param>
        /// <param name="authCredentials">The user's Microsoft Dynamics CRM logon credentials.</param>
        /// <returns></returns>
        private TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        /// <summary>
        /// This function is used to retrieve the optionset value using the optionset text label
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedLabel"></param>
        /// <returns></returns>
        private static int GetOptionsSetValueForLabel(IOrganizationService service, string entityName, string attributeName, string selectedLabel)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            int selectedOptionValue = 0;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                {
                    selectedOptionValue = oMD.Value.Value;
                    break;
                }
            }
            return selectedOptionValue;
        }

        /// <summary>
        /// This function is used to retrieve the optionset labek using the optionset value
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedValue"></param>
        /// <returns></returns>
        private static string GetOptionsSetTextForValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = null;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.LocalizedLabels[0].Label.ToString();
                    break;
                }
            }
            return selectedOptionLabel;
        }

        private static EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue)
        {
            ColumnSet indexCol = new ColumnSet(true);

            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = indexCol;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private static EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.ColumnSet = columnSet;
            indexAttribute.AddAttributeValue(columnName, columnValue);
            //indexAttribute.AddAttributeValue("spg_stage", 1);
            indexAttribute.AddAttributeValue("statecode", 1);
            //indexAttribute.Attributes.AddRange(new string[] { columnName });
            //indexAttribute.Values.AddRange(columnValue);

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private static Entity GetEntityRecord(ref IOrganizationService service, string entityName, Guid recordId, ColumnSet columnSet)
        {
            return service.Retrieve(entityName, recordId, columnSet);
        }
    }
}
