﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Client;
using Microsoft.Xrm.Client.Services;
using System.Text;
using System.Threading.Tasks;

namespace Matrix_Enrollment_Duplication_Check_DLL
{
    public class DuplicationCheckClass
    {
        private CrmConnection _connection;
        private OrganizationService service;
        private string _connectionstring = string.Empty;


        private static EntityCollection GetEntityRecords(ref OrganizationService service, string entityName, string[] columnAttributeName, object[] columnAttributeValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.ColumnSet = columnSet;
            indexAttribute.Attributes.AddRange(columnAttributeName);
            indexAttribute.Values.AddRange(columnAttributeValue);
            indexAttribute.AddOrder("createdon", OrderType.Descending);
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        public string[] DuplicationCheck(string customerName, string userName, string password, string url)
        {
            try
            {
                string[] arr = new string[2] {string.Empty, string.Empty};
                _connectionstring = string.Format("Url = {0}; Username={1}; Password={2}; authtype=IFD/", url, userName, password);
                _connection = CrmConnection.Parse(_connectionstring);
                service = new OrganizationService(_connection);
                if (service != null)
                {
                    EntityCollection CustomerCollection = GetEntityRecords(ref service, "account", new string[] { "name" }, new[] { customerName }, new ColumnSet("name"));
                    if (CustomerCollection.Entities.Count > 0)
                    {
                        Guid CustomerID = new Guid(CustomerCollection.Entities[0].Attributes["accountid"].ToString());
                        EntityCollection OppCollection = GetEntityRecords(ref service, "opportunity", new string[] { "parentaccountid" }, new[] { CustomerID.ToString() }, new ColumnSet("name"));
                        if (OppCollection.Entities.Count > 0)
                        {
                            arr[0] = OppCollection.Entities[0].Attributes["name"].ToString();
                            arr[1] = true.ToString();
                            return arr;
                        }
                        arr[0] = true.ToString();
                        return arr;
                    }
                    else
                    {
                        arr[0] = false.ToString();
                        return arr;
                    }
                }
                else
                {
                    arr[0] = false.ToString();
                    return arr;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

    }
}

