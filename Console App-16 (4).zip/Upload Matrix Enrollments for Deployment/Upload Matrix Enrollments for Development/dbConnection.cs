﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Upload_Matrix_Enrollments
{
    public class dbConnection
    {

        private SqlDataAdapter myAdapter;
        private SqlConnection conn;

        /// <constructor>
        /// Initialise Connection
        /// </constructor>
        /// 

        public dbConnection()
        {
            myAdapter = new SqlDataAdapter();

            // conn = new SqlConnection(@"Data Source=192.168.50.20,1433;Initial Catalog=HRMS;user=developers;password=123;");
            //conn = new SqlConnection(@"Data Source=192.168.10.102;Initial Catalog=MasoftHrms;user=sa;password=123;");
            //   conn = new SqlConnection(@"Data Source=(localdb)\v11.0;Initial Catalog=MasoftHrms;");
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MatrixEnrollments"].ConnectionString);

        }
        #region dbConnectionState
        private void closeConnection()
        {
            if (conn.State == ConnectionState.Open)
                conn.Close();
        }

        /// <method>
        /// Open Database Connection if Closed or Broken
        /// </method>
        private SqlConnection openConnection()
        {
            if (conn.State == ConnectionState.Closed || conn.State ==
                        ConnectionState.Broken)
            {
                conn.Open();
            }
            return conn;
        }

        #endregion

        #region CrudeOprations
        /// <method>
        /// Select Query With Out Parameters
        /// </method>
        public DataTable executeSelectQuery(String _query)
        {
            SqlCommand myCommand = new SqlCommand();
            DataTable dataTable = new DataTable();
            dataTable = null;
            DataSet ds = new DataSet();

            myCommand.Connection = openConnection();
            myCommand.CommandText = _query;
            myCommand.ExecuteNonQuery();
            myAdapter.SelectCommand = myCommand;
            myAdapter.Fill(ds);
            dataTable = ds.Tables[0];
            closeConnection();
            return dataTable;
        }

        /// <method>
        /// Select Query with Parameters
        /// </method>
        public DataTable executeSelectQuery(String _query, SqlParameter[] sqlParameters)
        {
            SqlCommand myCommand = new SqlCommand();
            DataTable dataTable = new DataTable();
            dataTable = null;
            DataSet ds = new DataSet();

            myCommand.Connection = openConnection();
            myCommand.CommandText = _query;
            myCommand.Parameters.AddRange(sqlParameters);
            myCommand.ExecuteNonQuery();
            myAdapter.SelectCommand = myCommand;
            myAdapter.Fill(ds);
            dataTable = ds.Tables[0];
            closeConnection();

            return dataTable;
        }


        /// <method>
        /// Insert Query with Parameters
        /// </method>
        public bool executeInsertQuery(String _query, SqlParameter[] sqlParameters)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = openConnection();
            myCommand.CommandText = _query;
            myCommand.Parameters.AddRange(sqlParameters);
            myAdapter.InsertCommand = myCommand;
            myCommand.ExecuteNonQuery();
            closeConnection();
            return true;
        }

        /// <method>
        /// Update Query with parameters
        /// </method>
        public bool executeUpdateQuery(String _query)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = openConnection();
            myCommand.CommandText = _query;
            myAdapter.UpdateCommand = myCommand;
            myCommand.ExecuteNonQuery();
            closeConnection();
            return true;
        }
        #endregion
    }
}
