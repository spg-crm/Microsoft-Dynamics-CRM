﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System.Data;
using System.Configuration;
using System.Text;
using System.ServiceModel.Description;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Client;
using Microsoft.Xrm.Client.Services;
using System.Collections.Generic;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace Upload_Matrix_Enrollments
{
    class Program
    {

        dbConnection con;

        static void Main(string[] args)
        {
            try
            {
                log.Info("App started.");
                //Console.Write("App started.");
                Program app = new Program();
                app.Run();
                log.Info(String.Format("App completed.{0}", Environment.NewLine));
                //Console.Write(String.Format("App completed.{0}", Environment.NewLine));
            }
            catch (Exception ex)
            {
                log.Error("Error occured.", ex);
                Console.Write("Error occured. ," + ex);
                //Console.ReadLine();
            }

        }

        private void Run()
        {
            GetTableRecords(_query);
            UploadMatrixEnrollments();
        }

        private void UploadMatrixEnrollments()
        {
            _connectionstring = string.Format("Url={0}/{1}", _serverUrl, _organizationUniqueName);
            _connection = CrmConnection.Parse(_connectionstring);
            service = new OrganizationService(_connection);
            List<Entity> OpportunityList = new List<Entity>();

            DateTime lastsuccessfulrun = GetLastSuccessfulRunDate(service);
            lastsuccessfulrun = lastsuccessfulrun.ToLocalTime();
            int Count = 0;
            Entity matrixenrollment = new Entity(_matrixenrollment);
            string name = string.Empty;
            Guid customerid = Guid.Empty;
            Guid Oppid = Guid.Empty;
            Guid accid = Guid.Empty;
            DataView dv = new DataView(dt);
            //dv.RowFilter = "Date > #" + lastsuccessfulrun + "# AND Date < #" + DateTime.Now.ToLocalTime() + "#";
            EntityCollection customercollection = null;
            EntityCollection marketercollection = null;
            EntityCollection oppcollection = null;
            EntityCollection contractcollection = null;
            EntityCollection contactcollection = null;
            EntityCollection brokercollection = null;
            EntityCollection brokeragentcollection = null;
            EntityCollection usercollection = null;
            EntityReference _brokerRef = null;
            EntityReference _customerRef = null;
            EntityReference _contactRef = null;
            EntityReference _brokeragentRef = null;
            EntityReference _utilityRef = null;
            EntityReference _userRef = null;
            foreach (DataRowView dr in dv)
            {

                log.Info("Before get utility entity 2");
                Entity utilityent = GetUtilityEntity(ref service, dr["Utility"].ToString());
                log.Info(string.Format("Get Utility Completed{0}", utilityent.Id));
                name = dr["BusinessName"].ToString() + "-" + dr["Utility"].ToString();
                if (utilityent.Id != Guid.Empty)
                {
                    _utilityRef = new EntityReference(utilityent.LogicalName, utilityent.Id);
                    matrixenrollment.Attributes[_utility] = _utilityRef;
                    integrationLogFind.Append("Utility");
                    string contactname = dr["FirstName"].ToString() + ' ' + dr["LastName"].ToString();
                    contactcollection = GetEntityRecords(ref service, _contact, new string[] { _fullname }, new[] { contactname }, new ColumnSet(true));
                    if (contactcollection.Entities.Count == 0)
                    {
                        Entity contactentity = new Entity(_contact);
                        contactentity.Attributes[_firstnamecontact] = dr["FirstName"].ToString();
                        contactentity.Attributes[_lastnamecontact] = dr["LastName"].ToString();
                        Guid contactid = service.Create(contactentity);
                        _contactRef = new EntityReference(_contact, contactid);
                        matrixenrollment.Attributes[_contactlookup] = _contactRef;
                        log.Info(String.Format("Contact Added With Name{0} {1}", dr["FirstName"].ToString(), dr["LastName"].ToString()));
                        integrationLogCreate.Append("Contact");
                    }
                    else
                    {
                        Guid contactid = new Guid(contactcollection.Entities[0][_contactguid].ToString());
                        _contactRef = new EntityReference(_contact, contactid);
                        matrixenrollment.Attributes[_contactlookup] = _contactRef;
                        //matrixenrollment.Attributes[_businessname] = _customerRef;
                        log.Info(String.Format("Contact ({0} {1}) selected for Matrix{2}", dr["FirstName"].ToString(), dr["LastName"].ToString(), name));
                        integrationLogFind.Append(",Contact");
                    }

                    if (dr["Master"] != DBNull.Value || dr["Master"].ToString() != "")
                    {

                        usercollection = GetEntityRecords(ref service, _userentity, new string[] { _systemusername }, new[] { dr["Master"] }, new ColumnSet(true));
                        if (usercollection.Entities.Count > 0)
                        {
                            _userRef = new EntityReference(usercollection.Entities[0].LogicalName, usercollection.Entities[0].Id);
                            matrixenrollment.Attributes[_master] = _userRef;
                            log.Info(string.Format("User selected with User Name {0}", dr["Master"].ToString()));
                            integrationLogFind.Append(",Master");
                        }
                        else
                        {
                            log.Info(string.Format("User not found with User Name {0}", dr["Master"].ToString()));
                            integrationLogNotMatched.Append(",Master");
                        }
                    }

                    customercollection = GetEntityRecords(ref service, _customer, new string[] { _customername }, new[] { dr["BusinessName"] }, new ColumnSet(true));
                    if (customercollection.Entities.Count == 0)
                    {
                        Entity customer = new Entity(_customer);
                        customer.Attributes[_customername] = dr["BusinessName"].ToString();
                        customer.Attributes[_primarycontact] = _contactRef;
                        customerid = service.Create(customer);
                        _customerRef = new EntityReference(_customer, customerid);
                        matrixenrollment.Attributes[_businessname] = _customerRef;
                        log.Info(String.Format("Customer Added With Name{0}", dr["BusinessName"].ToString()));
                        integrationLogCreate.Append(",Customer");
                    }
                    else
                    {
                        Entity customer = customercollection.Entities[0];
                        customer.Attributes[_primarycontact] = _contactRef;
                        customerid = new Guid(customer.Attributes[_accountguid].ToString());
                        _customerRef = new EntityReference(_customer, customerid);
                        matrixenrollment.Attributes[_businessname] = _customerRef;
                        log.Info(String.Format("Customer ({0}) selected for Matrix{1}", customercollection.Entities[0][_customername].ToString(), name));
                        service.Update(customer);
                        integrationLogFind.Append(",Customer");
                    }
                    if (dr["Agent"] != DBNull.Value || dr["Agent"].ToString() != string.Empty)
                    {
                        brokercollection = GetEntityRecords(ref service, _broker, new string[] { _brokercode }, new[] { dr["Agent"] }, new ColumnSet(true));
                        if (brokercollection.Entities.Count > 0)
                        {
                            _brokerRef = new EntityReference(brokercollection.Entities[0].LogicalName, brokercollection.Entities[0].Id);
                            matrixenrollment.Attributes[_agent] = _brokerRef;
                            log.Info(string.Format("Agent selected with code {0}", dr["Agent"].ToString()));
                            integrationLogFind.Append(",Broker");
                        }
                        else
                        {
                            log.Info(string.Format("Agent not found with code {0}", dr["Agent"].ToString()));
                            integrationLogNotMatched.Append("Agent");
                        }
                    }

                    if (dr["Subagent"] != DBNull.Value || dr["Subagent"].ToString() != string.Empty)
                    {
                        brokeragentcollection = GetEntityRecords(ref service, _contact, new string[] { _brokeragentcode }, new[] { dr["Subagent"] }, new ColumnSet(true));
                        if (brokeragentcollection.Entities.Count > 0)
                        {
                            _brokeragentRef = new EntityReference(brokeragentcollection.Entities[0].LogicalName, brokeragentcollection.Entities[0].Id);
                            matrixenrollment.Attributes[_subagent] = _brokeragentRef;
                            log.Info(string.Format("Subagent selected with code {0}", dr["Subagent"].ToString()));
                            integrationLogFind.Append(",Broker Agent");
                        }
                        else
                        {
                            log.Info(string.Format("Subagent not found with code {0}", dr["Subagent"].ToString()));
                            integrationLogNotMatched.Append(",Subagent");
                        }
                    }


                    if (dr["LoadFactor"].ToString() != null && dr["LoadFactor"].ToString() != "")
                    {
                        loadfactorvalue.Value = GetOptionsSetValueForLabel(service, _matrixenrollment, _loadfactor, dr["LoadFactor"].ToString());
                    }
                    if (dr["HistoricalUsageInd"].ToString() != null && dr["HistoricalUsageInd"].ToString() != "")
                    {
                        historicalusage.Value = GetOptionsSetValueForLabel(service, _matrixenrollment, _historicalusageind, dr["HistoricalUsageInd"].ToString());
                    }
                    if (dr["Commodity"].ToString() != null && dr["Commodity"].ToString() != "")
                    {
                        commodityvalue.Value = GetOptionsSetValueForLabel(service, _matrixenrollment, _commodity, dr["Commodity"].ToString());
                    }
                    if (dr["NewRenew"].ToString() != null && dr["NewRenew"].ToString() != "")
                    {
                        neworrenewvalue.Value = GetOptionsSetValueForLabel(service, _matrixenrollment, _neworrenew, dr["NewRenew"].ToString());
                    }
                    if (dr["BrokerType"].ToString() != null && dr["BrokerType"].ToString() != "")
                    {
                        brokertypevalue.Value = GetOptionsSetValueForLabel(service, _matrixenrollment, _brokertype, dr["BrokerType"].ToString());
                    }
                    if (dr["EnrollTypeDesc"].ToString() != null && dr["EnrollTypeDesc"].ToString() != "")
                    {
                        enrolltypedescvalue.Value = GetOptionsSetValueForLabel(service, _matrixenrollment, _enrolltypedesc, dr["EnrollTypeDesc"].ToString());
                    }
                    if (dr["ComissionType"].ToString() != null && dr["ComissionType"].ToString() != "")
                    {
                        commissiontypevalue.Value = GetOptionsSetValueForLabel(service, _matrixenrollment, _commissiontype, dr["ComissionType"].ToString());
                    }

                    matrixenrollment.Attributes[_name] = name;
                    matrixenrollment.Attributes[_firstname] = dr["FirstName"].ToString();
                    matrixenrollment.Attributes[_lastname] = dr["LastName"].ToString();
                    matrixenrollment.Attributes[_primaryphone] = dr["PrimaryPhoneNumber"].ToString();
                    matrixenrollment.Attributes[_servicestreetaddress] = dr["ServiceStreetAddress"].ToString();
                    matrixenrollment.Attributes[_servicestreetaddress2] = dr["ServiceStreetAddress2"].ToString();
                    matrixenrollment.Attributes[_servicecity] = dr["ServiceCity"].ToString();
                    matrixenrollment.Attributes[_servicestate] = dr["ServiceState"].ToString();
                    matrixenrollment.Attributes[_servicezipcode] = dr["ServiceZipCode"].ToString();
                    matrixenrollment.Attributes[_mailingaddress] = dr["MailingStreetAddress"].ToString();
                    matrixenrollment.Attributes[_mailingaddress2] = dr["MailingStreetAddress2"].ToString();
                    matrixenrollment.Attributes[_mailingcity] = dr["MailingCity"].ToString();
                    matrixenrollment.Attributes[_mailingstate] = dr["MailingState"].ToString();
                    matrixenrollment.Attributes[_mailingzipcode] = dr["MailingZipCode"].ToString();
                    matrixenrollment.Attributes[_utilitycode] = dr["UtilityCode"].ToString();
                    matrixenrollment.Attributes[_requestedstartdate] = Convert.ToDateTime(dr["RequestedStartDate"].ToString());
                    matrixenrollment.Attributes[_contractterms] = dr["ContractTerms_Months"].ToString();
                    matrixenrollment.Attributes[_contractrate] = Convert.ToDecimal(dr["ContractRate"].ToString());
                    matrixenrollment.Attributes[_meterfee] = new Money((decimal)dr["MeterFee"]);
                    matrixenrollment.Attributes[_basisincl] = dr["BasisIncl"].ToString();
                    matrixenrollment.Attributes[_contracttype] = dr["ContractType"].ToString();
                    matrixenrollment.Attributes[_revenueclassdesc] = dr["RevenueClassDesc"].ToString();
                    matrixenrollment.Attributes[_brokerfee] = new Money((decimal)dr["BrokerFee"] * 1000);
                    matrixenrollment.Attributes[_businesstype] = dr["BusinessType"].ToString();
                    matrixenrollment.Attributes[_monthlyusage] = dr["MonthlyUsage"].ToString();
                    matrixenrollment.Attributes[_contractstatus] = dr["Account_Status"].ToString();
                    matrixenrollment.Attributes[_emailaddress] = dr["EmailAddress"].ToString();
                    if (dr["IsMultiUtilities"] != DBNull.Value)
                    {
                        matrixenrollment.Attributes[_isMultiUtilities] = dr["IsMultiUtilities"];
                    }
                    //matrixenrollment.Attributes[_annualusage] = dr["AnnualUsage"].ToString();
                    if (dr["RateClass"] != DBNull.Value)
                    {
                        matrixenrollment.Attributes[_rateclass] = dr["RateClass"].ToString();
                    }
                    if (dr["LoadFactor"] != DBNull.Value)
                    {

                        if (loadfactorvalue.Value != 0)
                        {
                            matrixenrollment.Attributes.Add(_loadfactor, new OptionSetValue(loadfactorvalue.Value));
                        }
                    }

                    matrixenrollment.Attributes[_processtype] = dr["ProcessType"].ToString();
                    if (historicalusage.Value != null && historicalusage.Value != 0)
                    {
                        matrixenrollment.Attributes.Add(_historicalusageind, new OptionSetValue(historicalusage.Value));

                    }
                    if (commodityvalue.Value != null && commodityvalue.Value != 0)
                    {
                        matrixenrollment.Attributes.Add(_commodity, new OptionSetValue(commodityvalue.Value));

                    }
                    if (enrolltypedescvalue.Value != null && enrolltypedescvalue.Value != 0)
                    {
                        matrixenrollment.Attributes.Add(_enrolltypedesc, new OptionSetValue(enrolltypedescvalue.Value));

                    }
                    if (commissiontypevalue.Value != null && commissiontypevalue.Value != 0)
                    {
                        matrixenrollment.Attributes.Add(_commissiontype, new OptionSetValue(commissiontypevalue.Value));

                    }
                    matrixenrollment.Attributes[_county] = dr["County"].ToString();
                    matrixenrollment.Attributes[_statusdesc] = dr["StatusDesc"].ToString();
                    matrixenrollment.Attributes[_combinenameind] = dr["CombineNameInd"].ToString();
                    if (dr["MarketerName"] != DBNull.Value || dr["MarketerName"].ToString() != "")
                    {
                        marketercollection = GetEntityRecords(ref service, _marketer, new string[] { _marketername }, new[] { dr["MarketerName"] }, new ColumnSet(true));
                        if (marketercollection.Entities.Count != 0)
                        {
                            Guid marketerid = (Guid)marketercollection.Entities[0].Attributes[_marketerid];
                            matrixenrollment.Attributes[_marketernamelookup] = new EntityReference(_marketer, marketerid);
                            log.Info(string.Format("Marketer selected with name {0}", dr["MarketerName"].ToString()));
                            integrationLogFind.Append(",Marketer");
                        }
                        else
                        {
                            log.Info(string.Format("Marketer not found with name {0}", dr["MarketerName"].ToString()));
                            integrationLogNotMatched.Append(",Marketer");
                        }
                    }

                    if (dr["ComissionTerms"] != DBNull.Value || dr["ComissionTerms"].ToString() != "")
                    {
                        EntityCollection brokerpaymethodcollection = GetEntityRecords(ref service, _brokerpaymethod, new string[] { _brokerpayname }, new[] { dr["ComissionTerms"] }, new ColumnSet(true));
                        if (brokerpaymethodcollection.Entities.Count > 0)
                        {
                            Guid brokerpayid = (Guid)brokerpaymethodcollection.Entities[0].Attributes[_brokerpayguid];
                            matrixenrollment.Attributes[_commissionterms] = new EntityReference(_brokerpaymethod, brokerpayid);
                            log.Info(string.Format("Brokerpay method selected as {0}", dr["ComissionTerms"].ToString()));
                            integrationLogFind.Append(",Brokerpay Method");
                        }
                        else
                        {
                            log.Info(string.Format("Brokerpay method not found as {0}", dr["ComissionTerms"].ToString()));
                            integrationLogNotMatched.Append(",Borkerpay Method");
                        }
                    }

                    //matrixenrollment.Attributes[_oppname] = dr["OpportunityName"].ToString();
                    if (dr["OpportunityName"] != DBNull.Value || dr["OpportunityName"].ToString() != "")
                    {
                        oppcollection = GetEntityRecords(ref service, _opportunity, new string[] { _oppname }, new[] { dr["OpportunityName"] }, new ColumnSet(true));
                        Entity oppent = new Entity(_opportunity);
                        
                        Entity customerent = GetCustomerEntity(ref service, dr["BusinessName"].ToString());
                        if (oppcollection.Entities.Count <= 0)
                        {
                            oppent.Attributes[_oppname] = dr["OpportunityName"].ToString();
                            if (customerent != null)
                            {
                                // oppent.Attributes["parentaccountid"] = new EntityReference(customerent.LogicalName, Guid.Empty);
                                oppent.Attributes["parentaccountid"] = new EntityReference(customerent.LogicalName, customerent.Id);
                                oppent.Attributes["customerid"] = new EntityReference(customerent.LogicalName, customerent.Id);
                            }
                            switch (dr["MarketerName"].ToString())
                            {
                                case "Source Power & Gas LLC":
                                    {
                                        oppent.Attributes[_marketregionopp] = new EntityReference(_marketregion, new Guid("17003DA9-F476-E511-80C5-000D3A90E5FA"));
                                        break;
                                    }
                                case "Source Power & Gas LLC NT":
                                    {
                                        oppent.Attributes[_marketregionopp] = new EntityReference(_marketregion, new Guid("C03B13B0-F476-E511-80C5-000D3A90E5FA"));
                                        break;
                                    }
                                default:
                                    {
                                        break;
                                    }

                            }
                            Oppid = service.Create(oppent);
                            Entity OpportunityObject = new Entity();
                            OpportunityObject.LogicalName = "opportunity";

                            OpportunityObject.Id = Oppid;
                            OpportunityList.Add(OpportunityObject);//Adding Opportunity Object To execute Account Integration later on in code

                            matrixenrollment.Attributes[_oppname] = dr["OpportunityName"].ToString();
                            matrixenrollment.Attributes[_opplookup] = new EntityReference(_opportunity, Oppid);
                            log.Info(String.Format("Opportunity Added With Name{0}", dr["OpportunityName"].ToString()));
                            integrationLogCreate.Append(",Opportunity");
                        }
                        else
                        {
                            oppent = oppcollection.Entities[0];
                            OpportunityList.Add(oppent);//Adding Opportunity Object To execute Account Integration later on in code
                            matrixenrollment.Attributes[_oppname] = dr["OpportunityName"].ToString();
                            Oppid = (Guid)oppcollection.Entities[0].Attributes["opportunityid"];
                            matrixenrollment.Attributes[_opplookup] = new EntityReference(oppent.LogicalName, Oppid);
                            if (customerent != null)
                            {
                                //oppent.Attributes["parentaccountid"] = new EntityReference(customerent.LogicalName, Guid.Empty);
                                oppent.Attributes["parentaccountid"] = new EntityReference(customerent.LogicalName, customerent.Id);
                                oppent.Attributes["customerid"] = new EntityReference(customerent.LogicalName, customerent.Id);
                            }
                            switch (dr["MarketerName"].ToString())
                            {
                                case "Source Power & Gas LLC":
                                    {
                                        oppent.Attributes[_marketregionopp] = new EntityReference(_marketregion, new Guid("17003DA9-F476-E511-80C5-000D3A90E5FA"));
                                        break;
                                    }
                                case "Source Power & Gas LLC NT":
                                    {
                                        oppent.Attributes[_marketregionopp] = new EntityReference(_marketregion, new Guid("C03B13B0-F476-E511-80C5-000D3A90E5FA"));
                                        break;
                                    }
                                default:
                                    {
                                        break;
                                    }
                            }
                            log.Info(String.Format("Opportunity Selected With Name{0}", dr["OpportunityName"].ToString()));
                            integrationLogFind.Append(",Opportunity");
                            service.Update(oppent);
                        }
                    }
                    if (dr["ContractType"] != DBNull.Value || dr["ContractType"].ToString() != "")
                    {
                        Entity oppproductentity = new Entity(_opportunityproduct);
                        bool oppproductflag = false;
                        Guid oppproductid = Guid.Empty;
                        switch (dr["Market_Region"].ToString())
                        {
                            case "ERCOT":
                                {
                                    switch (dr["ContractType"].ToString())
                                    {
                                        case "Less than 50 kW":
                                            {
                                                GetOppProducts(ref service, _lessthan50, Oppid, out oppproductid, out oppproductflag);
                                                if (oppproductflag == false)
                                                {
                                                    oppproductentity.Attributes[_product] = new EntityReference(_productentity, _lessthan50);
                                                    log.Info("Product Selected With Name Fixed Price <50kWh");
                                                    oppproductentity.Attributes[_basiscongestion] = dr["BasisIncl"];
                                                    oppproductid = service.Create(oppproductentity);
                                                    integrationLogCreate.Append(",Opportunity Product");
                                                    log.Info("Opportunity Product Added With Name Fixed Price <50kWh");

                                                }
                                                else
                                                {
                                                    oppproductentity.Attributes[_product] = new EntityReference(_productentity, _lessthan50);
                                                    log.Info("Product Selected With Name Fixed Price <50kWh");
                                                    oppproductentity.Attributes[_basiscongestion] = dr["BasisIncl"];
                                                    integrationLogFind.Append(",Opportunity Product");
                                                    log.Info("Opportunity Product Selected With Name Fixed Price <50kWh");
                                                }

                                                break;
                                            }
                                        default:
                                            {
                                                GetOppProducts(ref service, _greaterthan50, Oppid, out oppproductid, out oppproductflag);
                                                if (oppproductflag == false)
                                                {
                                                    oppproductentity.Attributes[_product] = new EntityReference(_productentity, _greaterthan50);
                                                    log.Info("Product Selected With Name Fixed Price");
                                                    oppproductentity.Attributes[_basiscongestion] = dr["BasisIncl"];
                                                    oppproductid = service.Create(oppproductentity);
                                                    integrationLogCreate.Append(",Opportunity Product");
                                                    log.Info("Opportunity Product Added With Name Fixed Price");
                                                }
                                                else
                                                {
                                                    oppproductentity.Attributes[_product] = new EntityReference(_productentity, _greaterthan50);
                                                    log.Info("Product Selected With Name Fixed Price");
                                                    oppproductentity.Attributes[_basiscongestion] = dr["BasisIncl"];
                                                    integrationLogFind.Append(",Opportunity Product");
                                                    log.Info("Opportunity Product Selected With Name Fixed Price");
                                                }
                                                break;
                                            }
                                    }
                                    break;
                                }
                            case "PJM":
                                {
                                    GetOppProducts(ref service, _greaterthan50, Oppid, out oppproductid, out oppproductflag);
                                    if (oppproductflag == false)
                                    {
                                        oppproductentity.Attributes[_product] = new EntityReference(_productentity, _greaterthan50);
                                        log.Info("Product Selected With Name Fixed Price");
                                        oppproductentity.Attributes[_basiscongestion] = dr["BasisIncl"];
                                        oppproductid = service.Create(oppproductentity);
                                        integrationLogCreate.Append(",Opportunity Product");
                                        log.Info("Opportunity Product Added With Name Fixed Price");
                                    }
                                    else
                                    {
                                        oppproductentity.Attributes[_product] = new EntityReference(_productentity, _greaterthan50);
                                        log.Info("Product Selected With Name Fixed Price");
                                        oppproductentity.Attributes[_basiscongestion] = dr["BasisIncl"];
                                        integrationLogFind.Append(",Opportunity Product");
                                        log.Info("Opportunity Product Selected With Name Fixed Price");
                                    }
                                    break;
                                }

                        }


                        if (oppproductid != null && oppproductid != Guid.Empty)
                        {
                            OpportunityProductAssociationWithOpportunity(oppproductentity, Oppid, oppproductid, new Relationship("spg_opportunity_spg_opportunityproduct_Opportunity"), ref service);
                        }
                    }

                    log.Info("Before get utility entity 1");
                    if (dr["LDCAccountNumber"] != DBNull.Value || dr["LDCAccountNumber"].ToString() != "")
                    {

                        bool IsRecordExist = GetAccounts(ref service, dr["LDCAccountNumber"].ToString(), dr["BusinessName"].ToString(), utilityent.Id);
                        log.Info(string.Format("Get Accounts Completed{0}", IsRecordExist));
                        //Check if Account is already Exist...
                        if (IsRecordExist == false)
                        {
                            Entity accent = new Entity(_accounts);
                            accid = CreateAccountsRecord(dr["LDCAccountNumber"].ToString(), dr["BusinessName"].ToString(), Oppid.ToString(), dr["MarketerName"].ToString(), accent, matrixenrollment, utilityent, ref service);
                        }
                        else
                        {
                            Entity accent = GetAccountRecords(ref service, dr["LDCAccountNumber"].ToString());
                            accent.Attributes[_accname] = dr["LDCAccountNumber"].ToString();
                            accent.Attributes["spg_customername"] = dr["BusinessName"].ToString();
                            accent.Attributes["spg_utility"] = new EntityReference(utilityent.LogicalName, utilityent.Id);
                            accid = new Guid(accent[_accountsid].ToString());
                            if (accent != null && accid != Guid.Empty)
                            {
                                AccountsAssociationWithOpportunity(new EntityReference(_opportunity, Oppid), new EntityReference(accent.LogicalName, accent.Id), ref service);
                            }
                            matrixenrollment.Attributes[_accountlookup] = new EntityReference(_accounts, accid);
                            matrixenrollment.Attributes[_ldcaccountno] = dr["LDCAccountNumber"].ToString();
                            switch (dr["MarketerName"].ToString())
                            {
                                case "Source Power & Gas LLC":
                                    {
                                        accent.Attributes[_marketregion] = new EntityReference(_marketer, new Guid("17003DA9-F476-E511-80C5-000D3A90E5FA"));
                                        break;
                                    }
                                case "Source Power & Gas LLC NT":
                                    {
                                        accent.Attributes[_marketregion] = new EntityReference(_marketer, new Guid("C03B13B0-F476-E511-80C5-000D3A90E5FA"));
                                        break;
                                    }
                                default:
                                    {
                                        break;
                                    }
                            }
                            log.Info(String.Format("Accounts Selected With Name{0}", dr["LDCAccountNumber"].ToString()));
                            integrationLogFind.Append(",Account");
                            service.Update(accent);
                        }
                    }
                    //if (dr["ContractRate"] != DBNull.Value && dr["MeterFee"] != DBNull.Value)
                    //{
                    //    Guid contractid = Guid.Empty;
                    //    Entity contractent = null;
                    //    Entity customerent = GetCustomerEntity(ref service, dr["BusinessName"].ToString());
                    //    Entity accountentity = GetAccountRecords(ref service, dr["LDCAccountNumber"].ToString());
                    //    Entity opportunityentity = GetOpportunityForContract(ref service, _opportunity, dr["OpportunityName"].ToString());
                    //    contractcollection = GetEntityRecords(ref service, _contracts, new string[] { "spg_name" }, new[] { dr["OpportunityName"] }, new ColumnSet(true));
                    //    if (contractcollection.Entities.Count <= 0)
                    //    {
                    //        contractent = new Entity(_contracts);
                    //        contractent.Attributes["spg_customer"] = _customerRef;
                    //        contractid = service.Create(contractent);
                    //        log.Info(String.Format("Contract added with Name{0}", dr["OpportunityName"].ToString()));
                    //        integrationLogCreate.Append(",Contract");
                    //        matrixenrollment.Attributes[_matrixcontract] = new EntityReference(contractent.LogicalName, contractid);
                    //        if (contractid != null && contractid != Guid.Empty)
                    //        {
                    //            ContractsAssociationWithAccount(new EntityReference(accountentity.LogicalName, accountentity.Id), new EntityReference(contractent.LogicalName, contractid), ref service);
                    //            ContractsAssociationWithOpportunity(contractent, opportunityentity.Id, contractid, new Relationship("spg_opportunity_spg_contract"), ref service);
                    //        }
                    //    }
                    //    else
                    //    {
                    //        contractent = contractcollection.Entities[0];
                    //        if (contractent != null)
                    //        {
                    //            matrixenrollment.Attributes[_matrixcontract] = new EntityReference(contractent.LogicalName, contractent.Id);
                    //            ContractsAssociationWithAccount(new EntityReference(accountentity.LogicalName, accountentity.Id), new EntityReference(contractent.LogicalName, contractent.Id), ref service);
                    //            ContractsAssociationWithOpportunity(contractent, opportunityentity.Id, contractent.Id, new Relationship("spg_opportunity_spg_contract"), ref service);
                    //            log.Info(String.Format("Contract selected with Name{0}", dr["OpportunityName"].ToString()));
                    //            integrationLogFind.Append(",Contract");
                    //        }
                    //    }
                    //}
                    matrixenrollment.Attributes[_brokercategory] = dr["BrokerCategory"].ToString();
                    if (brokertypevalue.Value != null && brokertypevalue.Value != 0)
                    {
                        matrixenrollment.Attributes.Add(_brokertype, new OptionSetValue(brokertypevalue.Value));

                    }

                    matrixenrollment.Attributes[_isfortexas] = dr["IsForTexas"].ToString();
                    matrixenrollment.Attributes[_matrixdate] = Convert.ToDateTime(dr["MatrixDate"].ToString());
                    matrixenrollment.Attributes[_dateadded] = Convert.ToDateTime(dr["DateAdded"].ToString());
                    matrixenrollment.Attributes[_specialtypebusiness] = dr["SpecialTypeBusiness"].ToString();
                    matrixenrollment.Attributes[_hundredpergreen] = dr["HundredPerGreen"].ToString();
                    if (neworrenewvalue.Value != null && neworrenewvalue.Value != 0)
                    {
                        matrixenrollment.Attributes.Add(_neworrenew, new OptionSetValue(neworrenewvalue.Value));

                    }
                    
                    if (dr["CalculatedBrokerFee"] != DBNull.Value)
                    {
                        matrixenrollment.Attributes[_calcbrokerfee] = Convert.ToDecimal(dr["CalculatedBrokerFee"]);
                    }
                    
                    if (dr["CalculatedContract"] != DBNull.Value)
                    {
                        matrixenrollment.Attributes[_calccontract] = Convert.ToDecimal(dr["CalculatedContract"]);
                    }
                    Guid matrixid = Guid.Empty;
                    try
                    {
                        matrixid = service.Create(matrixenrollment);
                        if (integrationLogCreate.Length > 0)
                        {
                            integrationLogCreate.Append(" Created for matrix enrollment");
                            if (integrationLogCreate.ToString().IndexOf(",") == 0)
                            {
                                integrationLogCreate.Remove(0, 1);
                            }
                            log.Info(integrationLogCreate);
                        }
                        if (integrationLogFind.Length > 0)
                        {
                            integrationLogFind.Append(" Matched/Updated for matrix enrollment");
                            if (integrationLogFind.ToString().IndexOf(",") == 0)
                            {
                                integrationLogFind.Remove(0, 1);
                            }
                            log.Info(integrationLogFind);
                        }
                        if (integrationLogNotMatched.Length > 0)
                        {
                            integrationLogNotMatched.Append(" Not matched for matrix enrollment");
                            if (integrationLogNotMatched.ToString().IndexOf(",") == 0)
                            {
                                integrationLogNotMatched.Remove(0, 1);
                            }
                            log.Info(integrationLogNotMatched);
                        }
                        matrixenrollment.Attributes.Clear();
                        if (Count <= 0)
                        {
                            log.Info(String.Format("Last Successful Run On {0}", lastsuccessfulrun));
                            Count += 1;
                            CreateIntegrationStatusRecord(DateTime.Now, ref service);
                        }
                        UpdateIsProcessed(Convert.ToInt32(dr["EnrollmentID"]));
                        CreateIntegrationLog(dr["ID"].ToString(), integrationLogFind.ToString(), integrationLogNotMatched.ToString(), integrationLogCreate.ToString(), Oppid, matrixid);
                        log.Info(string.Format("Matrix Enrollment Processed With Name {0}", name));
                        log.Info("-------------------------------------------------------------------------------------------------------------------------");
                    }
                    catch (Exception ex)
                    {
                        matrixenrollment.Attributes.Clear();
                        log.InfoFormat("matrix creation failed with ID: {0} and name: {1}. Reason: {2}", dr["ID"], dr["BusinessName"], ex.Message);
                        log.Info("-------------------------------------------------------------------------------------------------------------------------");
                    }
                    //Guid matrixid = service.Create(matrixenrollment);    
                }
                else
                {
                    integrationLogNotMatched.Append("Utility not matched for matrix enrollment");
                    log.Info(string.Format("Matrix Enrollment Failed With Name {0}", name));
                    CreateIntegrationLog(dr["ID"].ToString(), string.Empty, integrationLogNotMatched.ToString(), string.Empty, Guid.Empty, Guid.Empty);
                    log.Info(integrationLogNotMatched);
                    log.Info("-------------------------------------------------------------------------------------------------------------------------");
                }
               
               
                integrationLogCreate.Clear();
                integrationLogFind.Clear();
                integrationLogNotMatched.Clear();
            }
            List<string> RemoveOppListIds = new List<string>();
            foreach (Entity entity in OpportunityList)
            {
                if (!RemoveOppListIds.Contains(entity.Id.ToString()))
                {

                    if (entity.Attributes.Contains("spg_matrixenrollmentsaccountintegrationflag"))
                    {
                        entity.Attributes["spg_matrixenrollmentsaccountintegrationflag"] = "Yes";
                    }
                    else

                    {
                        entity.Attributes.Add("spg_matrixenrollmentsaccountintegrationflag", "Yes");
                    }
                      service.Update(entity);
                    RemoveOppListIds.Add(entity.Id.ToString());
                }
            }
            log.Info("Insertion Successfull");

            //}
            //}
        }

        private void CreateIntegrationLog(string EnrollmentCode, string MatchedString, string UnMatechedString, string CreatedString, Guid OppGuid, Guid MatrixGuid)
        {
            Entity _matrixlogent = new Entity(_matrixlog);
            if (OppGuid != Guid.Empty && MatrixGuid != Guid.Empty)
            {
                _matrixlogent.Attributes[_enrollmentcode] = EnrollmentCode;
                _matrixlogent.Attributes[_matchedRecords] = MatchedString;
                _matrixlogent.Attributes[_unmatchedrecords] = UnMatechedString;
                _matrixlogent.Attributes[_createdrecords] = CreatedString;
                _matrixlogent.Attributes[_integrationstatus] = "Success";
                _matrixlogent.Attributes[_opportunitylookup] = new EntityReference(_opportunity, OppGuid);
                _matrixlogent.Attributes[_matrixenrollmentlookup] = new EntityReference(_matrixenrollment, MatrixGuid);
            }
            else
            {
                _matrixlogent.Attributes[_enrollmentcode] = EnrollmentCode;
                _matrixlogent.Attributes[_unmatchedrecords] = UnMatechedString;
                _matrixlogent.Attributes[_integrationstatus] = "Fail";
            }
            service.Create(_matrixlogent);
        }

        private void UpdateIsProcessed(int ID)
        {
            con = new dbConnection();
            _query = @"UPDATE mu_Enrollments_CRMLog
                       SET IsProcessed = 1
                       WHERE EnrollmentID = " + ID;
            con.executeUpdateQuery(_query);
        }

        private DateTime GetLastSuccessfulRunDate(IOrganizationService _orgService)
        {
            const string _FetchExpression = "<fetch distinct='false' mapping='logical' aggregate='true'>" +
                "<entity name='spg_integrationstatusmatrixenrollments'>" +
                "<attribute name='spg_lastsuccessfulrunon' aggregate='max'  alias='spg_lastsuccessfulrunon'/>" +
                //"<order attribute='spg_lastsuccessfulrunon' descending='true' />" +
                "</entity>" +
                "</fetch>";
            const string _SPGLastSuccessfulRunOn = "spg_lastsuccessfulrunon";
            RetrieveMultipleRequest req = new RetrieveMultipleRequest();
            FetchExpression fetch = new FetchExpression(_FetchExpression);
            req.Query = fetch;
            RetrieveMultipleResponse resp = (RetrieveMultipleResponse)_orgService.Execute(req);

            EntityCollection integrationStatus = resp.EntityCollection;

            if (integrationStatus.Entities.Count > 0)
            {
                Entity intStatus = integrationStatus.Entities[0];

                if (intStatus.Attributes.Contains(_SPGLastSuccessfulRunOn))
                {
                    AliasedValue lastSuccessfulRun = new AliasedValue();
                    lastSuccessfulRun = (AliasedValue)intStatus.Attributes[_SPGLastSuccessfulRunOn];
                    return Convert.ToDateTime(lastSuccessfulRun.Value);
                }
            }
            else
            {
                throw new Exception("Record not found in Integration Status entity.");

            }
            return DateTime.Now;
        }

        private void CreateIntegrationStatusRecord(DateTime lastSuccessfulRunDate, ref OrganizationService service)
        {
            Entity integrationStatus = new Entity(_entIntegrationStatus);

            integrationStatus[_attrLastSuccessfulRunOn] = lastSuccessfulRunDate;
            //integrationStatus[_attrLastStatus] = String.Format("{0} - {1}", oppStatusList.Return_Code, oppStatusList.Return_Message);

            Guid integrationStatusId = service.Create(integrationStatus);
        }

        /// <summary>
        /// This function is used to retrieve the optionset value using the optionset text label
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedLabel"></param>
        /// <returns></returns>
        private static int GetOptionsSetValueForLabel(OrganizationService service, string entityName, string attributeName, string selectedLabel)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            int selectedOptionValue = 0;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                {
                    selectedOptionValue = oMD.Value.Value;
                    break;
                }
            }
            return selectedOptionValue;
        }
        /// <summary>
        /// This function is used to retrieve entity record collection
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="columnAttributeName"></param>
        /// <param name="columnAttributeValue"></param>
        /// <param name="columnSet"></param>
        /// <returns></returns>
        private static EntityCollection GetEntityRecords(ref OrganizationService service, string entityName, string[] columnAttributeName, object[] columnAttributeValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.ColumnSet = columnSet;
            indexAttribute.Attributes.AddRange(columnAttributeName);
            indexAttribute.Values.AddRange(columnAttributeValue);
            indexAttribute.AddOrder("createdon", OrderType.Descending);
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }
        /// <summary>
        /// This method is used for fetching data from sql base table
        /// </summary>
        /// <param name="query"></param>
        private void GetTableRecords(string query)
        {
            try
            {
                con = new dbConnection();
                dt = con.executeSelectQuery(query);
            }

            catch (Exception ex)
            {
                log.Info(ex);
            }

        }

        private static bool GetAccounts(ref OrganizationService service, string AccountNumber, string CustomerName, Guid UtilityId)
        {
            bool IsExist = false;
            if (UtilityId != Guid.Empty)
            {
                Entity vzEntity = null;

                ColumnSet Indexcol = new ColumnSet(true);
                QueryByAttribute indexattribute = new QueryByAttribute();
                indexattribute.EntityName = "spg_account";
                indexattribute.Attributes.AddRange(new string[] { "spg_name", "spg_customername", "spg_utility" });
                indexattribute.Values.AddRange(new object[] { AccountNumber, CustomerName, UtilityId });
                indexattribute.ColumnSet = Indexcol;
                RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
                req_index.Query = indexattribute;
                RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
                EntityCollection index = resp_index.EntityCollection;
                if (index != null && index.Entities.Count > 0)
                    vzEntity = index.Entities[0];
                if (vzEntity != null && vzEntity.Attributes.Contains("spg_accountid"))
                {
                    IsExist = true;
                }
            }
            return IsExist;
        }

        private static void GetOppProducts(ref OrganizationService service, Guid ProductId, Guid OpportunityId, out Guid OppProductId, out bool Flag)
        {
            Flag = false;
            OppProductId = Guid.Empty;
            if (ProductId != Guid.Empty && OpportunityId != Guid.Empty)
            {
                Entity vzEntity = null;

                ColumnSet Indexcol = new ColumnSet(true);
                QueryByAttribute indexattribute = new QueryByAttribute();
                indexattribute.EntityName = "spg_opportunityproduct";
                indexattribute.Attributes.AddRange(new string[] { "spg_product", "spg_opportunity" });
                indexattribute.Values.AddRange(new object[] { ProductId, OpportunityId });
                indexattribute.ColumnSet = Indexcol;
                RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
                req_index.Query = indexattribute;
                RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
                EntityCollection index = resp_index.EntityCollection;
                if (index != null && index.Entities.Count > 0)
                    vzEntity = index.Entities[0];

                if (vzEntity != null && vzEntity.Attributes.Contains("spg_opportunityproductid"))
                {
                    Flag = true;
                    OppProductId = vzEntity.Id;
                }
            }
        }

        private Guid CreateAccountsRecord(string AccountNumber, string CustomerName, string OpportunityId, string MarketerName, Entity AccountsEntity, Entity MatrixEntity, Entity UtitlityEntity, ref OrganizationService service)
        {
            AccountsEntity.Attributes["spg_ldcaccountnumber"] = AccountNumber;
            AccountsEntity.Attributes["spg_customername"] = CustomerName;
            log.Info("Set utility to accounts out if");
            if (UtitlityEntity != null)
            {
                log.Info("Set utility to accounts into if");
                log.Info(string.Format("Utility Logical Name{0} and Utility ID{1}", UtitlityEntity.LogicalName, UtitlityEntity.Id));
                AccountsEntity.Attributes["spg_utility"] = new EntityReference(UtitlityEntity.LogicalName, UtitlityEntity.Id);
            }
            switch (MarketerName)
            {
                case "Source Power & Gas LLC":
                    {
                        AccountsEntity.Attributes[_marketregion] = new EntityReference(_marketer, new Guid("17003DA9-F476-E511-80C5-000D3A90E5FA"));
                        break;
                    }
                case "Source Power & Gas LLC NT":
                    {
                        AccountsEntity.Attributes[_marketregion] = new EntityReference(_marketer, new Guid("C03B13B0-F476-E511-80C5-000D3A90E5FA"));
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
            Guid Accid = service.Create(AccountsEntity);
            MatrixEntity.Attributes[_accountlookup] = new EntityReference(_accounts, Accid);
            MatrixEntity.Attributes[_ldcaccountno] = AccountNumber;
            log.Info(String.Format("Account added with name{0} and LDC account number{0}", AccountNumber));
            integrationLogCreate.Append(",Account");
            if (Accid != Guid.Empty)
            {
                EntityReference accountsReference = new EntityReference(_accounts, Accid);
                EntityReference OpportunityReference = new EntityReference(_opportunity, new Guid(OpportunityId));
                AccountsAssociationWithOpportunity(OpportunityReference, accountsReference, ref service);
            }
            return Accid;
        }

        private void AccountsAssociationWithOpportunity(EntityReference OpportunityReference, EntityReference AccountReference, ref OrganizationService service)
        {
            AssociateManyToManyEntityRecords(OpportunityReference, AccountReference, "spg_opportunity_spg_account", _accounts, ref service);
        }

        private void ContractsAssociationWithOpportunity(Entity ContractEntity, Guid OpportunityId, Guid ContractId, Relationship Relationship, ref OrganizationService service)
        {
            AssociateOneToManyEntityRecords(ContractEntity, OpportunityId, ContractId, Relationship, 1, ref service);
        }

        private void OpportunityProductAssociationWithOpportunity(Entity OpportunityProductEntity, Guid OpportunityId, Guid OppProductId, Relationship Relationship, ref OrganizationService service)
        {
            AssociateOneToManyEntityRecords(OpportunityProductEntity, OpportunityId, OppProductId, Relationship, 2, ref service);
        }

        private void ContractsAssociationWithAccount(EntityReference AccountReference, EntityReference ContractReference, ref OrganizationService service)
        {
            AssociateManyToManyEntityRecords(AccountReference, ContractReference, "spg_spg_contract_spg_account", _contracts, ref service);
        }

        private void AssociateManyToManyEntityRecords(EntityReference moniker1, EntityReference moniker2, string strEntityRelationshipName, string EntityCheck, ref OrganizationService service)

        {
            bool Flag = false;
            if (EntityCheck == _contracts && EntityCheck != string.Empty)
            {
                Flag = CheckIsAccountAssociatedToContracts(ref service, moniker1.Id, moniker2.Id);
            }
            else
            {
                Flag = CheckIsAccountAssociated(ref service, moniker1.Id, moniker2.Id);
            }


            if (Flag == false)
            {
                AssociateEntitiesRequest request = new AssociateEntitiesRequest();
                request.Moniker1 = new EntityReference { Id = moniker1.Id, LogicalName = moniker1.LogicalName };
                request.Moniker2 = new EntityReference { Id = moniker2.Id, LogicalName = moniker2.LogicalName };
                request.RelationshipName = strEntityRelationshipName;
                service.Execute(request);
            }

        }

        private void AssociateOneToManyEntityRecords(Entity moniker1, Guid moniker1Id, Guid moniker2Id, Relationship Relationship, int FlagType, ref OrganizationService service)

        {
            bool Flag = false;

            if (FlagType == 1)
            {
                Flag = CheckIsContractAssociated(ref service, moniker2Id);
            }
            else if (FlagType == 2)
            {
                Flag = CheckIsOpportunityProductAssociated(ref service, moniker2Id);
            }
            if (Flag == false)
            {
                EntityReferenceCollection relatedentity = new EntityReferenceCollection();
                relatedentity.Add(new EntityReference(moniker1.LogicalName, moniker2Id));
                service.Associate(_opportunity, moniker1Id, Relationship, relatedentity);
            }

        }

        private static bool CheckIsAccountAssociated(ref OrganizationService service, Guid opportunityId, Guid accountId)
        {
            Entity vzEntity = null;
            bool IsExist = false;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_opportunity_spg_account";
            indexattribute.Attributes.AddRange(new string[] { "opportunityid", "spg_accountid" });
            indexattribute.Values.AddRange(new object[] { opportunityId, accountId });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
                vzEntity = index.Entities[0];
            if (vzEntity != null && vzEntity.Attributes.Contains("spg_accountid"))
            {
                IsExist = true;
            }
            return IsExist;
        }

        private static bool CheckIsAccountAssociatedToContracts(ref OrganizationService service, Guid accountId, Guid contractId)
        {
            Entity vzEntity = null;
            bool IsExist = false;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_spg_contract_spg_account";
            indexattribute.Attributes.AddRange(new string[] { "spg_accountid", "spg_contractid" });
            indexattribute.Values.AddRange(new object[] { accountId, contractId });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
                vzEntity = index.Entities[0];
            if (vzEntity != null && vzEntity.Attributes.Contains("spg_accountid"))
            {
                IsExist = true;
            }
            return IsExist;
        }

        private static bool CheckIsContractAssociated(ref OrganizationService service, Guid opportunityId)
        {
            #region Retrieve records from an intersect table via Fetch
            bool IsExist = false;
            // Setup Fetch XML.
            StringBuilder linkFetch = new StringBuilder();
            linkFetch.Append("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"true\">");
            linkFetch.Append("<entity name=\"opportunity\">");
            linkFetch.Append("<attribute name=\"name\"/>");
            //linkFetch.Append("<attribute name=\"spg_contractid\"/>");
            linkFetch.Append("<link-entity name=\"spg_contract\" from=\"spg_contractsid\" to=\"opportunityid\" visible=\"true\" intersect=\"true\">");
            linkFetch.Append("<filter type=\"and\">");
            linkFetch.Append("<condition attribute=\"spg_contractid\" operator=\"eq\" value=\"");
            linkFetch.Append("{");
            linkFetch.Append(opportunityId);
            linkFetch.Append("}\" />");
            linkFetch.Append("</filter>");
            linkFetch.Append("</link-entity>");
            linkFetch.Append("</entity>");
            linkFetch.Append("</fetch>");

            // Build fetch request and obtain results.
            RetrieveMultipleRequest efr = new RetrieveMultipleRequest()
            {
                Query = new FetchExpression(linkFetch.ToString())
            };
            EntityCollection index = ((RetrieveMultipleResponse)service.Execute(efr)).EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                IsExist = true;
            }
            return IsExist;
            #endregion 
        }

        private static bool CheckIsOpportunityProductAssociated(ref OrganizationService service, Guid opportunityId)
        {
            #region Retrieve records from an intersect table via Fetch
            bool IsExist = false;
            // Setup Fetch XML.
            StringBuilder linkFetch = new StringBuilder();
            linkFetch.Append("<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"true\">");
            linkFetch.Append("<entity name=\"opportunity\">");
            linkFetch.Append("<attribute name=\"name\"/>");
            linkFetch.Append("<attribute name=\"spg_opportunityid\"/>");
            linkFetch.Append("<link-entity name=\"spg_opportunityproduct\" from=\"spg_opportunity\" to=\"opportunityid\" visible=\"false\" intersect=\"true\">");
            linkFetch.Append("<filter type=\"and\">");
            linkFetch.Append("<condition attribute=\"spg_opportunityproductid\" operator=\"eq\" value=\"");
            linkFetch.Append("{");
            linkFetch.Append(opportunityId);
            linkFetch.Append("}\" />");
            linkFetch.Append("</filter>");
            linkFetch.Append("</link-entity>");
            linkFetch.Append("</entity>");
            linkFetch.Append("</fetch>");

            // Build fetch request and obtain results.
            RetrieveMultipleRequest efr = new RetrieveMultipleRequest()
            {
                Query = new FetchExpression(linkFetch.ToString())
            };
            EntityCollection index = ((RetrieveMultipleResponse)service.Execute(efr)).EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                IsExist = true;
            }
            return IsExist;
            #endregion 
        }

        //This method removes special characters from an input string
        private string removeSpecialCharacters(string Input)
        {
            string[] chars = new string[] { "~", "@", "#", "$", "^", "*", "(", ")" };
            for (int i = 0; i < chars.Length; i++)
            {
                if (Input.Contains(chars[i]))
                {
                    Input = Input.Replace(chars[i], "");
                }
            }
            return Input;
        }

        private Entity GetUtilityEntity(ref OrganizationService service, string TerritoryCode)
        {
            Entity entity = new Entity();

            ColumnSet Indexcol = new ColumnSet(new string[] { "spg_utilityid" });
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_utility";
            indexattribute.Attributes.AddRange(new string[] { "spg_territorycode" });
            indexattribute.Values.AddRange(TerritoryCode);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            log.Info(resp_index.ToString());
            EntityCollection index = resp_index.EntityCollection;
            log.Info("Utility Count" + index.Entities.Count);
            if (index != null && index.Entities.Count > 0)
            {
                log.Info("Check Utility Collection");
                entity = (Entity)index.Entities[0];

            }

            return entity;
        }

        private Entity GetCustomerEntity(ref OrganizationService service, string Name)
        {
            Entity entity = null;

            ColumnSet Indexcol = new ColumnSet(new string[] { "accountid" });
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "account";
            indexattribute.Attributes.AddRange(new string[] { "name" });
            indexattribute.Values.AddRange(Name);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                entity = (Entity)index.Entities[0];

            }
            return entity;
        }

        private static Entity GetAccountRecords(ref OrganizationService service, string AccountNumber)
        {
            Entity vzEntity = null;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_account";
            indexattribute.Attributes.AddRange(new string[] { "spg_name" });
            indexattribute.Values.AddRange(new object[] { AccountNumber });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                vzEntity = index.Entities[0];
            }

            return vzEntity;
        }

        private static Entity GetOpportunityForContract(ref OrganizationService service, string EntityName, string OpportunityName)
        {
            Entity vzEntity = null;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = EntityName;
            indexattribute.Attributes.AddRange(new string[] { "spg_opportunityname" });
            indexattribute.Values.AddRange(new object[] { OpportunityName });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                vzEntity = index.Entities[0];
            }

            return vzEntity;
        }


        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        //Entity Name
        private string _matrixenrollment = "spg_matrixenrollment";

        //Fields Name
        private string _firstname = "spg_firstname";
        private string _lastname = "spg_lastname";
        private string _primaryphone = "spg_primaryphonenumber";
        private string _businessname = "spg_businessname";
        private string _ldcaccountno = "spg_ldcaccountnumber";
        private string _servicestreetaddress = "spg_servicestreetaddress";
        private string _servicestreetaddress2 = "spg_servicestreetaddress2";
        private string _servicecity = "spg_servicecity";
        private string _servicestate = "spg_servicestate";
        private string _servicezipcode = "spg_servicezipcode";
        private string _mailingaddress = "spg_mailingstreetaddress";
        private string _mailingaddress2 = "spg_mailingstreetaddress2";
        private string _mailingcity = "spg_mailingcity";
        private string _mailingstate = "spg_mailingstate";
        private string _matrixcontract = "spg_contract";
        private string _mailingzipcode = "spg_mailingzipcode";
        private string _utilitycode = "spg_utilitycode";
        private string _utility = "spg_utility";
        private string _enrolltypedesc = "spg_enrolltypedesc";
        private string _requestedstartdate = "spg_requestedstartdate";
        private string _contractterms = "spg_contractterms_months";
        private string _contractrate = "spg_contractrate";
        private string _meterfee = "spg_meterfee";
        private string _accountlookup = "spg_account";
        private string _contractllokup = "spg_contract";
        private string _basisincl = "spg_basisincl";
        private string _contracttype = "spg_contracttype";
        private string _revenueclassdesc = "spg_revenueclassdesc";
        private string _brokerfee = "spg_brokerfee";
        private string _commissiontype = "spg_commissiontype";
        private string _businesstype = "spg_businesstype";
        private string _monthlyusage = "spg_monthlyusage";
        private string _annualusage = "spg_annualmwh";
        private string _rateclass = "spg_rateclass";
        private string _loadfactor = "spg_loadfactor";
        private string _processtype = "spg_processtype";
        private string _historicalusageind = "spg_historicalusageind";
        private string _commodity = "spg_commodity";
        private string _county = "spg_county";
        private string _statusdesc = "spg_statusdesc";
        private string _combinenameind = "spg_statusdesc";
        private string _marketernamelookup = "spg_marketername";
        private string _oppname = "spg_opportunityname";
        private string _opplookup = "spg_opportunitylookup";
        private string _brokercategory = "spg_brokercategory";
        private string _brokertype = "spg_brokertype";
        private string _master = "spg_master";
        private string _isfortexas = "spg_isfortexas";
        private string _matrixdate = "spg_matrixdate";
        private string _dateadded = "spg_dateadded";
        private string _modifiedon = "modifiedon";
        private string _status = "spg_status";
        private string _commissionterms = "spg_commissionterms";
        private string _specialtypebusiness = "spg_specialtypebusiness";
        private string _hundredpergreen = "spg_hundredpergreen";
        private string _neworrenew = "spg_neworrenew";
        private string _calcbrokerfee = "spg_calculatedbrokerfee";
        private string _calccontract = "spg_calculatedcontract";
        private string _name = "spg_name";
        private string _contractstatus = "spg_contractstatus";
        private string _agent = "spg_agent"; //Agent lookup on matrix enrollments entity
        private string _subagent = "spg_subagent"; //Subagent lookup on matrix enrollments entity
        private string _contactlookup = "spg_contact"; //Contact lookup on matrix enrollments entity
        private string _emailaddress = "spg_emailaddress";
        private string _isMultiUtilities = "spg_ismultiutilities";
        //private string ;
        //private string ;
        //private string ;
        //private string ;
        //private string ;
        //private string ;
        //private string ;
        //private string ;
        //private string ;
        //private string ;
        //private string ;



        //Reference Entities
        private string _customer = "account";
        private string _marketer = "spg_marketer";
        private string _opportunity = "opportunity";
        private string _accounts = "spg_account";
        private string _contracts = "spg_contract";
        private string _marketregion = "spg_marketregion";
        private string _brokerpaymethod = "spg_brokerpaymethod";
        private string _entIntegrationStatus = "spg_integrationstatusmatrixenrollments";
        private string _contact = "contact";
        private string _broker = "spg_broker";
        private string _opportunityproduct = "spg_opportunityproduct";
        private string _productentity = "spg_product";
        private string _userentity = "systemuser";

        //Reference Entity Fields
        private string _customername = "name";
        private string _accountguid = "accountid"; //It is customer id field of customerentity
        private string _accountsid = "spg_accountid";
        private string _attrLastSuccessfulRunOn = "spg_lastsuccessfulrunon";
        private string _marketername = "spg_name";
        private string _accname = "spg_name";
        private string _marketerid = "spg_marketerid";
        private string _brokerpayguid = "spg_brokerpaymethodid";
        private string _brokerpayname = "spg_name";
        private string _marketregionopp = "spg_marketregion";
        private string _fullname = "fullname"; //It is used in contact entity as name field
        private string _lastnamecontact = "lastname"; //It is used in contact entity as last name field
        private string _firstnamecontact = "firstname"; //It is used in contact entity as first name field
        private string _contactguid = "contactid"; //It is used in contact entity as contactid field
        private string _primarycontact = "primarycontactid"; //It exist in customer and set from contact
        private string _brokercode = "spg_brokercode"; //It exist and used in broker entity;
        private string _brokeragentcode = "spg_brokeragentcode"; //It exist on contact entity and used for broker agent
        private string _product = "spg_product"; //It exist on opportunityproduct entity and used for product
        private string _basiscongestion = "spg_basiscongestion"; //It exist on opportunityproduct entity and
        private string _systemuserid = "systemuserid"; //It exist on user entity and contain guid
        private string _systemusername = "domainname"; //It exist on user entity and contain domain and username

        //Log Entities
        private string _matrixlog = "spg_matrixenrollmentlog";

        //Log Entity Fields
        private string _enrollmentcode = "spg_name"; //It exist on matrix enrollment log entity and used for log
        private string _matchedRecords = "spg_matchedrecords"; //It exist on matrix enrollment log entity and used for logging matched records
        private string _unmatchedrecords = "spg_unmatchedrecords"; //It exist on matrix enrollment log entity and used for logging unmatched records
        private string _createdrecords = "spg_createdrecords"; //It exist on matrix enrollment log entity and used for logging matched records
        private string _integrationstatus = "spg_integrationstatus"; //It exist on matrix enrollment log entity and used for logging matrix record status
        private string _opportunitylookup = "spg_opportunity"; // It exist on matrix enrollment log entity and used for logging related opportunity
        private string _matrixenrollmentlookup = "spg_matrixenrollment"; // It exist on matrix enrollment log entity and used for logging related matrix record 

        private string _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
        private string _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");
        private string _serverUrl = ConfigurationManager.AppSettings.Get("ServerUrl");
        private string _connectionstring = string.Empty;

        //These variables are declare for optionsetvalues
        private OptionSetValue enrolltypedescvalue = new OptionSetValue();
        private OptionSetValue businesstypeValue = new OptionSetValue();
        private OptionSetValue loadfactorvalue = new OptionSetValue();
        private OptionSetValue historicalusage = new OptionSetValue();
        private OptionSetValue commodityvalue = new OptionSetValue();
        private OptionSetValue statusvalue = new OptionSetValue();
        private OptionSetValue neworrenewvalue = new OptionSetValue();
        private OptionSetValue brokertypevalue = new OptionSetValue();
        private OptionSetValue commissiontypevalue = new OptionSetValue();

        // These guid variables are used for product of opportunity product
        Guid _lessthan50 = new Guid("3B701CD8-AE86-E511-80C7-000D3A90E5FA"); //It is used for ercot less than 50 KWh condition
        Guid _greaterthan50 = new Guid("37701CD8-AE86-E511-80C7-000D3A90E5FA"); //It is used for ercot greater than 50KWh and all pjm condition

        //Query for fetching data
        private static string _query = @"SELECT [ID],[BusinessName],[FirstName],[LastName],[PrimaryPhoneNumber],[EmailAddress],[LDCAccountNumber],[ServiceStreetAddress]
                                       ,[ServiceStreetAddress2],[ServiceCity],[ServiceState],[ServiceZipCode],[MailingStreetAddress],[MailingStreetAddress2],[MailingCity]
                                       ,[MailingState],[MailingZipCode],[Utility],[UtilityCode],[EnrollTypeDesc],[RequestedStartDate],[ContractTerms_Months],[ContractRate]
                                       ,[MeterFee],[BasisIncl],[ContractType],[RevenueClassDesc],[BillingMethod],[Master],[Agent],[Subagent],[BrokerFee],[ComissionType],[Market_Region]
                                       ,[ComissionTerms],[BusinessType],[MonthlyUsage],[AnnualUsage],[RateClass],[LoadFactor],[ProcessType],[HistoricalUsageInd],[Commodity]
                                       ,[County],[StatusDesc],[CombineNameInd],[MarketerName],[OpportunityName],[BrokerCategory],[BrokerType],[IsForTexas],[MatrixDate]
                                       ,[DateAdded],[CreatedByUser],[UpdatedByUser],[UpdateTimeStamp],[Status],[SpecialTypeBusiness],[HundredPerGreen],[NewRenew],[CalculatedBrokerFee]
                                       ,[CalculatedContract],[Date],[EnrollmentID],[ApprovedBy],[IsProcessed],[Account_Status],[IsMultiUtilities] FROM [mu_EnrollmentsView]";

        //Datatable for for stroing data and performing operations
        private static DataTable dt;

        //For Integration log
        StringBuilder integrationLogCreate = new StringBuilder();
        StringBuilder integrationLogFind = new StringBuilder();
        StringBuilder integrationLogNotMatched = new StringBuilder();

        //Crm Service Components
        private CrmConnection _connection;
        private OrganizationService service;

        // Provide your user name and password.
        private string _userName = string.Empty;
        private string _password = string.Empty;

        // Provide domain name for the On-Premises org.
        private string _domain = string.Empty;
    }
}
