﻿using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Xml;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Client;
using System.ServiceModel.Description;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Client.Services;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace SPGOppStatusUpdateConsoleApp
{
    class Program
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region Attributes
        private const string _entOpportunity = "opportunity";
        private const string _entIntegrationStatus = "spg_integrationstatus";
        private const string _entIntegrationCredential = "spg_integrationcredential";

        private const string _attrESGPortalOpportunityId = "spg_esgportalopportunityid";
        private const string _attrDefaultStatus = "statecode";
        private const string _attrStatus = "spg_status";
        private const string _attrSubStatus = "spg_substatus";
        private const string _attrStatusUpdateDate = "spg_statusupdatedate";
        private const string _attrLastSuccessfulRunOn = "spg_lastsuccessfulrunon";
        private const string _attrLastStatus = "spg_laststatus";

        private const string _attrIntAPIUrl = "spg_apiurl";
        private const string _attrIntAPIHost = "spg_apihost";
        private const string _attrIntAPIAccount = "spg_apiaccount";
        private const string _attrIntAPIPassword = "spg_apipassword";

        private string _discoveryServiceAddress = ConfigurationManager.AppSettings.Get("DiscoveryServiceAddress");
        private string _organizationUniqueName = ConfigurationManager.AppSettings.Get("OrganizationUniqueName");
        private string _serverUrl = ConfigurationManager.AppSettings.Get("ServerUrl");
        private string _connectionString = string.Empty;

        private string _hoursToSubtract = ConfigurationManager.AppSettings.Get("HoursToSubtract");
        private string _timeStamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

        private DateTime lastSuccessfulRunOn = new DateTime();
        private CrmConnection _connection;
        private OrganizationService _orgService;


        #endregion

        static void Main(string[] args)
        {
            try
            {
                log.Info("App started.");
                Program app = new Program();
                app.Run();
                log.Info(String.Format("App completed.{0}",Environment.NewLine));
            }
            catch (Exception ex)
            {
                log.Error("Error occured.", ex);
            }
        }

        private void Run()
        {
            Boolean result;

            _connectionString = String.Format("Url={0}/{1}", _serverUrl, _organizationUniqueName);

            _connection = CrmConnection.Parse(_connectionString);
            _orgService = new OrganizationService(_connection);

            OpportunityStatusList oppStatusList = new OpportunityStatusList();

            lastSuccessfulRunOn = GetLastSuccessfulRunDate();

            #region New code to fetch integration credentials from service

            EntityCollection integrationCredentials = GetIntCredentials();

            if (integrationCredentials != null)
            {
                if (integrationCredentials.Entities.Count > 0)
                {
                    Entity integrationCredential = (Entity)integrationCredentials.Entities[0];

                    if (integrationCredential.Attributes.Contains(_attrIntAPIUrl))
                        oppStatusList.Url = integrationCredential.Attributes[_attrIntAPIUrl].ToString();

                    if (integrationCredential.Attributes.Contains(_attrIntAPIAccount))
                        oppStatusList.UserId = integrationCredential.Attributes[_attrIntAPIAccount].ToString();

                    if (integrationCredential.Attributes.Contains(_attrIntAPIPassword))
                        oppStatusList.Password = integrationCredential.Attributes[_attrIntAPIPassword].ToString();
                }
                else
                {
                    throw new Exception("Integration credentials not found for ESP Portal.");
                }
            }
            else
            {
                throw new Exception("Could not retrieve Integration Credentials.");
            }

            #endregion

            oppStatusList.Row_limit = Convert.ToInt32(ConfigurationManager.AppSettings.Get("RowLimit"));
            oppStatusList.Update_start_date = lastSuccessfulRunOn.ToLocalTime().AddHours(-1*Convert.ToInt32(_hoursToSubtract));

            result = oppStatusList.GetOpportunityStatus();

            

            DataSet ds = new DataSet();

            log.Info(String.Format("{0}{1}{2}{3}","XML Request",Environment.NewLine,string.Concat(oppStatusList.Service_parameters, oppStatusList.Service_data),Environment.NewLine));

            if (result)
            {
                log.Info(String.Format("{0}{1}{2}{3}", "XML Response",Environment.NewLine, oppStatusList.XmlResponse.InnerXml, Environment.NewLine));
                XmlNodeReader reader = new XmlNodeReader(oppStatusList.XmlResponse);
                ds.ReadXml(reader);

                if (oppStatusList.Return_Code == "100" || oppStatusList.Return_Code == "0")
                {
                    
                    UpdateOpportunityStatus(ds);
                }
            }
            else
            {
                log.Info("0 Opportunity Returns");
            }

            CreateIntegrationStatusRecord(oppStatusList);
        }

        private DateTime GetLastSuccessfulRunDate()
        {
            const string _FetchExpression =  "<fetch distinct='false' mapping='logical' aggregate='true'>" +
                "<entity name='spg_integrationstatus'>" +
                "<attribute name='spg_lastsuccessfulrunon' aggregate='max' alias='spg_lastsuccessfulrunon'/>" +
                "</entity>" +
                "</fetch>";
            const string _SPGLastSuccessfulRunOn = "spg_lastsuccessfulrunon";
            RetrieveMultipleRequest req = new RetrieveMultipleRequest();
            FetchExpression fetch = new FetchExpression(_FetchExpression);
            req.Query = fetch;
            RetrieveMultipleResponse resp = (RetrieveMultipleResponse)_orgService.Execute(req);

            EntityCollection integrationStatus = resp.EntityCollection;

            if (integrationStatus.Entities.Count > 0)
            {
                Entity intStatus = integrationStatus.Entities[0];

                if (intStatus.Attributes.Contains(_SPGLastSuccessfulRunOn))
                {
                    AliasedValue lastSuccessfulRun = new AliasedValue();
                    lastSuccessfulRun = (AliasedValue)intStatus.Attributes[_SPGLastSuccessfulRunOn];
                    return Convert.ToDateTime(lastSuccessfulRun.Value);
                }
                else
                {
                    throw new Exception("Record not found in Integration Status entity.");
                    
                }
            }
            else
            {
                throw new Exception("Record not found in Integration Status entity.");
                
            }
        }

        private void CreateIntegrationStatusRecord(OpportunityStatusList oppStatusList)
        {
            Entity integrationStatus = new Entity(_entIntegrationStatus);

            integrationStatus[_attrLastSuccessfulRunOn] = DateTime.Now;
            integrationStatus[_attrLastStatus] = String.Format("Last successful run UTC Time {0} - Local Time {1} - {2} - {3}", lastSuccessfulRunOn, lastSuccessfulRunOn.ToLocalTime(), oppStatusList.Return_Code, oppStatusList.Return_Message);

            Guid integrationStatusId = _orgService.Create(integrationStatus);
        }

        private void UpdateOpportunityStatus(DataSet oppDataSet)
        {
            const string _OpportunityTableName = "Opportunity";
            const string _OpportunityId = "Opportunity_Id";
            const string _StatusSubStatusDesc = "Status_Substatus_Desc";
            #region Loop through opportunities dataset to update status in CRM

            for (int i = 0; i < oppDataSet.Tables[_OpportunityTableName].Rows.Count; i++)
            {
                DataRow row = oppDataSet.Tables[_OpportunityTableName].Rows[i];

                string opportunityId = string.Empty;
                string opportunityCompleteStatus = string.Empty;
                string opportunityStatus = string.Empty;
                string opportunitySubStatus = string.Empty;
                bool opportunityStatusUpdateRequired = false;

                opportunityId = oppDataSet.Tables[_OpportunityTableName].Rows[i][_OpportunityId].ToString();
                opportunityCompleteStatus = oppDataSet.Tables[_OpportunityTableName].Rows[i][_StatusSubStatusDesc].ToString();

                int subStatusChar = opportunityCompleteStatus.IndexOf(@"/");

                if (i == 0)
                {
                    log.Info(String.Format("Last successful run was on {0}", lastSuccessfulRunOn.ToLocalTime()));
                   
                }

                if (subStatusChar == -1)
                {
                    opportunityStatus = opportunityCompleteStatus;
                }
                else
                {
                    opportunityStatus = opportunityCompleteStatus.Substring(0, subStatusChar);
                    opportunitySubStatus = opportunityCompleteStatus;
                }

                if (opportunityCompleteStatus != string.Empty)
                {
                    
                    ColumnSet statusColumns = new ColumnSet(_attrESGPortalOpportunityId, _attrStatus, _attrSubStatus, _attrStatusUpdateDate, _attrDefaultStatus);

                    EntityCollection opportunities = GetEntityRecords(_entOpportunity, _attrESGPortalOpportunityId, opportunityId, statusColumns);

                    if (opportunities.Entities.Count > 0)
                    {
                        Entity opportunity = opportunities.Entities[0];

                        OptionSetValue existingOppStatusValue = new OptionSetValue();
                        OptionSetValue existingDefaultOppStatusValue = new OptionSetValue();
                        OptionSetValue existingOppSubStatusValue = new OptionSetValue();

                        OptionSetValue opportunityStatusValue = new OptionSetValue();
                        OptionSetValue opportunitySubStatusValue = new OptionSetValue();

                        string existingOppStatusText = string.Empty;
                        string existingOppSubStatusText = string.Empty;

                        if (opportunity.Attributes.Contains(_attrStatus))
                        {
                            existingOppStatusValue = opportunity.Attributes[_attrStatus] as OptionSetValue;
                            existingDefaultOppStatusValue = opportunity.Attributes[_attrDefaultStatus] as OptionSetValue;
                            existingOppStatusText = GetOptionsSetTextForValue(_entOpportunity, _attrStatus, existingOppStatusValue.Value);
                            if (existingDefaultOppStatusValue.Value == 0)
                            {
                                if (existingOppStatusText != "Lost" &&
                                    existingOppStatusText != "Not Viable" &&
                                    existingOppStatusText != "Cancel")
                                {
                                    opportunityStatusUpdateRequired = true;
                                }
                            }

                            opportunityStatusValue.Value = GetOptionsSetValueForLabel(_entOpportunity, _attrStatus, opportunityStatus);
                            opportunity.Attributes[_attrStatus] = opportunityStatusValue;
                        }

                        if (opportunity.Attributes.Contains(_attrSubStatus) && subStatusChar != -1)
                        {
                            existingOppSubStatusValue = opportunity.Attributes[_attrSubStatus] as OptionSetValue;
                            existingOppSubStatusText = GetOptionsSetTextForValue(_entOpportunity, _attrSubStatus, existingOppSubStatusValue.Value);

                            opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(_entOpportunity, _attrSubStatus, opportunitySubStatus);
                            opportunity.Attributes[_attrSubStatus] = opportunitySubStatusValue;
                        }

                        if (opportunity.Attributes.Contains(_attrStatusUpdateDate))
                        {
                            opportunity.Attributes[_attrStatusUpdateDate] = DateTime.Now;
                        }
                        else
                        {
                            opportunity.Attributes.Add(_attrStatusUpdateDate, DateTime.Now);
                        }

                        if (opportunityStatusUpdateRequired)
                        {
                            if (existingOppStatusValue.Value != opportunityStatusValue.Value || existingOppSubStatusValue.Value != opportunitySubStatusValue.Value)
                            {
                                try
                                {
                                    if(opportunity.Attributes.Contains(_attrESGPortalOpportunityId))
                                    {
                                        opportunity.Attributes.Remove(_attrESGPortalOpportunityId); 
                                    _orgService.Update(opportunity);
                                    log.Info(String.Format("Status of opportunity id {0} updated with {1}", opportunityId, opportunityCompleteStatus));
                                    }
                                }
                                catch (Exception ex)
                                {
                                    log.Info(String.Format("Could not update status of opportunity id {0} with {1}", opportunityId, opportunityCompleteStatus), ex);
                                }
                            }
                            else
                            {
                                log.Info(String.Format("Opportunity id {0} does not require update. Already have {1} status.", opportunityId, opportunityCompleteStatus));
                            }
                        }
                        else
                        {
                            log.Info(String.Format("Opportunity id {0} has {0} status hence ignoring update.", opportunityId, existingOppStatusText));
                        }

                    }
                    else
                    {
                        log.Info(String.Format("Could not find opportunity id {0} in Microsoft Dynamics CRM", opportunityId, opportunityCompleteStatus));
                    }
                }
            }
            #endregion
        }

        private void UpdateOpportunityStatus(string opportunityId, string opportunityStatus, string opportunitySubStatus)
        {
            ColumnSet statusColumns = new ColumnSet(_attrESGPortalOpportunityId, _attrStatus, _attrSubStatus, _attrStatusUpdateDate);

            EntityCollection opportunities = GetEntityRecords(_entOpportunity, _attrESGPortalOpportunityId, opportunityId, statusColumns);

            if (opportunities.TotalRecordCount > 0)
            {
                Entity opportunity = opportunities.Entities[0];

                if (opportunity.Attributes.Contains(_attrStatus))
                {
                    OptionSetValue opportunityStatusValue = new OptionSetValue();
                    opportunityStatusValue.Value = GetOptionsSetValueForLabel(_entOpportunity, _attrStatus, opportunityStatus);
                    opportunity.Attributes[_attrStatus] = opportunityStatusValue;
                }

                if (opportunity.Attributes.Contains(_attrSubStatus))
                {
                    OptionSetValue opportunitySubStatusValue = new OptionSetValue();
                    opportunitySubStatusValue.Value = GetOptionsSetValueForLabel(_entOpportunity, _attrSubStatus, opportunitySubStatus);
                    opportunity.Attributes[_attrSubStatus] = opportunitySubStatusValue;
                }

                if (opportunity.Attributes.Contains(_attrStatusUpdateDate))
                {
                    opportunity.Attributes[_attrStatusUpdateDate] = DateTime.Now;
                }
                else
                {
                    opportunity.Attributes.Add(_attrStatusUpdateDate, DateTime.Now);
                }
                if (opportunity.Attributes.Contains(_attrESGPortalOpportunityId))
                    opportunity.Attributes.Remove(_attrESGPortalOpportunityId);
                    _orgService.Update(opportunity);

                
            }
            else
            {
               
            }
        }

        public static XmlDocument HttpSOAPRequest(string url, string serviceParameters, string serviceData)
        {
            // trust all certs
            ServicePointManager.ServerCertificateValidationCallback = ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });

            System.Net.ServicePointManager.Expect100Continue = false;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);

            req.KeepAlive = false;
            req.ConnectionGroupName = Guid.NewGuid().ToString();
            req.Headers.Add("SOAPAction", "\"\"");
            req.ContentType = "text/xml;charset=utf-8";
            req.Accept = "text/xml";
            req.Method = "POST";
            Stream stm = req.GetRequestStream();

           const string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
            const string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
            string input = string.Concat(soapHdr, serviceParameters, serviceData, soapTrl);
            
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(soapHdr + serviceParameters + serviceData + soapTrl);
            stm.Write(bytes, 0, bytes.Length);
            stm.Close();

            HttpWebResponse resp;

            try
            {
                resp = (HttpWebResponse)req.GetResponse();

                Stream objResponseStream = resp.GetResponseStream();
                XmlTextReader objXMLReader = new XmlTextReader(objResponseStream);
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(objXMLReader);
                XmlDocument XMLResponse = xmldoc;
                objXMLReader.Close();
                return XMLResponse;
            }
            catch (WebException exc)
            {
                if (exc.Status == WebExceptionStatus.ProtocolError)
                {
                    StreamReader reader = new StreamReader(exc.Response.GetResponseStream());
                    throw new Exception(reader.ReadToEnd());
                }
                return null;
            }
        }


        /// <summary>
        /// This function is used to retrieve the optionset value using the optionset text label
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedLabel"></param>
        /// <returns></returns>
        private int GetOptionsSetValueForLabel(string entityName, string attributeName, string selectedLabel)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)_orgService.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            int selectedOptionValue = 0;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                {
                    selectedOptionValue = oMD.Value.Value;
                    break;
                }
            }
            return selectedOptionValue;
        }

        /// <summary>
        /// This function is used to retrieve the optionset labek using the optionset value
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeName"></param>
        /// <param name="selectedValue"></param>
        /// <returns></returns>
        private string GetOptionsSetTextForValue(string entityName, string attributeName, int selectedValue)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)_orgService.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = null;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.LocalizedLabels[0].Label.ToString();
                    break;
                }
            }
            return selectedOptionLabel;
        }

        private EntityCollection GetEntityRecords(string entityName, string columnName, string columnValue)
        {
            ColumnSet indexCol = new ColumnSet(true);

            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = indexCol;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)_orgService.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private EntityCollection GetEntityRecords(string entityName, string columnName, string columnValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = columnSet;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)_orgService.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private EntityCollection GetIntCredentials()
        {
            EntityCollection integrationCredentials = GetEntityRecords(_entIntegrationCredential, _attrIntAPIHost, "1");
            return integrationCredentials;
        }
    }
}
