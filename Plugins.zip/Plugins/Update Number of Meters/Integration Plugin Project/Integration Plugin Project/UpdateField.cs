﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Text;
using System.Xml;
using System.Xml.Linq;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace UpdateNumberofMeters
{
   
    public class UpdateField
        : IPlugin
    {
       
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);

            try
            {
                // The InputParameters collection contains all the data passed in the message request.
                if (!context.InputParameters.Contains("Target")) { return; }

                EntityReference ef = (EntityReference)context.InputParameters["Target"];
                if (ef.LogicalName != "opportunity") { return; }

                Relationship relationship = (Relationship)context.InputParameters["Relationship"];
                if (relationship.SchemaName != "spg_opportunity_spg_account") { return; }

                UpdateNumberofMeters(ref service, ef);



            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
        private void UpdateNumberofMeters(ref IOrganizationService service, EntityReference Opportunity)
        {
            int count = GetAccountsCount(ref service, Opportunity.Id);
            Entity OpportunityEntity = new Entity("opportunity");
            OpportunityEntity.Id = Opportunity.Id;
            OpportunityEntity.Attributes.Add("spg_numberofmeters", count);
            service.Update(OpportunityEntity);
        }
        private static int GetAccountsCount(ref IOrganizationService service, Guid OpportunityId)
        {

            int count = 0;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_opportunity_spg_account";
            indexattribute.Attributes.AddRange(new string[] { "opportunityid" });
            indexattribute.Values.AddRange(new object[] { OpportunityId });
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                count = index.Entities.Count;
            }

            return count;
        }


    }
}
