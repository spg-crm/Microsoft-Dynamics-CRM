﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace Clone_Opportunity_Related_Entitties
{
    public class CloneRecord : CodeActivity
    {
        [Input("Previous Opportunity Id")]
        public InArgument<string> previousOpportunityId { get; set; }

        [Input("New Opportunity Id")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> opportunityReference { get; set; }

        private const string fieldsConfigurationEntityName = "spg_fieldsconfiguration";
        private const string fieldIsGrid = "spg_isgrid";
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracer = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                string copyFromOpportunityId = previousOpportunityId.Get<string>(executionContext);
                EntityReference newOpportunityReference = opportunityReference.Get<EntityReference>(executionContext);

                if (copyFromOpportunityId != string.Empty)

                {
                    EntityCollection fieldConfigurationCollection = GetFieldsConfiguration(ref service);
                    if (fieldConfigurationCollection != null)

                    {
                        foreach (Entity fieldConfigurationEntity in fieldConfigurationCollection.Entities)

                        {
                            string opportunityLookupFieldName = string.Empty;
                            string gridEntityName = string.Empty;
                            if (fieldConfigurationEntity.Attributes.Contains("spg_name"))

                            {
                                opportunityLookupFieldName = fieldConfigurationEntity.Attributes["spg_name"].ToString();
                            }

                            if (fieldConfigurationEntity.Attributes.Contains("spg_gridentityname"))

                            {
                                gridEntityName = fieldConfigurationEntity.Attributes["spg_gridentityname"].ToString(); 
                            }

                            if (opportunityLookupFieldName.Length > 0 && gridEntityName.Length > 0 )

                            {
                               EntityCollection relatedRecordCollection = GetRelatedRecord(ref service, gridEntityName, opportunityLookupFieldName, new Guid(copyFromOpportunityId));

                                if (relatedRecordCollection != null)

                                {
                                  
                                    foreach (Entity relatedEntity in relatedRecordCollection.Entities)

                                    {
                                        if (relatedEntity.Attributes.Contains("spg_opportunityproductid"))

                                        {
                                            relatedEntity.Attributes.Remove("spg_opportunityproductid");
                                  
                                        }

                                        if (relatedEntity.Attributes.Contains(opportunityLookupFieldName))

                                        {
                                            relatedEntity.Attributes.Remove(opportunityLookupFieldName);

                                        }

                                        relatedEntity.Attributes.Add(opportunityLookupFieldName, newOpportunityReference);

                                        relatedEntity.Id = Guid.NewGuid();
                                        service.Create(relatedEntity);
                                        
                                    }
                                }
                            
                            }
                        }
                    }
                }

            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
        private EntityCollection GetRelatedRecord(ref IOrganizationService service, string EntityName, string OpportunityLookupFieldName , Guid OpportunityId)
        {
          
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = EntityName;
            indexattribute.Attributes.AddRange(new string[] { OpportunityLookupFieldName });
            indexattribute.Values.AddRange(OpportunityId);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
           
            return index;
        }
        private EntityCollection GetFieldsConfiguration(ref IOrganizationService service)
        {

            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = fieldsConfigurationEntityName;
            indexattribute.Attributes.AddRange(new string[] { fieldIsGrid });
            indexattribute.Values.AddRange(true);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            return index;
        }
    }
}
