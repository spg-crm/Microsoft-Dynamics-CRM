﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.IO;
using System.Net;
using System.Net.Security;
using System.ServiceModel.Description;
using System.Text;
using System.Xml;
using Address_Verification_Project;

namespace AccountsESGIntegration
{
    public class AccountsIntegration : CodeActivity
    {
        
        
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracer = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                string service_param = string.Empty;
                string myservice_data = string.Empty;
                string url = string.Empty;
                string userAccount = string.Empty;
                string password = string.Empty;
               
                EntityReference OpportunityReference = opportunityReference.Get<EntityReference>(executionContext);
                Entity integrationCredential =  GetIntCredentials(ref service, 1);
               //Setting API URL, Account and Password
                if (integrationCredential.Attributes.Contains("spg_apiurl"))
                    url = integrationCredential.Attributes["spg_apiurl"].ToString();

                if (integrationCredential.Attributes.Contains("spg_apiaccount"))
                    userAccount = integrationCredential.Attributes["spg_apiaccount"].ToString();

                if (integrationCredential.Attributes.Contains("spg_apipassword"))
                    password = integrationCredential.Attributes["spg_apipassword"].ToString();
                string opportunityToken = OpportunityToken.Get<string>(executionContext);
               
                if (opportunityToken.Length > 0 && url.Length > 0 && userAccount.Length > 0 && password.Length > 0 )
                {
                    service_param = "<serviceParameters>" +
                                           "<logonUserid>" + userAccount+" </logonUserid>" +
                                           "<logonPassword>" + password + "</logonPassword>" +
                                           "<companyID>CW_SOURCE</companyID>" +
                                           "<partName>Opportunity.Opportunity_Task_Create_New</partName>" +
                                           "<partFunction>process</partFunction>";
                    service_param += "<partTokens>Opportunity_Tkn=" + opportunityToken + "</partTokens>" +
                                            "<partSearch></partSearch>" +
                                            "<partOrder></partOrder>" +
                                            "</serviceParameters>";
                    ColumnSet colset = new ColumnSet(new string[] { "spg_accountid" });
                    
                    EntityCollection accountsCollection = GetEntityRecords(ref service, "spg_opportunity_spg_account", "opportunityid", OpportunityReference.Id.ToString(), colset);//Fetching Accounts Ids from Many to Many Table...
                    foreach (Entity accountEntity in accountsCollection.Entities)
                    {
                       
                        EntityCollection accountcollection = GetEntityRecords(ref service, "spg_account", "spg_accountid", accountEntity["spg_accountid"].ToString());//Fetching Accounts Entity Record...
                        foreach (Entity account in accountcollection.Entities)
                        {
                           
                            string xmlresponse = string.Empty;
                            string _historicalUsage = string.Empty;
                            string _requestStart = string.Empty;
                            string accountNumber = string.Empty;
                            string customerName = string.Empty;
                            string postalCode = string.Empty;
                            string cityName = string.Empty;
                            string countyName = string.Empty;
                            string stateName = string.Empty;
                            string billMethodDescription = string.Empty;
                            string distributorName = string.Empty;
                            string address1 = string.Empty;

                            OptionSetValue _historicalusagevalue = account.Attributes["spg_historicalusage"] as OptionSetValue;
                           
                            if (_historicalusagevalue.Value > 0)
                            {
                                _historicalUsage = GetOptionsSetTextForValue(service, "spg_account", "spg_historicalusage", _historicalusagevalue.Value);
                            }
                            if (account.Attributes.Contains("spg_utility"))
                            {
                                distributorName = ((EntityReference)account.Attributes["spg_utility"]).Name;
                            }
                            if (account.Attributes.Contains("spg_adressline1"))
                            {
                                address1 = account.Attributes["spg_adressline1"].ToString();
                            }
                            if (account.Attributes.Contains("spg_ldcaccountnumber"))
                            {
                                accountNumber = account["spg_ldcaccountnumber"].ToString();
                            }

                            if (account.Attributes.Contains("spg_customername"))
                            {
                                customerName = account["spg_customername"].ToString();
                            }

                            if (account.Attributes.Contains("spg_address1_postalcode"))
                            {
                                postalCode = account["spg_address1_postalcode"].ToString();
                            }
                            if (account.Attributes.Contains("spg_address1_city"))
                            {
                                cityName = account["spg_address1_city"].ToString();
                            }
                            if (account.Attributes.Contains("spg_address1_state"))
                            {
                                stateName = account["spg_address1_state"].ToString();
                            }
                            if (account.Attributes.Contains("spg_address1_county"))
                            {
                                countyName = account.Attributes["spg_address1_county"].ToString();
                            }
                            if (countyName == string.Empty)//Fetch County Name from Service Object Application if Account does not have the County...
                            {
                                countyName = GetCountyName(address1, cityName, stateName, postalCode, ServiceObjectKey, account, ref service, accountNumber, OpportunityReference);
                                if (countyName != string.Empty)
                                {
                                    countyIntegrationFlag = "Success";
                                }
                                else
                                {
                                    countyIntegrationFlag = "Fail";
                                }
                            }
                            else { countyIntegrationFlag = "Not Executed"; }
                            
                            if (account.Attributes.Contains("spg_billmethoddesc"))
                            {
                                billMethodDescription = ((EntityReference)account["spg_billmethoddesc"]).Name;
                            }
                           
                          bool isIntegrated=  CheckAccountsIsIntegrated(ref service, accountNumber , OpportunityReference.Id);//Check if account is already integrated or not....
                            if (isIntegrated == false)
                            {
                                myservice_data = "<serviceData>" +
                                   "<Process_Type>SaveAccount</Process_Type>" +
                                   "<Distributor_Name>" + replaceSpecialCharacter(distributorName) + "</Distributor_Name>" +
                                   "<LDC_Account_Num>" + accountNumber + "</LDC_Account_Num>" +
                                   "<Customer_Name>" + replaceSpecialCharacter(customerName) + "</Customer_Name>" +
                                   "<Account_Name></Account_Name>" +
                                   "<Equipment_Id_Code></Equipment_Id_Code>" +
                                   "<Historical_Usage_Desc>" + _historicalUsage + "</Historical_Usage_Desc>" +
                                   "<Service_Type_Desc>Electric</Service_Type_Desc>" +
                                   "<Requested_Start_Date>" + _requestStart + "</Requested_Start_Date>" +
                                   "<First_Name></First_Name>" +
                                   "<Last_Name></Last_Name>" +
                                   "<Revenue_Class_Desc>Commercial</Revenue_Class_Desc>" +
                                   "<Postal_Code>" + postalCode + "</Postal_Code>" +
                                   "<City_Name>" + replaceSpecialCharacter(cityName) + "</City_Name>" +
                                   "<Ln1_Addr>" + replaceSpecialCharacter(address1) + "</Ln1_Addr>" +
                                   "<Ln2_Addr></Ln2_Addr>" +
                                   "<State_Name>" + replaceSpecialCharacter(stateName) + "</State_Name>" +
                                   // "<State_Name>Texas</State_Name>" +
                                   "<Combine_Name_Ind>Y</Combine_Name_Ind>" +
                                   "<County_Name>" + replaceSpecialCharacter( countyName) + "</County_Name>" +
                                   "<Bill_Method_Desc>" + billMethodDescription + "</Bill_Method_Desc>" +
                                   "<Service_Address></Service_Address>" +
                                   "<Status_Desc></Status_Desc>" +
                                   "<Customer_Prospect_Tkn></Customer_Prospect_Tkn>" +
                                   "<Customer_Prospect_Account_Tkn></Customer_Prospect_Account_Tkn>" +
                                   "<Opportunity_Account_Tkn></Opportunity_Account_Tkn>" +
                                   "</serviceData>";

                                // Xmlresponse = HttpSOAPRequest("https://208.253.5.105/P2CAppSource/services/VersatilityWebServiceProxy", service_param, myservice_data, ref tracer, OpportunityReference, accountNumber, ref service);
                                xmlresponse = HttpSOAPRequest(url, service_param, myservice_data, ref tracer, OpportunityReference, accountNumber, ref service);
                            }
                        }
                    }
                    createCountyIntegrationStatus(ref service, countyIntegrationFlag, OpportunityReference);//Creating County Integration Status Record for Notification...
                }
            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
        private  EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue, ColumnSet columnSet)
        {
            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = columnSet;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private  EntityCollection GetEntityRecords(ref IOrganizationService service, string entityName, string columnName, string columnValue)
        {
            ColumnSet indexCol = new ColumnSet(true);

            QueryByAttribute indexAttribute = new QueryByAttribute();
            indexAttribute.EntityName = entityName;
            indexAttribute.Attributes.AddRange(new string[] { columnName });
            indexAttribute.Values.AddRange(columnValue);
            indexAttribute.ColumnSet = indexCol;

            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexAttribute;

            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        private  string GetOptionsSetTextForValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = null;
            foreach (OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.LocalizedLabels[0].Label.ToString();
                    break;
                }
            }
            return selectedOptionLabel;
        }
        public  string HttpSOAPRequest(string url, string serviceParameters, string serviceData, ref ITracingService tracer, EntityReference OpportunityReference, string AccountNumber, ref IOrganizationService service)
        {
            // trust all certs
            ServicePointManager.ServerCertificateValidationCallback = ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });

            System.Net.ServicePointManager.Expect100Continue = false;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);

            req.KeepAlive = false;
            req.ConnectionGroupName = Guid.NewGuid().ToString();
            req.Headers.Add("SOAPAction", "\"\"");
            req.ContentType = "text/xml;charset=utf-8";
            req.Accept = "text/xml";
            req.Method = "POST";
            Stream stm = req.GetRequestStream();

            string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
            string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
            string input = string.Concat(soapHdr, serviceParameters, serviceData, soapTrl);
            //tracer.Trace(input);
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(soapHdr + serviceParameters + serviceData + soapTrl);
            stm.Write(bytes, 0, bytes.Length);
            stm.Close();
            
            HttpWebResponse resp;

            try
            {
                string responseText=string.Empty;
                resp = (HttpWebResponse)req.GetResponse();
               
                Stream objResponseStream = resp.GetResponseStream();
                var encoding = ASCIIEncoding.ASCII;
                using (var reader = new System.IO.StreamReader(resp.GetResponseStream(), encoding))
                {
                     responseText = reader.ReadToEnd();
                }
                string returnCode = string.Empty;
                string integrationStatus = string.Empty;
                if (responseText.Length > 0)
                {
                    if (responseText.Contains("<returnCode>") && responseText.Contains("</returnCode>"))
                    {
                        returnCode = responseText.Substring(responseText.IndexOf("<returnCode>") + 12, 2);
                        if (returnCode.Contains("<"))
                            returnCode = returnCode.Replace("<", "");
                    }
                   
                }
                if (returnCode == "20" || returnCode == "0")
                {
                    integrationStatus = "Success";
                }
                else
                {
                    integrationStatus = "Failure";
                }
                //Creating Integration Log...
                Entity accountsIntegrationLog = new Entity("spg_accountsintegrationlog");
                accountsIntegrationLog.Attributes.Add("spg_opportunity", OpportunityReference);
                accountsIntegrationLog.Attributes.Add("spg_name", AccountNumber);
                accountsIntegrationLog.Attributes.Add("spg_request", input);
                accountsIntegrationLog.Attributes.Add("spg_response", responseText);
                accountsIntegrationLog.Attributes.Add("spg_returncode", returnCode);
                accountsIntegrationLog.Attributes.Add("spg_integrationstatus", integrationStatus);
                service.Create(accountsIntegrationLog);
                return responseText;
            }
            catch (WebException exc)
            {
                if (exc.Status == WebExceptionStatus.ProtocolError)
                {
                    StreamReader reader = new StreamReader(exc.Response.GetResponseStream());
                    throw new Exception(reader.ReadToEnd());
                }
                return null;
            }
        }
        public string replaceSpecialCharacter(string Value)
        {
            if (Value.Contains("&"))
            {
                Value = Value.Replace("&", "&amp;");
            }
            return Value;
        }

        public Entity GetIntCredentials(ref IOrganizationService service, int apiHost)
        {
            Entity entity = null;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_integrationcredential";
            indexattribute.Attributes.AddRange(new string[] { "spg_apihost" });
            indexattribute.Values.AddRange(apiHost);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                entity = (Entity)index.Entities[0];
            }
            return entity;
        }

        public bool CheckAccountsIsIntegrated(ref IOrganizationService service, string accountNumber, Guid opportunityId)
        {
            Entity entity = null;
            bool returnFlag = false;
            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_accountsintegrationlog";
            indexattribute.Attributes.AddRange(new string[] { "spg_name", "spg_opportunity" ,"spg_integrationstatus" });
            indexattribute.Values.AddRange(new object[] { accountNumber ,opportunityId  ,"Success"});
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;
            if (index != null && index.Entities.Count > 0)
            {
                entity = (Entity)index.Entities[0];
                if (entity != null && entity.Attributes.Contains("spg_accountsintegrationlogid"))
                {
                    returnFlag = true;
                }
            }
            return returnFlag;
        }

        private string GetCountyName(string address, string city, string state, string zipcode, string key, Entity accountEntityObject, ref IOrganizationService service, string accountNumber, EntityReference opportunityReference)
        {
            try
            {
                string countyName = string.Empty;
                AddressVerification methods = new AddressVerification();
                countyName = methods.GetCounty(address, city, state, zipcode, key);
                accountEntityObject.Attributes.Add("spg_address1_county", countyName);
                service.Update(accountEntityObject);//Updating County on Accounts Entity....
                if (countyName.Length > 0)//Creating County Integration Log...
                {
                    createCountyIntegrationLog(ref service, accountNumber, countyName, opportunityReference, new EntityReference(accountEntityObject.LogicalName, accountEntityObject.Id), "Success");
                }
                else
                {
                    createCountyIntegrationLog(ref service, accountNumber, countyName, opportunityReference, new EntityReference(accountEntityObject.LogicalName, accountEntityObject.Id), "Failure");
                }
                
                return countyName;
            }
            catch (Exception ex)
            {
                createCountyIntegrationLog(ref service, accountNumber, "", opportunityReference, new EntityReference(accountEntityObject.LogicalName, accountEntityObject.Id), "Failure");
                return ""; }
        }
        private void createCountyIntegrationLog(ref IOrganizationService service, string accountNumber,string countyName,EntityReference opportunityReference,EntityReference accountsReference, string status)
        {
            try
            {
                Entity entity = new Entity("spg_countyintegrationlog");
                entity.Attributes.Add("spg_name", accountNumber);
                entity.Attributes.Add("spg_countyname", countyName);
                entity.Attributes.Add("spg_status", status);
                entity.Attributes.Add("spg_accountsid", accountsReference);
                entity.Attributes.Add("spg_opportunityid", opportunityReference);
                service.Create(entity);
            }
            catch (Exception ex)
            { }
        }
        private void createCountyIntegrationStatus(ref IOrganizationService service, string status,EntityReference opportunityReference)
        {
            try
            {
              EntityCollection collection =  GetEntityRecords(ref service, "spg_countyintegrationstatus", "spg_opportunityid", opportunityReference.Id.ToString());
                if (collection != null && collection.Entities.Count > 0)//Deleting Existing Record to show updated notifcation...
                {
                    foreach (Entity delentity in collection.Entities)
                    {
                        service.Delete(delentity.LogicalName,delentity.Id);
                    }
                }
                Entity entity = new Entity("spg_countyintegrationstatus");
                entity.Attributes.Add("spg_name", status);
                entity.Attributes.Add("spg_opportunityid", opportunityReference);
                service.Create(entity);
            }
            catch (Exception ex)
            { }
        }
        public const string ServiceObjectKey = "WS65-AKL1-DSY1";
        public string  countyIntegrationFlag = "Not Executed";

        [Input("Opportunity Id")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> opportunityReference { get; set; }

        [Input("Opportunity Token")]
        [ReferenceTarget("opportunity")]
        public InArgument<string> OpportunityToken { get; set; }

    }
}
