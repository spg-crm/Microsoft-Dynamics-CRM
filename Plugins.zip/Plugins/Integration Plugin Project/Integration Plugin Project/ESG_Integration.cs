﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Net;
using System.Net.Security;
using System.Xml;
using System.Xml.Linq;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace Integration_Plugin_Project
{
    enum ESGWebServiceReturnCode
    {
        Ok = 0, //signifying the process ran ok
        Initialize = 1, //signifying the process is to initialize
        OkMessage = 2, //signifying the process is to display an OK dialog
        InvalidFunction = -1, //signifying that an invalid function was passed to the server
        Error = -5, //signifying the process returned an error
        Warning = 5, //signifying the process returned a Warning
        RowAlreadyUpdated = -10, //signifying that a row has been updated by another user
        RowNoRoomToAdd = -20, //signifying that a row could not be inserted into the database
        RowTokenTooBig = -30, //signifying that the token value for a requested row is too large
        VersionMismatch = -40, //signifying that a version mismatch has been detected between the client and the server
        ServerUnavailable = -50, //signifying that the server is unavailable
        ServerBusy = -60, //signifying that the server is busy
        ProgramNotFound = -70, //signifying that a requested program was not found
        RowDeleted = 10, //signifying that the row was deleted successfully
        RowAllRetrieved = 100, //signifying that all rows have been retrieved
        RowNotFound = 101, //signifying that the requested row was not found
        TaskCompletedOk = 20, //signifying the task completed successfully
        Information = 30, //signifying the process returned an Informational return code
    }

    public class ESG_Integration
    {
        #region Transaction entity field Constants

        private string _attrContactName = "spg_contactname";
        private string _attrEMailAddr = "spg_emailaddr";
        private string _attrMarketerName = "spg_marketername";
        private string _attrOpportunityName = "spg_opportunityname";
        private string _attrOpportunityID = "spg_esgportalopportunityid";
        private string _attrOpportunityTkn = "spg_esgportalopportunitytkn";
        private string _attrPhoneNum = "spg_phonenum";
        private string _attrProcessType = "spg_processtype";
        private string _attrContractId = "spg_contract_id";
        private string _attrQuoteInd = "spg_quoteind";
        private string _attrReturnCode = "spg_returncode";
        private string _attrReturnDetails = "spg_returndetails";
        private string _attrReturnMessage = "spg_returnmessage";
        private string _attrCommodity = "spg_servicetypedesc";
        private string _attrStatusDesc = "spg_statusdesc";
        private string _attrSubStatusDesc = "spg_substatusdesc";

        private string _attrBDM = "spg_bdm";
        private string _attrBroker = "spg_broker";
        private string _attrBrokerAgent = "spg_brokeragent";
        private string _attrBrokerCategory = "spg_brokercategory";
        private string _attrBrokerFee = "spg_brokerfee";
        private string _attrSourceMargin = "spg_sourcemargin";
        private string _attrBrokerType = "spg_brokertype";
        private string _attrUnit = "spg_unit";
        private string _attrBrokerName = "spg_brokername";
        private string _attrBrokerToken = "spg_brokertoken";

        private string _attrContractstartdate = "spg_contract_start_date";
        private string _attrContractretailadder = "spg_contract_retail_adder";
        private string _attrContractrate = "spg_contractrate";
        private string _attrDatepriced = "spg_date_priced";
        private string _attrTerm = "spg_term";
        private string _attrClosedate = "spg_contractclosedate";
        private string _attrMeterfee = "spg_meter_fee";
        private string _attrContractid = "spg_contract_id";
        private string _attrBrokerfee = "spg_brokerfee";
        private string _attrSourcemargin = "spg_sourcemargin";
        private string _attrContractSourcemargin = "spg_contract_source_margin";
        private string _attrAnnualmwh= "spg_annual_mwh";
        private string _attrTermmwh = "spg_esg_term_mwh";
        private string _attrContractstatus= "spg_contract_status";
        private string _attrProductName = "spg_product_name";
        private string _attrPaymentTerms = "spg_payment_terms";
        private string _attrContractIntegrationStatus = "spg_contractintegrationstatus";
        private string _attrPricingContractCreateDate = "spg_pricingcontractcreatedate";
        private string _attrPricingQuoteID = "spg_pricingquoteid";
        private string _attrProduct = "spg_product";

        private string _attrIntAPIUrl = "spg_apiurl";
        private string _attrIntAPIAccount = "spg_apiaccount";
        private string _attrIntAPIPassword = "spg_apipassword";

        private string _attrResultXML = "spg_resultxml";
        private string _attrRequestDataXML = "spg_dataxml";


        #endregion

        #region Class attributes used to integration opportunity to ESG Portal
        private string process_Type = string.Empty;
        private string contract_ID = string.Empty;
        private string opportunity_Tkn = string.Empty;
        private string opportunity_ID = string.Empty;
        private string category_Desc = string.Empty;
        private string broker_Code = string.Empty;
        private string broker_Type = string.Empty;
        private string status_Desc = string.Empty;
        private string sub_Status_Desc = string.Empty;
        private string marketer_Name = string.Empty;
        private string opportunity_Name = string.Empty;
        private string contact_Name = string.Empty;
        private string phone_Num = string.Empty;
        private string e_Mail_Addr = string.Empty;
        private string service_Type_Desc = string.Empty;
        private string log_Text = string.Empty;
        private string quote_Ind = string.Empty;
        private string unit_Measure_Desc = string.Empty;
        private decimal broker_Fee_Num;
        private string broker_Name = string.Empty;
        private string broker_Tkn = string.Empty;


        private string opp_ID = string.Empty;
        private string customer_Name = string.Empty;
        private string contract_Start_Date = string.Empty;
        private string contract_Retail_Adder = string.Empty;
        private string contract_Rate = string.Empty;
        private string date_Priced = string.Empty;
        private string Product = string.Empty;
        private string product_Name = string.Empty;
        private string Term = string.Empty;
        private string payment_Terms = string.Empty;
        private string close_Date = string.Empty;
        private string meter_Fee = string.Empty;
        private string quote_ID = string.Empty;
        private string broker_Fee = string.Empty;
        private string source_Margin = string.Empty;
        private string source_Margin_UOM = string.Empty;
        private string annual_MWH = string.Empty;
        private string term_MWH = string.Empty;
        private string contract_Create_Date_Time = string.Empty;
        private string contract_Status = string.Empty;

        private string url = string.Empty;
        private string userId = string.Empty;
        private string password = string.Empty;
        private string service_parameters = string.Empty;
        private string service_data = string.Empty;
        private string return_Code = string.Empty;
        private string return_Message = string.Empty;
        private string return_Details = string.Empty;
        private string input = string.Empty;

        XmlDocument xmlResponse = null;
        #endregion

        #region Get/Set methods for attributes
        public string Process_Type
        {
            get
            {
                return process_Type.Replace("&amp;", "&");
            }

            set
            {
                process_Type = value.Replace("&", "&amp;");
            }
        }
        public string Contract_ID
        {
            get
            {
                return contract_ID.Replace("&amp;", "&");
            }

            set
            {
                contract_ID = value.Replace("&", "&amp;");
            }
        }

        public string Opportunity_Tkn
        {
            get
            {
                return opportunity_Tkn.Replace("&amp;", "&");
            }
            set
            {
                opportunity_Tkn = value.Replace("&", "&amp;");
            }
        }

        public string Opportunity_ID
        {
            get
            {
                return opportunity_ID.Replace("&amp;", "&");
            }
        }

        public string Status_Desc
        {
            get
            {
                return status_Desc;
            }

            set
            {
                status_Desc = value;
            }
        }

        public string Sub_Status_Desc
        {
            get
            {
                return sub_Status_Desc;
            }

            set
            {
                sub_Status_Desc = value;
            }
        }

        public string Marketer_Name
        {
            get
            {
                return marketer_Name.Replace("&amp;", "&");
            }

            set
            {
                marketer_Name = value.Replace("&", "&amp;");
            }
        }

        public string Opportunity_Name
        {
            get
            {
                return opportunity_Name.Replace("&amp;", "&");
            }

            set
            {
                if (value.Length > 50)
                    throw new ArgumentOutOfRangeException("Opportunity_Name", "Maximum length for Opportunity Name is 50");

                opportunity_Name = value.Replace("&", "&amp;");
            }
        }

        public string Contact_Name
        {
            get
            {
                return contact_Name.Replace("&amp;", "&");
            }

            set
            {
                contact_Name = value.Replace("&", "&amp;");
            }
        }

        public string Phone_Num
        {
            get
            {
                return phone_Num;
            }

            set
            {
                phone_Num = value;
            }
        }

        public string E_Mail_Addr
        {
            get
            {
                return e_Mail_Addr;
            }

            set
            {
                e_Mail_Addr = value;
            }
        }

        public string Service_Type_Desc
        {
            get
            {
                return service_Type_Desc;
            }

            set
            {
                service_Type_Desc = value;
            }
        }

        public string Log_Text
        {
            get
            {
                return log_Text;
            }

            set
            {
                log_Text = value;
            }
        }

        public string Quote_Ind
        {
            get
            {
                return quote_Ind;
            }

            set
            {
                quote_Ind = value;
            }
        }

        public string Url
        {
            get
            {
                return url;
            }

            set
            {
                url = value;
            }
        }

        public string UserAccount
        {
            get
            {
                return userId;
            }

            set
            {
                userId = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Service_parameters
        {
            get
            {
                return service_parameters;
            }

            set
            {
                service_parameters = value;
            }
        }

        public string Service_data
        {
            get
            {
                return service_data;
            }

            set
            {
                service_data = value;
            }
        }

        public string ReturnCode
        {
            get
            {
                return return_Code;
            }
        }
        public string Category_Desc
        {
            get
            {
                return category_Desc.Replace("&amp;", "&");
            }

            set
            {
                category_Desc = value.Replace("&", "&amp;");
            }
        }
        public string Unit_Measure_Desc
        {
            get
            {
                return unit_Measure_Desc.Replace("&amp;", "&");
            }

            set
            {
                unit_Measure_Desc = value.Replace("&", "&amp;");
            }
        }

        public decimal Broker_Fee_Num
        {
            get
            {
                return broker_Fee_Num * 1000;
            }

            set
            {
                if (value != 0)
                    broker_Fee_Num = value / 1000;
            }
        }

        public string Broker_Name
        {
            get
            {
                return broker_Name.Replace("&amp;", "&");
            }

            set
            {
                broker_Name = value.Replace("&", "&amp;");
            }
        }

        public string Broker_Tkn
        {
            get
            {
                return broker_Tkn.Replace("&amp;", "&");
            }

            set
            {
                broker_Tkn = value.Replace("&", "&amp;");
            }
        }

        public string Broker_Code
        {
            get
            {
                return broker_Code.Replace("&amp;", "&");
            }

            set
            {
                broker_Code = value.Replace("&", "&amp;");
            }
        }

        public string Broker_Type
        {
            get
            {
                return broker_Type.Replace("&amp;", "&");
            }

            set
            {
                broker_Type = value.Replace("&", "&amp;");
            }
        }
        public string ReturnMessage
        {
            get
            {
                return return_Message;
            }
        }

        public string ReturnDetails
        {
            get
            {
                return return_Details;
            }
        }

        public XmlDocument XmlResponse
        {
            get
            {
                return xmlResponse;
            }

            set
            {
                xmlResponse = value;
            }
        }
        #endregion

        public Boolean IntegrateOpportunity(ref ITracingService tracer)
        {
            try
            {
                service_parameters = "<serviceParameters>" +
                                     "<logonUserid>" + userId + "</logonUserid>" +
                                     "<logonPassword>" + password + "</logonPassword>" +
                                     "<companyID>CW_SOURCE</companyID>" +
                                     "<partName>Opportunity.Opportunity_Task_Create_New</partName>" +
                                     "<partTokens>Opportunity_Tkn=</partTokens>" +
                                     "<partFunction>process</partFunction>" +
                                     "<partSearch></partSearch>" +
                                     "</serviceParameters>";

                service_data = "<serviceData>" +
                                "<Process_Type>" + process_Type + "</Process_Type>" +
                                "<Opportunity_Tkn>" + "</Opportunity_Tkn>" +
                                "<Opportunity_ID>" + "</Opportunity_ID>" +
                                "<Status_Desc>" + "</Status_Desc>" +
                                "<Sub_Status_Desc>" + "</Sub_Status_Desc>" +
                                "<Marketer_Name>" + marketer_Name + "</Marketer_Name>" +
                                "<Opportunity_Name>" + opportunity_Name + "</Opportunity_Name>" +
                                "<Contact_Name>" + contact_Name + "</Contact_Name>" +
                                "<Phone_Num>" + phone_Num + "</Phone_Num>" +
                                "<E_Mail_Addr>" + e_Mail_Addr + "</E_Mail_Addr>" +
                                "<Service_Type_Desc>" + service_Type_Desc + "</Service_Type_Desc>" +
                                "<Log_Text>" + log_Text + "</Log_Text>" +
                                "<Quote_Ind>" + quote_Ind + "</Quote_Ind>" +
                                "</serviceData>";

                tracer.Trace("Httpsoap request..");
                tracer.Trace(Service_parameters);
                tracer.Trace(Service_data);
                xmlResponse = Invoke_Request.HttpSOAPRequest(url, Service_parameters, Service_data, ref tracer, false);

                if (xmlResponse != null)
                {
                    string Response = xmlResponse.InnerXml;

                    Response = Response.Replace(":", "_");

                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(Response);

                    XmlNode returnCode = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnCode");
                    XmlNode returnMessage = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnMessage");
                    XmlNode returnDetails = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnDetails");
                    XmlNode statusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Status_Desc");
                    XmlNode subStatusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Sub_Status_Desc");

                    if (returnCode.InnerText != "")
                        return_Code = returnCode.InnerText;

                    if (returnMessage.InnerText != "")
                        return_Message = returnMessage.InnerText;

                    if (returnDetails.InnerText != "")
                        return_Details = returnMessage.InnerText;

                    if (statusDesc.InnerText != "")
                        status_Desc = statusDesc.InnerText;

                    if (subStatusDesc.InnerText != "")
                        sub_Status_Desc = subStatusDesc.InnerText;

                    if (Convert.ToInt32(returnCode.InnerText) == (int)ESGWebServiceReturnCode.TaskCompletedOk)
                    {
                        XmlNode opportunityToken = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_Tkn");
                        XmlNode opportunityId = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_ID");

                        if (opportunityId.InnerText != "")
                            opportunity_ID = opportunityId.InnerText;

                        if (opportunityToken.InnerText != "")
                            opportunity_Tkn = opportunityToken.InnerText;

                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                string msg = string.Empty;

                msg = msg + Url;
                msg = msg + Password;
                msg = msg + UserAccount;

                throw new Exception(string.Format("Error occured {0}", ex.ToString()));


                //if (xmlResponse != null)
                //{
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, xmlResponse.InnerXml);
                //}
                //else
                //{
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, ErrorMessage);
                //}
                return false;
            }
        }
        public void IntegrateOpportunity(ref Entity entity, ref IOrganizationService service, Guid UserId, ref ITracingService tracer)
        {
            try
            {
                Boolean result;

                EntityCollection integrationCredentials = GetIntCredentials(ref service, 1);

                if (integrationCredentials != null)
                {
                    if (integrationCredentials.Entities.Count > 0)
                    {
                        Entity integrationCredential = (Entity)integrationCredentials.Entities[0];

                        if (integrationCredential.Attributes.Contains(_attrIntAPIUrl))
                            Url = integrationCredential.Attributes[_attrIntAPIUrl].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIAccount))
                            UserAccount = integrationCredential.Attributes[_attrIntAPIAccount].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIPassword))
                            Password = integrationCredential.Attributes[_attrIntAPIPassword].ToString();
                    }
                    else
                    {
                        throw new Exception("Zero records returned.");
                    }
                }
                else
                {
                    throw new Exception("Could not retrieve Integration Credentials.");
                }


                /*
                CreateOpportunity createOpportunity = new CreateOpportunity();

                createOpportunity.Url = "https://208.253.5.105/P2CAppSource/services/VersatilityWebServiceProxy";
                createOpportunity.UserId = "webcrm";
                createOpportunity.Password = "webcrm";
                */

                //#region Test project code safe to delete
                //createOpportunity.Process_Type = "SaveOpportunity";
                //createOpportunity.Marketer_Name = "Source Power &amp; Gas LLC RES";
                //createOpportunity.Opportunity_Name = "Haroon Attari Test 2";
                //createOpportunity.Contact_Name = "Azwar.Alam";
                //createOpportunity.Phone_Num = "3453161125";
                //createOpportunity.E_Mail_Addr = "aalam@medtractions.com";
                //createOpportunity.Service_Type_Desc = "Electric";
                //createOpportunity.Log_Text = "";
                //createOpportunity.Quote_Ind = "N";

                //result = IntegrateOpportunity();

                //if (result)
                //{
                //    throw new Exception(String.Format("Opportunity created successfully with id # {0}", Opportunity_ID));
                //}
                //else
                //{
                //    throw new Exception(String.Format("Opportunity could not be created {0}", Service_data));
                //}
                //#endregion

                tracer.Trace("Setting attribute..");
                if (entity.Attributes.Contains(_attrProcessType))
                {
                    tracer.Trace("into process type");
                    Process_Type = entity.Attributes[_attrProcessType].ToString();
                }

                if (entity.Attributes.Contains(_attrMarketerName))
                {
                    tracer.Trace("checking null for marketer");
                    if (entity.Attributes[_attrMarketerName] != null)
                    {
                        tracer.Trace("into marketername");
                        Marketer_Name = entity.Attributes[_attrMarketerName].ToString();
                    }
                }
                if (entity.Attributes.Contains(_attrOpportunityName))
                {
                    tracer.Trace("into opportunity name");
                    Opportunity_Name = entity.Attributes[_attrOpportunityName].ToString();
                }
                if (entity.Attributes.Contains(_attrContactName))
                {
                    tracer.Trace("into contact name");
                    Contact_Name = entity.Attributes[_attrContactName].ToString();
                }
                if (entity.Attributes.Contains(_attrPhoneNum))
                {
                    tracer.Trace("into phonen num");
                    Phone_Num = entity.Attributes[_attrPhoneNum].ToString();
                }
                if (entity.Attributes.Contains(_attrEMailAddr))
                {
                    tracer.Trace("into email address");
                    E_Mail_Addr = entity.Attributes[_attrEMailAddr].ToString();
                }
                if (entity.Attributes.Contains(_attrCommodity))
                {
                    tracer.Trace("into commodity");
                    Service_Type_Desc = entity.Attributes[_attrCommodity].ToString();
                }
                if (entity.Attributes.Contains(_attrQuoteInd))
                {
                    tracer.Trace("into quote ind");
                    Quote_Ind = entity.Attributes[_attrQuoteInd].ToString();
                }
                tracer.Trace("Initiating integration..");
                result = IntegrateOpportunity(ref tracer);

                if (result && (Opportunity_ID != String.Empty))
                {

                    //throw new Exception(String.Format("Opportunity created successfully with id # {0} - Return code {1} - Return message {2}", Opportunity_ID, ReturnCode, ReturnMessage));
                    tracer.Trace(String.Format("Opportunity created successfully with id # {0}", Opportunity_ID));

                    if (entity.Attributes.Contains(_attrStatusDesc))
                        entity.Attributes[_attrStatusDesc] = Status_Desc;
                    else
                        entity.Attributes.Add(_attrStatusDesc, Status_Desc);

                    if (entity.Attributes.Contains(_attrSubStatusDesc))
                        entity.Attributes[_attrSubStatusDesc] = Sub_Status_Desc;
                    else
                        entity.Attributes.Add(_attrSubStatusDesc, Sub_Status_Desc);

                    if (entity.Attributes.Contains(_attrOpportunityID))
                        entity.Attributes[_attrOpportunityID] = Opportunity_ID;
                    else
                        entity.Attributes.Add(_attrOpportunityID, Opportunity_ID);

                    if (entity.Attributes.Contains(_attrOpportunityTkn))
                        entity.Attributes[_attrOpportunityTkn] = Opportunity_Tkn;
                    else
                        entity.Attributes.Add(_attrOpportunityTkn, Opportunity_Tkn);

                    if (entity.Attributes.Contains(_attrReturnCode))
                        entity.Attributes[_attrReturnCode] = ReturnCode;
                    else
                        entity.Attributes.Add(_attrReturnCode, ReturnCode);

                    if (entity.Attributes.Contains(_attrReturnMessage))
                        entity.Attributes[_attrReturnMessage] = ReturnMessage;
                    else
                        entity.Attributes.Add(_attrReturnMessage, ReturnMessage);

                    if (entity.Attributes.Contains(_attrReturnDetails))
                        entity.Attributes[_attrReturnDetails] = ReturnDetails;
                    else
                        entity.Attributes.Add(_attrReturnDetails, ReturnDetails);

                    string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
                    string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
                    string dataXML = string.Concat(soapHdr, Environment.NewLine, Service_parameters, Environment.NewLine, Service_data, Environment.NewLine, soapTrl);

                    if (entity.Attributes.Contains(_attrRequestDataXML))
                        entity.Attributes[_attrRequestDataXML] = dataXML;
                    else
                        entity.Attributes.Add(_attrRequestDataXML, dataXML);

                    if (entity.Attributes.Contains(_attrResultXML))
                        entity.Attributes[_attrResultXML] = XmlResponse.InnerXml;
                    else
                        entity.Attributes.Add(_attrResultXML, XmlResponse.InnerXml);

                }
                else
                {
                    #region copied from success
                    tracer.Trace(String.Format("Opportunity created successfully with id # {0}", Opportunity_ID));

                    if (entity.Attributes.Contains(_attrStatusDesc))
                        entity.Attributes[_attrStatusDesc] = Status_Desc;
                    else
                        entity.Attributes.Add(_attrStatusDesc, Status_Desc);

                    if (entity.Attributes.Contains(_attrSubStatusDesc))
                        entity.Attributes[_attrSubStatusDesc] = Sub_Status_Desc;
                    else
                        entity.Attributes.Add(_attrSubStatusDesc, Sub_Status_Desc);

                    if (entity.Attributes.Contains(_attrOpportunityID))
                        entity.Attributes[_attrOpportunityID] = Opportunity_ID;
                    else
                        entity.Attributes.Add(_attrOpportunityID, Opportunity_ID);

                    if (entity.Attributes.Contains(_attrOpportunityTkn))
                        entity.Attributes[_attrOpportunityTkn] = Opportunity_Tkn;
                    else
                        entity.Attributes.Add(_attrOpportunityTkn, Opportunity_Tkn);

                    if (entity.Attributes.Contains(_attrReturnCode))
                        entity.Attributes[_attrReturnCode] = ReturnCode;
                    else
                        entity.Attributes.Add(_attrReturnCode, ReturnCode);

                    if (entity.Attributes.Contains(_attrReturnMessage))
                        entity.Attributes[_attrReturnMessage] = ReturnMessage;
                    else
                        entity.Attributes.Add(_attrReturnMessage, ReturnMessage);

                    if (entity.Attributes.Contains(_attrReturnDetails))
                        entity.Attributes[_attrReturnDetails] = ReturnDetails;
                    else
                        entity.Attributes.Add(_attrReturnDetails, ReturnDetails);

                    string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
                    string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
                    string dataXML = string.Concat(soapHdr, Environment.NewLine, Service_parameters, Environment.NewLine, Service_data, Environment.NewLine, soapTrl);

                    if (entity.Attributes.Contains(_attrRequestDataXML))
                        entity.Attributes[_attrRequestDataXML] = dataXML;
                    else
                        entity.Attributes.Add(_attrRequestDataXML, dataXML);

                    if (entity.Attributes.Contains(_attrResultXML))
                        entity.Attributes[_attrResultXML] = XmlResponse.InnerXml;
                    else
                        entity.Attributes.Add(_attrResultXML, XmlResponse.InnerXml);

                    #endregion
                    //throw new Exception(String.Format("Opportunity could not be created - Return code {0} - Return message {1} {2}", ReturnCode, ReturnMessage, ReturnDetails));
                    tracer.Trace("Opportunity could not be created");
                }
            }
            catch (ArgumentOutOfRangeException aore)
            {
                tracer.Trace(aore.Message);
            }
        }
        public void IntegrateBDM(ref Entity entity, ref IOrganizationService service, Guid UserId, ref ITracingService tracer)
        {
            try
            {
                Boolean result;

                EntityCollection integrationCredentials = GetIntCredentials(ref service, 1);

                if (integrationCredentials != null)
                {
                    if (integrationCredentials.Entities.Count > 0)
                    {
                        Entity integrationCredential = (Entity)integrationCredentials.Entities[0];

                        if (integrationCredential.Attributes.Contains(_attrIntAPIUrl))
                            Url = integrationCredential.Attributes[_attrIntAPIUrl].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIAccount))
                            UserAccount = integrationCredential.Attributes[_attrIntAPIAccount].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIPassword))
                            Password = integrationCredential.Attributes[_attrIntAPIPassword].ToString();
                    }
                    else
                    {
                        throw new Exception("Zero records returned.");
                    }
                }
                else
                {
                    throw new Exception("Could not retrieve Integration Credentials.");
                }

                if (entity.Attributes.Contains(_attrProcessType))
                    Process_Type = entity.Attributes[_attrProcessType].ToString();

                if (entity.Attributes.Contains(_attrOpportunityTkn))
                    Opportunity_Tkn = entity.Attributes[_attrOpportunityTkn].ToString();

                if (entity.Attributes.Contains(_attrBrokerType))
                    Broker_Type = entity.Attributes[_attrBrokerType].ToString();

                if (entity.Attributes.Contains(_attrBrokerCategory))
                    Category_Desc = entity.Attributes[_attrBrokerCategory].ToString();

                if (entity.Attributes.Contains(_attrBDM))
                    if (entity.Attributes[_attrBDM] != null)
                        Broker_Code = entity.Attributes[_attrBDM].ToString();

                if (entity.Attributes.Contains(_attrCommodity))
                    Service_Type_Desc = entity.Attributes[_attrCommodity].ToString();

                if (entity.Attributes.Contains(_attrUnit))
                    if (entity.Attributes[_attrUnit] != null)
                        Unit_Measure_Desc = entity.Attributes[_attrUnit].ToString();

                //if (entity.Attributes.Contains(_attrBrokerFee))
                //{
                //    if (entity.Attributes[_attrBrokerFee] != null)
                //    {
                //        decimal brokerfee = entity.GetAttributeValue<decimal?>(_attrBrokerFee).GetValueOrDefault(0.00m);
                //        throw new Exception(String.Format("fee value for BDM is {0}", brokerfee));
                //        integrateBDM.Broker_Fee_Num = entity.GetAttributeValue<decimal?>(_attrBrokerFee).GetValueOrDefault(0.00m);
                //    }
                //}
                if (entity.Attributes.Contains(_attrSourceMargin))
                    if (entity.Attributes[_attrSourceMargin] != null)
                        Broker_Fee_Num = entity.GetAttributeValue<decimal?>(_attrSourceMargin).GetValueOrDefault(0.00m); //((decimal)entity.Attributes[_attrBrokerFee]).Value;

                result = SaveBroker(ref tracer);

                if (result)
                {

                    //throw new Exception(String.Format("Opportunity created successfully with id # {0} - Return code {1} - Return message {2}", createOpportunity.Opportunity_ID, createOpportunity.ReturnCode, createOpportunity.ReturnMessage));
                    tracer.Trace(String.Format("BDM integrated successfully against opportunity id {0}", Opportunity_Tkn));

                    if (entity.Attributes.Contains(_attrBrokerName))
                        entity.Attributes[_attrBrokerName] = Broker_Name;
                    else
                        entity.Attributes.Add(_attrBrokerName, Broker_Name);

                    if (entity.Attributes.Contains(_attrBrokerToken))
                        entity.Attributes[_attrBrokerToken] = Broker_Tkn;
                    else
                        entity.Attributes.Add(_attrBrokerToken, Broker_Tkn);

                    if (entity.Attributes.Contains(_attrStatusDesc))
                        entity.Attributes[_attrStatusDesc] = Status_Desc;
                    else
                        entity.Attributes.Add(_attrStatusDesc, Status_Desc);

                    if (entity.Attributes.Contains(_attrReturnCode))
                        entity.Attributes[_attrReturnCode] = ReturnCode;
                    else
                        entity.Attributes.Add(_attrReturnCode, ReturnCode);

                    if (entity.Attributes.Contains(_attrReturnMessage))
                        entity.Attributes[_attrReturnMessage] = ReturnMessage;
                    else
                        entity.Attributes.Add(_attrReturnMessage, ReturnMessage);

                    if (entity.Attributes.Contains(_attrReturnDetails))
                        entity.Attributes[_attrReturnDetails] = ReturnDetails;
                    else
                        entity.Attributes.Add(_attrReturnDetails, ReturnDetails);

                    string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
                    string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
                    string dataXML = string.Concat(soapHdr, Environment.NewLine, Service_parameters, Environment.NewLine, Service_data, Environment.NewLine, soapTrl);

                    if (entity.Attributes.Contains(_attrRequestDataXML))
                        entity.Attributes[_attrRequestDataXML] = dataXML;
                    else
                        entity.Attributes.Add(_attrRequestDataXML, dataXML);

                    if (entity.Attributes.Contains(_attrResultXML))
                        entity.Attributes[_attrResultXML] = XmlResponse.InnerXml;
                    else
                        entity.Attributes.Add(_attrResultXML, XmlResponse.InnerXml);

                }
                else
                {
                    //throw new Exception(String.Format("BDM could not be integrated for opportunity id {0}", integrateBroker.Opportunity_Tkn));
                    tracer.Trace("Opportunity could not be created");
                }
            }
            catch (ArgumentOutOfRangeException aore)
            {
                tracer.Trace(aore.Message);
            }
        }
        public Boolean SaveBroker(ref ITracingService tracer)
        {
            try
            {
                service_parameters = "<serviceParameters>" +
                                     "<logonUserid>" + userId + "</logonUserid>" +
                                     "<logonPassword>" + password + "</logonPassword>" +
                                     "<companyID>CW_SOURCE</companyID>" +
                                     "<partName>Opportunity.Opportunity_Task_Create_New</partName>" +
                                     String.Format("<partTokens>Opportunity_Tkn={0}</partTokens>", opportunity_Tkn) +
                                     "<partFunction>process</partFunction>" +
                                     "<partSearch></partSearch>" +
                                     "<partOrder></partOrder>" +
                                     "</serviceParameters>";

                service_data = "<serviceData>" +
                                "<Process_Type>" + process_Type + "</Process_Type>" +
                                "<Category_Desc>" + category_Desc + "</Category_Desc>" +
                                "<Broker_Code>" + broker_Code + "</Broker_Code>" +
                                "<Broker_Type>" + broker_Type + "</Broker_Type>" +
                                "<Service_Type_Desc>" + service_Type_Desc + "</Service_Type_Desc>" +
                                "<Unit_Measure_Desc>" + unit_Measure_Desc + "</Unit_Measure_Desc>" +
                                "<Broker_Fee_Num>" + broker_Fee_Num + "</Broker_Fee_Num>" +
                                "<Broker_Name></Broker_Name>" +
                                "<Broker_Tkn></Broker_Tkn>" +
                                "<Status_Desc></Status_Desc>" +
                                "</serviceData>";

                xmlResponse = Invoke_Request.HttpSOAPRequest(url, this.Service_parameters, this.Service_data, ref tracer, false);

                if (xmlResponse != null)
                {
                    string Response = xmlResponse.InnerXml;

                    Response = Response.Replace(":", "_");

                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(Response);

                    XmlNode returnCode = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnCode");
                    XmlNode returnMessage = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnMessage");
                    XmlNode returnDetails = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnDetails");
                    XmlNode statusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Status_Desc");
                    XmlNode brokerName = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Broker_Name");
                    XmlNode brokerTkn = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Broker_Tkn");

                    if (returnCode.InnerText != "")
                        return_Code = returnCode.InnerText;

                    if (returnMessage.InnerText != "")
                        return_Message = returnMessage.InnerText;

                    if (returnDetails.InnerText != "")
                        return_Details = returnMessage.InnerText;

                    if (Convert.ToInt32(returnCode.InnerText) == (int)ESGWebServiceReturnCode.TaskCompletedOk)
                    {
                        if (statusDesc.InnerText != "")
                            status_Desc = statusDesc.InnerText;

                        if (brokerName.InnerText != "")
                            broker_Name = brokerName.InnerText;

                        if (brokerTkn.InnerText != "")
                            broker_Tkn = brokerTkn.InnerText;

                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                string msg = string.Empty;

                msg = msg + Url;
                msg = msg + Password;
                msg = msg + UserAccount;

                throw new Exception(string.Format("Error occured {0}", ex.ToString()));


                if (xmlResponse != null)
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, xmlResponse.InnerXml);
                }
                else
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, ErrorMessage);
                }
                return false;
            }

            return false;
        }
        public void IntegrateBroker(ref Entity entity, ref IOrganizationService service, Guid UserId, ref ITracingService tracer)
        {
            try
            {
                Boolean result;

                EntityCollection integrationCredentials = GetIntCredentials(ref service, 1);

                if (integrationCredentials != null)
                {
                    if (integrationCredentials.Entities.Count > 0)
                    {
                        Entity integrationCredential = (Entity)integrationCredentials.Entities[0];

                        if (integrationCredential.Attributes.Contains(_attrIntAPIUrl))
                            Url = integrationCredential.Attributes[_attrIntAPIUrl].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIAccount))
                            UserAccount = integrationCredential.Attributes[_attrIntAPIAccount].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIPassword))
                            Password = integrationCredential.Attributes[_attrIntAPIPassword].ToString();
                    }
                    else
                    {
                        throw new Exception("Zero records returned.");
                    }
                }
                else
                {
                    throw new Exception("Could not retrieve Integration Credentials.");
                }

                if (entity.Attributes.Contains(_attrProcessType))
                    Process_Type = entity.Attributes[_attrProcessType].ToString();

                if (entity.Attributes.Contains(_attrOpportunityTkn))
                    Opportunity_Tkn = entity.Attributes[_attrOpportunityTkn].ToString();

                if (entity.Attributes.Contains(_attrBrokerType))
                    Broker_Type = entity.Attributes[_attrBrokerType].ToString();

                if (entity.Attributes.Contains(_attrBrokerCategory))
                    Category_Desc = entity.Attributes[_attrBrokerCategory].ToString();

                if (entity.Attributes.Contains(_attrBroker))
                    if (entity.Attributes[_attrBroker] != null)
                        Broker_Code = entity.Attributes[_attrBroker].ToString();

                if (entity.Attributes.Contains(_attrCommodity))
                    Service_Type_Desc = entity.Attributes[_attrCommodity].ToString();

                if (entity.Attributes.Contains(_attrUnit))
                    if (entity.Attributes[_attrUnit] != null)
                        Unit_Measure_Desc = entity.Attributes[_attrUnit].ToString();

                //if (entity.Attributes.Contains(_attrBrokerFee))
                //{
                //    if (entity.Attributes[_attrBrokerFee] != null)
                //    {
                //        decimal brokerfee = entity.GetAttributeValue<decimal?>(_attrBrokerFee).GetValueOrDefault(0.00m);
                //        throw new Exception(String.Format("fee value for broker is {0}", brokerfee));
                //        integrateBroker.Broker_Fee_Num = entity.GetAttributeValue<decimal?>(_attrBrokerFee).GetValueOrDefault(0.00m);
                //    }
                //}
                if (entity.Attributes.Contains(_attrBrokerFee))
                    if (entity.Attributes[_attrBrokerFee] != null)
                        Broker_Fee_Num = ((Money)entity.Attributes[_attrBrokerFee]).Value;

                result = SaveBroker(ref tracer);

                if (result)
                {

                    //throw new Exception(String.Format("Opportunity created successfully with id # {0} - Return code {1} - Return message {2}", createOpportunity.Opportunity_ID, createOpportunity.ReturnCode, createOpportunity.ReturnMessage));
                    tracer.Trace(String.Format("BDM integrated successfully against opportunity id {0}", Opportunity_Tkn));

                    if (entity.Attributes.Contains(_attrBrokerName))
                        entity.Attributes[_attrBrokerName] = Broker_Name;
                    else
                        entity.Attributes.Add(_attrBrokerName, Broker_Name);

                    if (entity.Attributes.Contains(_attrBrokerToken))
                        entity.Attributes[_attrBrokerToken] = Broker_Tkn;
                    else
                        entity.Attributes.Add(_attrBrokerToken, Broker_Tkn);

                    if (entity.Attributes.Contains(_attrStatusDesc))
                        entity.Attributes[_attrStatusDesc] = Status_Desc;
                    else
                        entity.Attributes.Add(_attrStatusDesc, Status_Desc);

                    if (entity.Attributes.Contains(_attrReturnCode))
                        entity.Attributes[_attrReturnCode] = ReturnCode;
                    else
                        entity.Attributes.Add(_attrReturnCode, ReturnCode);

                    if (entity.Attributes.Contains(_attrReturnMessage))
                        entity.Attributes[_attrReturnMessage] = ReturnMessage;
                    else
                        entity.Attributes.Add(_attrReturnMessage, ReturnMessage);

                    if (entity.Attributes.Contains(_attrReturnDetails))
                        entity.Attributes[_attrReturnDetails] = ReturnDetails;
                    else
                        entity.Attributes.Add(_attrReturnDetails, ReturnDetails);

                    string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
                    string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
                    string dataXML = string.Concat(soapHdr, Environment.NewLine, Service_parameters, Environment.NewLine, Service_data, Environment.NewLine, soapTrl);

                    if (entity.Attributes.Contains(_attrRequestDataXML))
                        entity.Attributes[_attrRequestDataXML] = dataXML;
                    else
                        entity.Attributes.Add(_attrRequestDataXML, dataXML);

                    if (entity.Attributes.Contains(_attrResultXML))
                        entity.Attributes[_attrResultXML] = XmlResponse.InnerXml;
                    else
                        entity.Attributes.Add(_attrResultXML, XmlResponse.InnerXml);

                }
                else
                {
                    //throw new Exception(String.Format("Broker could not be integrated for opportunity id {0}", integrateBroker.Opportunity_Tkn));
                    tracer.Trace("Opportunity could not be created");
                }
            }
            catch (ArgumentOutOfRangeException aore)
            {
                tracer.Trace(aore.Message);
            }
        }
        public void IntegrateBrokerAgent(ref Entity entity, ref IOrganizationService service, Guid UserId, ref ITracingService tracer)
        {
            try
            {
                Boolean result;

                EntityCollection integrationCredentials = GetIntCredentials(ref service, 1);

                if (integrationCredentials != null)
                {
                    if (integrationCredentials.Entities.Count > 0)
                    {
                        Entity integrationCredential = (Entity)integrationCredentials.Entities[0];

                        if (integrationCredential.Attributes.Contains(_attrIntAPIUrl))
                            Url = integrationCredential.Attributes[_attrIntAPIUrl].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIAccount))
                            UserAccount = integrationCredential.Attributes[_attrIntAPIAccount].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIPassword))
                            Password = integrationCredential.Attributes[_attrIntAPIPassword].ToString();
                    }
                    else
                    {
                        throw new Exception("Zero records returned.");
                    }
                }
                else
                {
                    throw new Exception("Could not retrieve Integration Credentials.");
                }

                if (entity.Attributes.Contains(_attrProcessType))
                    Process_Type = entity.Attributes[_attrProcessType].ToString();

                if (entity.Attributes.Contains(_attrOpportunityTkn))
                    Opportunity_Tkn = entity.Attributes[_attrOpportunityTkn].ToString();

                if (entity.Attributes.Contains(_attrBrokerType))
                    Broker_Type = entity.Attributes[_attrBrokerType].ToString();

                if (entity.Attributes.Contains(_attrBrokerCategory))
                    Category_Desc = entity.Attributes[_attrBrokerCategory].ToString();

                if (entity.Attributes.Contains(_attrBrokerAgent))
                    if (entity.Attributes[_attrBrokerAgent] != null)
                        Broker_Code = entity.Attributes[_attrBrokerAgent].ToString();

                if (entity.Attributes.Contains(_attrCommodity))
                    Service_Type_Desc = entity.Attributes[_attrCommodity].ToString();

                if (entity.Attributes.Contains(_attrUnit))
                    if (entity.Attributes[_attrUnit] != null)
                        Unit_Measure_Desc = entity.Attributes[_attrUnit].ToString();

                //if (entity.Attributes.Contains(_attrBrokerFee))
                //{
                //    if (entity.Attributes[_attrBrokerFee] != null)
                //    {
                //        decimal brokerfee = entity.GetAttributeValue<Money>(_attrBrokerFee).GetValueOrDefault(0.00m);
                //        throw new Exception(String.Format("fee value for broker agent is {0}", brokerfee));
                //        integrateBrokerAgent.Broker_Fee_Num = entity.GetAttributeValue<decimal?>(_attrBrokerFee).GetValueOrDefault(0.00m);
                //    }
                //}
                if (entity.Attributes.Contains(_attrBrokerFee))
                    if (entity.Attributes[_attrBrokerFee] != null)
                        Broker_Fee_Num = ((Money)entity.Attributes[_attrBrokerFee]).Value;

                result = SaveBroker(ref tracer);

                if (result)
                {

                    //throw new Exception(String.Format("Opportunity created successfully with id # {0} - Return code {1} - Return message {2}", createOpportunity.Opportunity_ID, createOpportunity.ReturnCode, createOpportunity.ReturnMessage));
                    tracer.Trace(String.Format("BDM integrated successfully against opportunity id {0}", Opportunity_Tkn));

                    if (entity.Attributes.Contains(_attrBrokerName))
                        entity.Attributes[_attrBrokerName] = Broker_Name;
                    else
                        entity.Attributes.Add(_attrBrokerName, Broker_Name);

                    if (entity.Attributes.Contains(_attrBrokerToken))
                        entity.Attributes[_attrBrokerToken] = Broker_Tkn;
                    else
                        entity.Attributes.Add(_attrBrokerToken, Broker_Tkn);

                    if (entity.Attributes.Contains(_attrStatusDesc))
                        entity.Attributes[_attrStatusDesc] = Status_Desc;
                    else
                        entity.Attributes.Add(_attrStatusDesc, Status_Desc);

                    if (entity.Attributes.Contains(_attrReturnCode))
                        entity.Attributes[_attrReturnCode] = ReturnCode;
                    else
                        entity.Attributes.Add(_attrReturnCode, ReturnCode);

                    if (entity.Attributes.Contains(_attrReturnMessage))
                        entity.Attributes[_attrReturnMessage] = ReturnMessage;
                    else
                        entity.Attributes.Add(_attrReturnMessage, ReturnMessage);

                    if (entity.Attributes.Contains(_attrReturnDetails))
                        entity.Attributes[_attrReturnDetails] = ReturnDetails;
                    else
                        entity.Attributes.Add(_attrReturnDetails, ReturnDetails);

                    string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";
                    string soapTrl = "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
                    string dataXML = string.Concat(soapHdr, Environment.NewLine, Service_parameters, Environment.NewLine, Service_data, Environment.NewLine, soapTrl);

                    if (entity.Attributes.Contains(_attrRequestDataXML))
                        entity.Attributes[_attrRequestDataXML] = dataXML;
                    else
                        entity.Attributes.Add(_attrRequestDataXML, dataXML);

                    if (entity.Attributes.Contains(_attrResultXML))
                        entity.Attributes[_attrResultXML] = XmlResponse.InnerXml;
                    else
                        entity.Attributes.Add(_attrResultXML, XmlResponse.InnerXml);

                }
                else
                {
                    //throw new Exception(String.Format("Broker Agent could not be integrated for opportunity id {0}", integrateBroker.Opportunity_Tkn));
                    tracer.Trace("Opportunity could not be created");
                }
            }
            catch (ArgumentOutOfRangeException aore)
            {
                tracer.Trace(aore.Message);
            }
        }

        public Boolean GetContract(ref ITracingService tracer)
        {
            try
            {
                service_parameters = "<serviceParameters>" +
                                                          "<partName>SalesPortal.GetContractList</partName>" +
                                                          "<partTokens>Opportunity_Tkn=</partTokens>" +
                                                          "<partFunction>passthrough</partFunction>" +
                                                          "<partSearch/>" +
                                                          "<partOrder/>" +
                                                          "<partLastToken/>" +
                                                          "<logonUserid>"+ userId+ "</logonUserid>" +
                                                          "<logonPassword>" + password + "</logonPassword>" +
                                                          "<companyID>CW_SOURCE</companyID>" +
                                                          "</serviceParameters>";

                service_data = "<serviceData>" +
                               "<contractID>" + Contract_ID + "</contractID>" +
                               "<oppId></oppId>" +
                               "<quoteID></quoteID>" +
                               "</serviceData>";
                //tracer.Trace(service_parameters);

                tracer.Trace("Contract : " +Contract_ID);
                tracer.Trace("URL : " + url);
                xmlResponse = Invoke_Request.HttpSOAPRequest(url, this.Service_parameters, this.Service_data, ref tracer, true);

                if (xmlResponse != null)
                {
                    string Response = xmlResponse.InnerXml;

                    Response = Response.Replace(":", "_");
                    tracer.Trace(Response.ToString());


                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(Response);

                    XmlNode returnCode = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnCode");
                    XmlNode returnMessage = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnMessage");
                    XmlNode returnDetails = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnDetails");
                    XmlNode oppID = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/opp_id");
                    XmlNode customerName = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/cust_name");
                    XmlNode contractStartDate = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_start_date");
                    XmlNode contractRetailAdder = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_retail_adder");
                    XmlNode contractRate = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_rate");
                    XmlNode datePriced = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/date_priced");
                    XmlNode product = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/product");
                    XmlNode productName = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/product_name");
                    XmlNode term = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/term");
                    XmlNode paymentTerms = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/payment_terms");
                    XmlNode closeDate = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/close_date");
                    XmlNode meterFee = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/meter_fee");
                    XmlNode contractID = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_id");
                    XmlNode quoteID = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/quote_id");
                    XmlNode brokerFee = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/broker_fee");
                    XmlNode sourceMargin = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/source_margin");
                    XmlNode sourceMarginUOM = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/source_margin_uom");
                    XmlNode annulaMWH = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/annual_mwh");
                    XmlNode termMWH = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/term_mwh");
                    XmlNode contractCreateDateTime = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_create_date_time");
                    XmlNode contractStatus = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/serviceData/SalesPortal.GetContractList/contract_status");

                    if (returnCode.InnerText != "")
                        return_Code = returnCode.InnerText;

                    if (returnMessage.InnerText != "")
                        return_Message = returnMessage.InnerText;

                    if (returnDetails.InnerText != "")
                        return_Details = returnMessage.InnerText;

                    if (Convert.ToInt32(returnCode.InnerText) == (int)ESGWebServiceReturnCode.TaskCompletedOk || Convert.ToInt32(returnCode.InnerText) == (int)ESGWebServiceReturnCode.Ok)
                    {
                        if (oppID.InnerText != "")
                            opp_ID = oppID.InnerText;

                        if (customerName.InnerText != "")
                            customer_Name = customerName.InnerText;

                        if (contractStartDate.InnerText != "")
                            contract_Start_Date = contractStartDate.InnerText;

                        if (contractRetailAdder.InnerText != "")
                            contract_Retail_Adder = contractRetailAdder.InnerText;

                        if (contractRate.InnerText != "")
                            contract_Rate = contractRate.InnerText;

                        if (datePriced.InnerText != "")
                            date_Priced = datePriced.InnerText;

                        if (product.InnerText != "")
                            Product = product.InnerText;

                        if (productName.InnerText != "")
                            product_Name = productName.InnerText;

                        if (term.InnerText != "")
                            Term = term.InnerText;

                        if (paymentTerms.InnerText != "")
                            payment_Terms = paymentTerms.InnerText;

                        if (closeDate.InnerText != "")
                            close_Date = closeDate.InnerText;

                        if (meterFee.InnerText != "")
                            meter_Fee = meterFee.InnerText;
                        
                        if (contractID.InnerText != "")
                            contract_ID = contractID.InnerText;

                        if (quoteID.InnerText != "")
                            quote_ID = quoteID.InnerText;

                        if (brokerFee.InnerText != "")
                            broker_Fee = brokerFee.InnerText;

                        if (sourceMargin.InnerText != "")
                            source_Margin = sourceMargin.InnerText;

                        if (sourceMarginUOM.InnerText != "")
                            source_Margin_UOM = sourceMarginUOM.InnerText;

                        if (annulaMWH.InnerText != "")
                            annual_MWH = annulaMWH.InnerText;

                        if (termMWH.InnerText != "")
                            term_MWH = termMWH.InnerText;

                        if (contractCreateDateTime.InnerText != "")
                            contract_Create_Date_Time = contractCreateDateTime.InnerText;

                        if (contractStatus.InnerText != "")
                            contract_Status = contractStatus.InnerText;


                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                string msg = string.Empty;

                msg = msg + Url;
                msg = msg + Password;
                msg = msg + UserAccount;

                tracer.Trace((string.Format("Error occured {0}", ex.ToString())));

                throw new Exception(string.Format("Error occured {0}", ex.ToString()));


                if (xmlResponse != null)
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, xmlResponse.InnerXml);
                }
                else
                {
                    //  Util.FileWrite(strPath, "Response-" + CustomerID, ErrorMessage);
                }
                return false;
            }

            return false;
        }
        public void IntegrateContract(ref Entity entity, ref IOrganizationService service, Guid UserId, ref ITracingService tracer)
        {
            try
            {
                Boolean result;

                EntityCollection integrationCredentials = GetIntCredentials(ref service, 1);

                if (integrationCredentials != null)
                {
                    if (integrationCredentials.Entities.Count > 0)
                    {
                        Entity integrationCredential = (Entity)integrationCredentials.Entities[0];

                        if (integrationCredential.Attributes.Contains(_attrIntAPIUrl))
                            Url = integrationCredential.Attributes[_attrIntAPIUrl].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIAccount))
                            UserAccount = integrationCredential.Attributes[_attrIntAPIAccount].ToString();

                        if (integrationCredential.Attributes.Contains(_attrIntAPIPassword))
                            Password = integrationCredential.Attributes[_attrIntAPIPassword].ToString();
                    }
                    else
                    {
                        throw new Exception("Zero records returned.");
                    }
                }
                else
                {
                    throw new Exception("Could not retrieve Integration Credentials.");
                }


                if (entity.Attributes.Contains(_attrContractId))
                    Contract_ID = entity.Attributes[_attrContractId].ToString();

                tracer.Trace("Contract id is : " + Contract_ID);
                result = GetContract(ref tracer);
                tracer.Trace("Result is : " + result);
                if (result)
                {

                    tracer.Trace(String.Format("Fetch Contract executed successfully for contract id {0}", Contract_ID));
                    try
                    {
                        if (contract_Start_Date != null && contract_Start_Date.Length > 0 && contract_Start_Date.Contains("T"))
                        {
                            contract_Start_Date = contract_Start_Date.Substring(0, contract_Start_Date.IndexOf("T"));

                            if (entity.Attributes.Contains(_attrContractstartdate))
                                entity.Attributes[_attrContractstartdate] = Convert.ToDateTime(contract_Start_Date.ToString());
                            else
                                entity.Attributes.Add(_attrContractstartdate, Convert.ToDateTime(contract_Start_Date.ToString()));
                        }
                    }
                    catch (Exception ex) { }

                    try
                    {
                        if (contract_Create_Date_Time != null && contract_Create_Date_Time.Length > 0 && contract_Create_Date_Time.Contains("T"))
                        {
                            contract_Create_Date_Time = contract_Create_Date_Time.Substring(0, contract_Create_Date_Time.IndexOf("T"));

                            if (entity.Attributes.Contains(_attrPricingContractCreateDate))
                                entity.Attributes[_attrPricingContractCreateDate] = Convert.ToDateTime(contract_Create_Date_Time.ToString());
                            else
                                entity.Attributes.Add(_attrPricingContractCreateDate, Convert.ToDateTime(contract_Create_Date_Time.ToString()));
                        }
                    }
                    catch (Exception ex) { }
                    try
                    {
                        if (contract_Retail_Adder != null && contract_Retail_Adder.Length > 0)
                        {
                            if (entity.Attributes.Contains(_attrContractretailadder))
                                entity.Attributes[_attrContractretailadder] = Convert.ToDecimal(contract_Retail_Adder.ToString()) * 1000;
                            else
                                entity.Attributes.Add(_attrContractretailadder, Convert.ToDecimal(contract_Retail_Adder.ToString()) * 1000);
                        }
                    }
                    catch (Exception ex) { }
                    try
                    {
                        if (contract_Rate != null && contract_Rate.Length > 0)
                        {
                            if (contract_Rate.Contains("Commodity Rate"))
                                contract_Rate = contract_Rate.Replace("Commodity Rate","");
                            if (contract_Rate.Contains("$/kWh"))
                                contract_Rate = contract_Rate.Replace("$/kWh", "");
                             if (contract_Rate.Contains(":"))
                                contract_Rate = contract_Rate.Replace(":", "");
                            if (contract_Rate.Contains("_"))
                                contract_Rate = contract_Rate.Replace("_", "");
                            if (entity.Attributes.Contains(_attrContractrate))
                                entity.Attributes[_attrContractrate] = Convert.ToDecimal(contract_Rate.ToString()) * 1000;
                            else
                                entity.Attributes.Add(_attrContractrate, Convert.ToDecimal(contract_Rate.ToString()) * 1000);
                        }
                    }
                    catch (Exception ex) { }

                    if (entity.Attributes.Contains(_attrProduct))
                        entity.Attributes[_attrProduct] = (Product.ToString());
                    else
                        entity.Attributes.Add(_attrProduct, (Product.ToString()));

                    try
                    {
                        if (date_Priced != null && date_Priced.Length > 0 && date_Priced.Contains("T"))
                        {
                            date_Priced = date_Priced.Substring(0, date_Priced.IndexOf("T"));
                            if (entity.Attributes.Contains(_attrDatepriced))
                                entity.Attributes[_attrDatepriced] = Convert.ToDateTime(date_Priced.ToString());
                            else
                                entity.Attributes.Add(_attrDatepriced, Convert.ToDateTime(date_Priced.ToString()));
                        }
                    }
                    catch (Exception ex) { }

                    try
                    {
                        if (Term != null && Term.Length > 0)
                        {
                            if (entity.Attributes.Contains(_attrTerm))
                                entity.Attributes[_attrTerm] = Convert.ToInt32(Term.ToString());
                            else
                                entity.Attributes.Add(_attrTerm, Convert.ToInt32(Term.ToString()));
                        }
                    }
                    catch (Exception ex) { }

                    try
                    {
                        if (close_Date != null && close_Date.Length > 0 && close_Date.Contains("T"))
                        {
                            close_Date = close_Date.Substring(0, close_Date.IndexOf("T"));
                            if (entity.Attributes.Contains(_attrClosedate))
                                entity.Attributes[_attrClosedate] = Convert.ToDateTime( close_Date.ToString());
                            else
                                entity.Attributes.Add(_attrClosedate, Convert.ToDateTime(close_Date.ToString()));
                        }
                    }
                    catch (Exception ex) { }

                    if (entity.Attributes.Contains(_attrOpportunityID))
                        entity.Attributes[_attrOpportunityID] = opp_ID.ToString();
                    else
                        entity.Attributes.Add(_attrOpportunityID, opp_ID.ToString());

                    if (entity.Attributes.Contains(_attrPricingQuoteID))
                        entity.Attributes[_attrPricingQuoteID] = quote_ID.ToString();
                    else
                        entity.Attributes.Add(_attrPricingQuoteID, quote_ID.ToString());   

                    try
                    {
                       
                        if (meter_Fee != null)
                        {
                            if (entity.Attributes.Contains(_attrMeterfee))
                                entity.Attributes[_attrMeterfee] = new Money( Convert.ToDecimal(meter_Fee.ToString()));
                            else
                                entity.Attributes.Add(_attrMeterfee,new Money (Convert.ToDecimal(meter_Fee.ToString())));
                        }
                    }
                    catch (Exception ex) { }

                    try
                    {
                        if (broker_Fee != null)
                        {
                            if (entity.Attributes.Contains(_attrBrokerfee))
                                entity.Attributes[_attrBrokerfee] = new Money(Convert.ToDecimal(broker_Fee.ToString()) * 1000);
                            else
                                entity.Attributes.Add(_attrBrokerfee, new Money(Convert.ToDecimal(broker_Fee.ToString()) * 1000));
                        }
                    }
                    catch (Exception ex) { }

                    try
                    {
                        if (source_Margin != null)
                        {
                            if (entity.Attributes.Contains(_attrContractSourcemargin))
                                entity.Attributes[_attrContractSourcemargin] = new Money (Convert.ToDecimal(source_Margin.ToString()) * 1000);
                            else
                                entity.Attributes.Add(_attrContractSourcemargin, new Money(Convert.ToDecimal(source_Margin.ToString()) * 1000));
                        }
                    }
                    catch (Exception ex) { }

                    try
                    {
                        if (annual_MWH != null && (Convert.ToDecimal(annual_MWH)) != 0)
                        {

                            if (entity.Attributes.Contains(_attrAnnualmwh))
                                entity.Attributes[_attrAnnualmwh] = Convert.ToInt32((Convert.ToDecimal(annual_MWH)));
                            else
                                entity.Attributes.Add(_attrAnnualmwh, Convert.ToInt32((Convert.ToDecimal(annual_MWH))));
                        }

                    }
                    catch (Exception ex) {  }
                   
                    try
                    {
                        
                        if (term_MWH != null && term_MWH.Length > 0)
                        {
                           
                            if (entity.Attributes.Contains(_attrTermmwh))
                                entity.Attributes[_attrTermmwh] = Convert.ToDecimal(term_MWH.ToString());
                            else
                                entity.Attributes.Add(_attrTermmwh, Convert.ToDecimal(term_MWH.ToString()));
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    
                    
                    
                    if (entity.Attributes.Contains(_attrContractstatus))
                        entity.Attributes[_attrContractstatus] = contract_Status.ToString();
                    else
                        entity.Attributes.Add(_attrContractstatus, contract_Status.ToString());
                   
                    if (entity.Attributes.Contains(_attrProductName))
                        entity.Attributes[_attrProductName] = product_Name.ToString();
                    else
                        entity.Attributes.Add(_attrProductName, product_Name.ToString());

                    if (entity.Attributes.Contains(_attrPaymentTerms))
                        entity.Attributes[_attrPaymentTerms] = payment_Terms.ToString();
                    else
                        entity.Attributes.Add(_attrPaymentTerms, payment_Terms.ToString());


                    string soapHdr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Body>";
                    string soapTrl = "</soapenv:Body></soapenv:Envelope>";
                    string dataXML = string.Concat(soapHdr, Environment.NewLine, Service_parameters, Environment.NewLine, Service_data, Environment.NewLine, soapTrl);

                    if (entity.Attributes.Contains(_attrRequestDataXML))
                        entity.Attributes[_attrRequestDataXML] = dataXML;
                    else
                        entity.Attributes.Add(_attrRequestDataXML, dataXML);

                    if (entity.Attributes.Contains(_attrResultXML))
                        entity.Attributes[_attrResultXML] = XmlResponse.InnerXml;
                    else
                        entity.Attributes.Add(_attrResultXML, XmlResponse.InnerXml);

                    

                     if (entity.Attributes.Contains(_attrContractIntegrationStatus))
                        entity.Attributes[_attrContractIntegrationStatus] = "Success";
                    else
                        entity.Attributes.Add(_attrContractIntegrationStatus, "Success");
                }
                else
                {
                    if (entity.Attributes.Contains(_attrContractIntegrationStatus))
                        entity.Attributes[_attrContractIntegrationStatus] = "Failed";
                    else
                        entity.Attributes.Add(_attrContractIntegrationStatus, "Failed");
                    //throw new Exception(String.Format("Broker Agent could not be integrated for opportunity id {0}", integrateBroker.Opportunity_Tkn));
                    tracer.Trace("Contract could not be update");
                }
            }
            catch (ArgumentOutOfRangeException aore)
            {
                tracer.Trace(aore.Message);
            }
        }

        #region Helpers
        private EntityCollection GetIntCredentials(ref IOrganizationService service, int apiHost)
        {

            ColumnSet Indexcol = new ColumnSet(true);
            QueryByAttribute indexattribute = new QueryByAttribute();
            indexattribute.EntityName = "spg_integrationcredential";
            indexattribute.Attributes.AddRange(new string[] { "spg_apihost" });
            indexattribute.Values.AddRange(apiHost);
            indexattribute.ColumnSet = Indexcol;
            RetrieveMultipleRequest req_index = new RetrieveMultipleRequest();
            req_index.Query = indexattribute;
            RetrieveMultipleResponse resp_index = (RetrieveMultipleResponse)service.Execute(req_index);
            EntityCollection index = resp_index.EntityCollection;

            return index;
        }

        #endregion
    }
}
