﻿using System;
using System.Xml;

namespace SPGStatusSynchronizationfromPricingSolutionforETFEntity
{
    class ETFStatusList
    {
        #region Class attributes used to integration opportunity to ESG Portal
        private string opportunity_Tkn = string.Empty;
        private string url = string.Empty;
        private string userId = string.Empty;
        private string password = string.Empty;
        private string service_parameters = string.Empty;
        private string service_data = string.Empty;

        private string return_Code = string.Empty;
        private string return_Message = string.Empty;
        private string return_Details = string.Empty;

        private int row_limit;
        private DateTime update_start_date;

        XmlDocument xmlResponse = null;

        #endregion

        #region Get/Set methods for attributes
        public string Opportunity_Tkn
        {
            get
            {
                return opportunity_Tkn;
            }

            set
            {
                opportunity_Tkn = value;
            }
        }

        public string Url
        {
            get
            {
                return url;
            }

            set
            {
                url = value;
            }
        }

        public string UserId
        {
            get
            {
                return userId;
            }

            set
            {
                userId = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Service_parameters
        {
            get
            {
                return service_parameters;
            }

            set
            {
                service_parameters = value;
            }
        }

        public string Service_data
        {
            get
            {
                return service_data;
            }

            set
            {
                service_data = value;
            }
        }

        public XmlDocument XmlResponse
        {
            get
            {
                return xmlResponse;
            }

            set
            {
                xmlResponse = value;
            }
        }

        public int Row_limit
        {
            get
            {
                return row_limit;
            }

            set
            {
                row_limit = value;
            }
        }

        public DateTime Update_start_date
        {
            get
            {
                return update_start_date;
            }

            set
            {
                update_start_date = value;
            }
        }

        public string Return_Code
        {
            get
            {
                return return_Code;
            }

            set
            {
                return_Code = value;
            }
        }

        public string Return_Message
        {
            get
            {
                return return_Message;
            }

            set
            {
                return_Message = value;
            }
        }

        public string Return_Details
        {
            get
            {
                return return_Details;
            }

            set
            {
                return_Details = value;
            }
        }
        #endregion

        public ETFStatusList()
        {

        }

        public Boolean GetOpportunityStatus()
        {
            try
            {
                if (opportunity_Tkn != String.Empty)
                {
                    service_parameters = "<serviceParameters>" +
                                            "<logonUserid>" + userId + "</logonUserid>" +
                                            "<logonPassword>" + password + "</logonPassword>" +
                                            "<companyID>CW_SOURCE</companyID>" +
                                            "<partName>Opportunity.Opportunity_List</partName>" +
                                            String.Format("<partTokens>Opportunity_Tkn={0}</partTokens>", opportunity_Tkn) +
                                            "<partFunction>list</partFunction>" +
                                            String.Format("<partSearch>&lt;field rowLimit='{0}' name='Update_Start_Date_Sc' value='{1}' operator='=' ignoreCase='false' soundex='false'/&gt;</partSearch>", row_limit, update_start_date.ToString("yyyy-MM-dd")) +
                                            "<partOrder></partOrder>" +
                                            "</serviceParameters>";
                }
                else
                {
                    service_parameters = "<serviceParameters>" +
                                            "<logonUserid>" + userId + "</logonUserid>" +
                                            "<logonPassword>" + password + "</logonPassword>" +
                                            "<companyID>CW_SOURCE</companyID>" +
                                            "<partName>Opportunity.Opportunity_List</partName>" +
                                            "<partTokens>Opportunity_Tkn=</partTokens>" +
                                            "<partFunction>list</partFunction>" +
                                            String.Format("<partSearch>&lt;field rowLimit='{0}' name='Update_Start_Date_Sc' value='{1}' operator='=' ignoreCase='false' soundex='false'/&gt;</partSearch>", row_limit, update_start_date.ToString("yyyy-MM-dd")) +
                                            //"<partSearch>\"<field rowLimit='500' name='Update_Start_Date_Sc' value='2015-10-01' operator='=' ignoreCase='false' soundex='false'/>\"</partSearch>" +
                                            "<partOrder></partOrder>" +
                                            "</serviceParameters>";
                }

                service_data = "<serviceData>" +
                                "<Opportunity_Id></Opportunity_Id>" +
                                "<Opportunity_Name></Opportunity_Name>" +
                                "<Internal_Master_Code></Internal_Master_Code>" +
                                "<External_Master_Code></External_Master_Code>" +
                                "<Status_Substatus_Desc></Status_Substatus_Desc>" +
                                "<Create_Date></Create_Date>" +
                                "<Num_Accounts></Num_Accounts>" +
                                "<Total_HU_Num></Total_HU_Num>" +
                                "<HU_Days_Cnt></HU_Days_Cnt>" +
                                "<Average_HU_Num></Average_HU_Num>" +
                                "<Update_Tstamp></Update_Tstamp>" +
                                "</serviceData>";

                XmlResponse = Program.HttpSOAPRequest(url, Service_parameters, Service_data);

                if (XmlResponse != null)
                {
                    string Response = XmlResponse.InnerXml;

                    Response = Response.Replace(":", "_");

                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(Response);

                    XmlNode returnCode = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnCode");
                    XmlNode returnMessage = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnMessage");
                    XmlNode returnDetails = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceReturn/returnDetails");

                    //XmlNode statusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Status_Desc");
                    //XmlNode subStatusDesc = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Sub_Status_Desc");

                    if (returnCode.InnerText != "")
                        return_Code = returnCode.InnerText;

                    if (returnMessage.InnerText != "")
                        return_Message = returnMessage.InnerText;

                    if (returnDetails.InnerText != "")
                        return_Details = returnMessage.InnerText;

                    //if (statusDesc.InnerText != "")
                    //    status_Desc = statusDesc.InnerText;

                    //if (subStatusDesc.InnerText != "")
                    //    sub_Status_Desc = subStatusDesc.InnerText;

                    //if (Convert.ToInt32(returnCode.InnerText) == (int)ESGWebServiceReturnCode.TaskCompletedOk)
                    //{
                    //    XmlNode opportunityToken = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_Tkn");
                    //    XmlNode opportunityId = xmlDoc.SelectSingleNode("/soapenv_Envelope/soapenv_Body/serviceData/Opportunity_ID");

                    //    if (opportunityId.InnerText != "")
                    //        opportunity_ID = opportunityId.InnerText;

                    //    if (opportunityToken.InnerText != "")
                    //        opportunity_Tkn = opportunityToken.InnerText;

                    //    return true;
                    //}
                    //else
                    //{
                    //    return false;
                    //}

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
